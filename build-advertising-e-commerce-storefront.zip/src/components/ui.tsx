"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";

export function StarRating({
  value,
  size = "sm",
  showValue = false,
  count,
}: {
  value: number;
  size?: "sm" | "md" | "lg";
  showValue?: boolean;
  count?: number;
}) {
  const dimension = size === "lg" ? "h-5 w-5" : size === "md" ? "h-4 w-4" : "h-3.5 w-3.5";
  const rounded = Math.round(value * 2) / 2;
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="inline-flex items-center gap-0.5" aria-hidden>
        {[1, 2, 3, 4, 5].map((star) => {
          const fill = rounded >= star ? 1 : rounded >= star - 0.5 ? 0.5 : 0;
          return (
            <svg key={star} viewBox="0 0 20 20" className={`${dimension} shrink-0`}>
              <defs>
                <linearGradient id={`half-${star}-${fill}`}>
                  <stop offset="50%" stopColor="currentColor" />
                  <stop offset="50%" stopColor="transparent" />
                </linearGradient>
              </defs>
              <path
                d="M10 1.6l2.6 5.3 5.8.8-4.2 4.1 1 5.8L10 14.9l-5.2 2.7 1-5.8L1.6 7.7l5.8-.8L10 1.6z"
                className="text-brass-400"
                fill={fill === 1 ? "currentColor" : fill === 0.5 ? `url(#half-${star}-${fill})` : "none"}
                stroke="currentColor"
                strokeWidth="1.2"
              />
            </svg>
          );
        })}
      </span>
      {showValue ? (
        <span className="font-mono text-xs text-ink-600">
          {value.toFixed(1)}
          {typeof count === "number" ? ` · ${count} reseñas` : ""}
        </span>
      ) : null}
      <span className="sr-only">{value.toFixed(1)} de 5</span>
    </span>
  );
}

export function Reveal({
  children,
  delay = 0,
  className = "",
  as: Tag = "div",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: "div" | "section" | "li" | "article" | "header";
}) {
  const ref = useRef<HTMLElement | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    if (typeof IntersectionObserver === "undefined") {
      setVisible(true);
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisible(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -60px 0px" },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <Tag
      ref={ref as never}
      className={`reveal ${visible ? "is-visible" : ""} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}

export function Badge({ children, tone = "brass" }: { children: ReactNode; tone?: "brass" | "ink" | "flame" }) {
  const tones = {
    brass: "border-brass-400/40 bg-brass-100/70 text-brass-600",
    ink: "border-ink-900/15 bg-ink-900/5 text-ink-700",
    flame: "border-flame-500/30 bg-flame-400/12 text-flame-500",
  } as const;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-[0.18em] ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  invert = false,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  invert?: boolean;
}) {
  return (
    <div
      className={`max-w-2xl ${align === "center" ? "mx-auto text-center" : ""} ${
        invert ? "text-bone-100" : "text-ink-900"
      }`}
    >
      <p className={`eyebrow ${invert ? "text-brass-300" : "text-iris-600"}`}>{eyebrow}</p>
      <h2 className="display-balance mt-4 text-3xl leading-[1.08] sm:text-4xl lg:text-[2.75rem]">
        {title}
      </h2>
      {description ? (
        <p className={`mt-4 text-sm leading-relaxed sm:text-base ${invert ? "text-bone-300/80" : "text-ink-600"}`}>
          {description}
        </p>
      ) : null}
    </div>
  );
}
