import Image from "next/image";
import Link from "next/link";
import { QuickAdd } from "@/components/add-to-cart";
import { StarRating } from "@/components/ui";
import { formatMoney, ratingLabel } from "@/lib/format";
import type { Product } from "@/db/schema";

export function ProductCard({
  product,
  categoryName,
  priority = false,
  compact = false,
}: {
  product: Product;
  categoryName?: string;
  priority?: boolean;
  compact?: boolean;
}) {
  const hasDiscount =
    typeof product.compareAtPriceCents === "number" && product.compareAtPriceCents > product.priceCents;
  const discount = hasDiscount
    ? Math.round((1 - product.priceCents / (product.compareAtPriceCents as number)) * 100)
    : 0;

  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-sm border border-bone-200 bg-bone-50 transition-all duration-500 hover:-translate-y-1 hover:border-ink-900/20 hover:shadow-[0_40px_60px_-40px_rgba(12,12,17,0.45)]">
      <Link
        href={`/producto/${product.slug}`}
        className="relative block aspect-4/5 overflow-hidden bg-bone-100"
      >
        <Image
          src={product.images[0]}
          alt={product.name}
          fill
          priority={priority}
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
          className="object-cover transition-all duration-[900ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.07]"
        />
        {product.images[1] ? (
          <Image
            src={product.images[1]}
            alt=""
            aria-hidden
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            className="object-cover opacity-0 transition-opacity duration-700 group-hover:opacity-100"
          />
        ) : null}

        <div className="absolute inset-x-0 top-0 flex items-start justify-between p-3">
          <div className="flex flex-col gap-1.5">
            {product.badge ? (
              <span className="rounded-full bg-ink-950/90 px-3 py-1 font-mono text-[9px] uppercase tracking-[0.18em] text-brass-200 backdrop-blur">
                {product.badge}
              </span>
            ) : null}
            {discount > 0 ? (
              <span className="rounded-full bg-flame-500 px-3 py-1 font-mono text-[9px] uppercase tracking-[0.18em] text-bone-50">
                −{discount}%
              </span>
            ) : null}
          </div>
          {product.reviewCount > 0 ? (
            <span className="flex items-center gap-1 rounded-full bg-bone-50/90 px-2.5 py-1 font-mono text-[10px] text-ink-800 backdrop-blur">
              <StarRating value={product.ratingAvg / 10} />
              {ratingLabel(product.ratingAvg)}
            </span>
          ) : null}
        </div>
      </Link>

      <div className="flex flex-1 flex-col gap-3 p-5">
        <div className="flex items-center justify-between gap-2">
          <span className="eyebrow text-ink-400">
            {categoryName ?? product.categorySlug.replace(/-/g, " ")}
          </span>
          <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-400">
            {product.leadTime}
          </span>
        </div>

        <Link href={`/producto/${product.slug}`} className="block">
          <h3 className="display-balance text-[1.05rem] leading-snug transition-colors group-hover:text-brass-600">
            {product.name}
          </h3>
        </Link>

        {!compact ? (
          <p className="line-clamp-2 text-[13px] leading-relaxed text-ink-600">
            {product.shortDescription}
          </p>
        ) : null}

        <div className="mt-auto space-y-4 pt-2">
          <div className="flex items-end justify-between gap-3">
            <div>
              <p className="font-mono text-lg text-ink-950">{formatMoney(product.priceCents)}</p>
              <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-400">
                {product.unitLabel}
              </p>
            </div>
            {hasDiscount ? (
              <p className="font-mono text-xs text-ink-400 line-through">
                {formatMoney(product.compareAtPriceCents as number)}
              </p>
            ) : null}
          </div>
          <div className="translate-y-2 opacity-100 transition-all duration-500 group-hover:translate-y-0 lg:translate-y-3 lg:opacity-0 lg:group-hover:opacity-100">
            <QuickAdd
              product={{
                slug: product.slug,
                name: product.name,
                image: product.images[0],
                unitLabel: product.unitLabel,
                priceCents: product.priceCents,
                minQty: product.minQty,
              }}
            />
          </div>
        </div>
      </div>
    </article>
  );
}
