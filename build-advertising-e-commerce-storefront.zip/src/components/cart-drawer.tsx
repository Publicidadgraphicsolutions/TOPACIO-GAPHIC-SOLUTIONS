"use client";

import Image from "next/image";
import Link from "next/link";
import { useCart } from "@/components/cart-provider";
import { formatMoney, FREE_SHIPPING_THRESHOLD_CENTS } from "@/lib/format";

export function CartDrawer() {
  const {
    items,
    count,
    subtotalCents,
    totals,
    isOpen,
    closeCart,
    setQuantity,
    removeItem,
    deliveryMethod,
    setDeliveryMethod,
    hydrated,
    lastAdded,
  } = useCart();

  const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD_CENTS - subtotalCents);
  const progress = Math.min(100, (subtotalCents / FREE_SHIPPING_THRESHOLD_CENTS) * 100);

  return (
    <>
      <div
        aria-hidden={!isOpen}
        onClick={closeCart}
        className={`fixed inset-0 z-70 bg-ink-950/70 backdrop-blur-sm transition-opacity duration-500 ${
          isOpen ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      />
      <aside
        role="dialog"
        aria-modal="true"
        aria-label="Carrito de compra"
        className={`fixed inset-y-0 right-0 z-80 flex w-full max-w-[27rem] flex-col bg-ink-950 text-bone-100 shadow-[0_0_80px_rgba(0,0,0,0.55)] transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <header className="flex items-center justify-between border-b border-bone-100/10 px-6 py-5">
          <div>
            <p className="eyebrow text-brass-300">Tu pedido</p>
            <p className="display-balance mt-1 text-xl">
              {count > 0 ? `${count} ${count === 1 ? "pieza" : "piezas"}` : "Carrito vacío"}
            </p>
          </div>
          <button
            type="button"
            onClick={closeCart}
            className="grid h-10 w-10 place-items-center rounded-full border border-bone-100/15 text-bone-200 transition hover:border-brass-300 hover:text-brass-200"
            aria-label="Cerrar carrito"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </header>

        {hydrated && items.length > 0 ? (
          <>
            <div className="border-b border-bone-100/10 px-6 py-4">
              <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-[0.2em] text-bone-300/70">
                <span>Envío gratis desde {formatMoney(FREE_SHIPPING_THRESHOLD_CENTS)}</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <div className="mt-2 h-1 overflow-hidden rounded-full bg-bone-100/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-brass-500 to-brass-200 transition-all duration-700"
                  style={{ width: `${progress}%` }}
                />
              </div>
              {remaining > 0 ? (
                <p className="mt-2 text-xs text-bone-300/70">
                  Te faltan <span className="text-brass-200">{formatMoney(remaining)}</span> para
                  envío sin costo.
                </p>
              ) : (
                <p className="mt-2 text-xs text-brass-200">¡Envío sin costo desbloqueado!</p>
              )}
            </div>

            <ul className="flex-1 divide-y divide-bone-100/8 overflow-y-auto px-6">
              {items.map((item) => (
                <li
                  key={item.slug}
                  className={`flex gap-4 py-5 transition-colors ${
                    lastAdded === item.slug ? "bg-brass-400/5" : ""
                  }`}
                >
                  <Link
                    href={`/producto/${item.slug}`}
                    onClick={closeCart}
                    className="relative h-20 w-16 shrink-0 overflow-hidden rounded-sm bg-ink-800"
                  >
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      sizes="64px"
                      className="object-cover"
                    />
                  </Link>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-3">
                      <Link
                        href={`/producto/${item.slug}`}
                        onClick={closeCart}
                        className="text-sm leading-snug text-bone-100 transition hover:text-brass-200"
                      >
                        {item.name}
                      </Link>
                      <button
                        type="button"
                        onClick={() => removeItem(item.slug)}
                        className="shrink-0 text-bone-300/50 transition hover:text-flame-400"
                        aria-label={`Quitar ${item.name}`}
                      >
                        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.6">
                          <path d="M5 7h14M9 7V5h6v2M7 7l1 13h8l1-13" />
                        </svg>
                      </button>
                    </div>
                    <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.16em] text-bone-300/50">
                      {item.unitLabel}
                    </p>
                    <div className="mt-3 flex items-center justify-between">
                      <div className="inline-flex items-center rounded-full border border-bone-100/15">
                        <button
                          type="button"
                          onClick={() => setQuantity(item.slug, item.quantity - 1)}
                          className="grid h-8 w-8 place-items-center rounded-full text-bone-200 transition hover:text-brass-200"
                          aria-label="Reducir cantidad"
                        >
                          −
                        </button>
                        <span className="min-w-8 text-center font-mono text-xs">{item.quantity}</span>
                        <button
                          type="button"
                          onClick={() => setQuantity(item.slug, item.quantity + 1)}
                          className="grid h-8 w-8 place-items-center rounded-full text-bone-200 transition hover:text-brass-200"
                          aria-label="Aumentar cantidad"
                        >
                          +
                        </button>
                      </div>
                      <span className="font-mono text-sm text-brass-200">
                        {formatMoney(item.priceCents * item.quantity)}
                      </span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>

            <footer className="space-y-4 border-t border-bone-100/10 bg-ink-900/60 px-6 py-5">
              <div className="grid grid-cols-2 gap-2">
                {(["enviar", "recoger"] as const).map((method) => (
                  <button
                    key={method}
                    type="button"
                    onClick={() => setDeliveryMethod(method)}
                    className={`rounded-sm border px-3 py-2 font-mono text-[10px] uppercase tracking-[0.18em] transition ${
                      deliveryMethod === method
                        ? "border-brass-300 bg-brass-300/10 text-brass-200"
                        : "border-bone-100/15 text-bone-300/70 hover:border-bone-100/30"
                    }`}
                  >
                    {method === "enviar" ? "Envío a domicilio" : "Recoger en taller"}
                  </button>
                ))}
              </div>
              <dl className="space-y-1.5 font-mono text-xs text-bone-300/80">
                <div className="flex justify-between">
                  <dt>Subtotal</dt>
                  <dd>{formatMoney(totals.subtotalCents)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>Envío</dt>
                  <dd>{totals.shippingCents === 0 ? "Incluido" : formatMoney(totals.shippingCents)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>IVA 16%</dt>
                  <dd>{formatMoney(totals.taxCents)}</dd>
                </div>
                <div className="flex justify-between border-t border-bone-100/10 pt-2 text-sm text-bone-50">
                  <dt>Total estimado</dt>
                  <dd className="text-brass-200">{formatMoney(totals.totalCents)}</dd>
                </div>
              </dl>
              <Link
                href="/checkout"
                onClick={closeCart}
                className="group flex items-center justify-center gap-2 rounded-sm bg-brass-300 px-6 py-3.5 text-center font-mono text-[11px] uppercase tracking-[0.22em] text-ink-950 transition hover:bg-brass-200"
              >
                Continuar al checkout
                <svg viewBox="0 0 24 24" className="h-4 w-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <path d="M4 12h15M13 6l6 6-6 6" />
                </svg>
              </Link>
              <button
                type="button"
                onClick={closeCart}
                className="w-full text-center font-mono text-[10px] uppercase tracking-[0.2em] text-bone-300/60 transition hover:text-bone-100"
              >
                Seguir explorando
              </button>
            </footer>
          </>
        ) : (
          <div className="flex flex-1 flex-col items-center justify-center gap-5 px-8 text-center">
            <div className="grid h-20 w-20 place-items-center rounded-full border border-brass-400/30 text-brass-300">
              <svg viewBox="0 0 24 24" className="h-8 w-8" fill="none" stroke="currentColor" strokeWidth="1.2">
                <path d="M4 7h16l-1.2 13H5.2L4 7zM9 7V5.4A3 3 0 0 1 12 3a3 3 0 0 1 3 2.4V7" />
              </svg>
            </div>
            <div>
              <p className="display-balance text-2xl">Tu carrito está vacío</p>
              <p className="mt-2 text-sm text-bone-300/70">
                Explora papelería, P.O.P., branding y producción audiovisual lista para producir.
              </p>
            </div>
            <Link
              href="/tienda"
              onClick={closeCart}
              className="rounded-sm border border-brass-400/50 px-6 py-3 font-mono text-[11px] uppercase tracking-[0.22em] text-brass-200 transition hover:bg-brass-300 hover:text-ink-950"
            >
              Ver catálogo
            </Link>
          </div>
        )}
      </aside>
    </>
  );
}
