"use client";

import Image from "next/image";
import { useState } from "react";

export function ProductGallery({ images, name }: { images: string[]; name: string }) {
  const [active, setActive] = useState(0);
  const [zoom, setZoom] = useState(false);
  const list = images.length > 0 ? images : ["/images/hero-atelier.jpg"];

  return (
    <div className="flex flex-col gap-4">
      <div
        className="group relative aspect-4/5 w-full overflow-hidden rounded-sm bg-bone-100"
        onMouseEnter={() => setZoom(true)}
        onMouseLeave={() => setZoom(false)}
      >
        {list.map((image, index) => (
          <Image
            key={`${image}-${index}`}
            src={image}
            alt={`${name} — imagen ${index + 1}`}
            fill
            priority={index === 0}
            sizes="(max-width: 1024px) 100vw, 50vw"
            className={`object-cover transition-all duration-[900ms] ease-[cubic-bezier(0.16,1,0.3,1)] ${
              index === active ? "opacity-100" : "opacity-0"
            } ${zoom && index === active ? "scale-[1.12]" : "scale-100"}`}
          />
        ))}

        {list.length > 1 ? (
          <>
            <button
              type="button"
              onClick={() => setActive((value) => (value - 1 + list.length) % list.length)}
              aria-label="Imagen anterior"
              className="absolute left-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-bone-50/85 text-ink-900 opacity-0 backdrop-blur transition-all duration-300 hover:bg-bone-50 group-hover:opacity-100"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M15 6l-6 6 6 6" />
              </svg>
            </button>
            <button
              type="button"
              onClick={() => setActive((value) => (value + 1) % list.length)}
              aria-label="Imagen siguiente"
              className="absolute right-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-bone-50/85 text-ink-900 opacity-0 backdrop-blur transition-all duration-300 hover:bg-bone-50 group-hover:opacity-100"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M9 6l6 6-6 6" />
              </svg>
            </button>
            <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 gap-1.5">
              {list.map((image, index) => (
                <button
                  key={`dot-${image}-${index}`}
                  type="button"
                  onClick={() => setActive(index)}
                  aria-label={`Ver imagen ${index + 1}`}
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    index === active ? "w-7 bg-ink-950" : "w-1.5 bg-ink-950/40 hover:bg-ink-950/70"
                  }`}
                />
              ))}
            </div>
          </>
        ) : null}

        <span className="absolute right-4 top-4 rounded-full bg-ink-950/85 px-3 py-1 font-mono text-[9px] uppercase tracking-[0.18em] text-bone-100 backdrop-blur">
          {active + 1} / {list.length}
        </span>
      </div>

      {list.length > 1 ? (
        <ul className="grid grid-cols-4 gap-3">
          {list.map((image, index) => (
            <li key={`thumb-${image}-${index}`}>
              <button
                type="button"
                onClick={() => setActive(index)}
                className={`relative aspect-square w-full overflow-hidden rounded-sm border transition-all duration-300 ${
                  index === active
                    ? "border-brass-400 ring-1 ring-brass-400/40"
                    : "border-bone-200 opacity-70 hover:opacity-100"
                }`}
                aria-label={`Ver imagen ${index + 1}`}
              >
                <Image src={image} alt="" aria-hidden fill sizes="120px" className="object-cover" />
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}
