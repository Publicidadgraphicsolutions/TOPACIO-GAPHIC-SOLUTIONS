"use client";

import Link from "next/link";
import { useState } from "react";
import { BrandLockup } from "@/components/brand";

type NavCategory = { slug: string; name: string; icon: string };

export function NewsletterForm({ compact = false }: { compact?: boolean }) {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (!email.includes("@")) {
      setState("error");
      return;
    }
    setState("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      setState(res.ok ? "done" : "error");
      if (res.ok) setEmail("");
    } catch {
      setState("error");
    }
  }

  if (state === "done") {
    return (
      <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-brass-200">
        ¡Listo! Te llegará el próximo brief.
      </p>
    );
  }

  return (
    <form onSubmit={onSubmit} className={compact ? "" : "max-w-md"}>
      <div className="flex items-center gap-2 border-b border-bone-100/20 pb-3 focus-within:border-brass-300">
        <input
          type="email"
          value={email}
          onChange={(event) => {
            setEmail(event.target.value);
            setState("idle");
          }}
          placeholder="correo@empresa.com"
          className="w-full bg-transparent text-sm text-bone-100 outline-none placeholder:text-bone-300/40"
          aria-label="Correo electrónico"
        />
        <button
          type="submit"
          disabled={state === "loading"}
          className="shrink-0 font-mono text-[10px] uppercase tracking-[0.2em] text-brass-300 transition hover:text-brass-100 disabled:opacity-50"
        >
          {state === "loading" ? "Enviando…" : "Suscribirme"}
        </button>
      </div>
      {state === "error" ? (
        <p className="mt-2 font-mono text-[10px] uppercase tracking-[0.18em] text-flame-400">
          Revisa el correo e intenta de nuevo.
        </p>
      ) : null}
    </form>
  );
}

export function SiteFooter({
  categories,
  settings,
}: {
  categories: NavCategory[];
  settings: Record<string, string>;
}) {
  return (
    <footer className="cyber-grid relative overflow-hidden border-t border-iris-500/25 bg-ink-950 text-bone-200">
      <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-iris-500/20 blur-3xl" />
      <div className="pointer-events-none absolute -right-20 top-10 h-64 w-64 rounded-full bg-brass-400/10 blur-3xl" />
      <div className="relative mx-auto max-w-[88rem] px-5 py-16 sm:px-8 lg:py-20">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <BrandLockup size={62} />
            <p className="mt-6 max-w-sm text-sm leading-relaxed text-bone-300/70">
              {settings.footerNote}
            </p>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-bone-300/60">
              Agencia creativa: papelería comercial, material P.O.P., diseño gráfico, BTL,
              producción audiovisual UGC, modelaje y talleres para emprender.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {["Factura CFDI 4.0", "MAyM / MiPyME", "Envíos nacionales", "Garantía de reimpresión"].map(
                (item) => (
                  <span
                    key={item}
                    className="rounded-full border border-brass-400/30 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-brass-200"
                  >
                    {item}
                  </span>
                ),
              )}
            </div>
          </div>

          <div>
            <p className="eyebrow text-brass-300">Servicios</p>
            <ul className="mt-5 space-y-3 text-sm">
              {categories.map((category) => (
                <li key={category.slug}>
                  <Link
                    href={`/tienda?categoria=${category.slug}`}
                    className="text-bone-300/75 transition hover:text-brass-200"
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="eyebrow text-brass-300">Taller</p>
            <ul className="mt-5 space-y-3 text-sm text-bone-300/75">
              <li>
                <Link href="/tienda" className="transition hover:text-brass-300">
                  Catálogo completo
                </Link>
              </li>
              <li>
                <Link href="/talleres" className="transition hover:text-brass-300">
                  Talleres para emprender
                </Link>
              </li>
              <li>
                <Link href="/#proceso" className="transition hover:text-brass-300">
                  Cómo trabajamos
                </Link>
              </li>
              <li>
                <Link href="/#cotizacion" className="transition hover:text-brass-200">
                  Solicitar cotización
                </Link>
              </li>
              <li>
                <Link href="/checkout" className="transition hover:text-brass-200">
                  Finalizar compra
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <p className="eyebrow text-brass-300">Brief mensual</p>
            <p className="mt-5 text-sm leading-relaxed text-bone-300/70">
              Ideas de campaña, tendencias de punto de venta y precios de temporada. Sin spam.
            </p>
            <div className="mt-5">
              <NewsletterForm />
            </div>
            <div className="mt-7 space-y-1.5 font-mono text-[11px] text-bone-300/60">
              <p className="text-brass-300">{settings.instagram}</p>
              <p>{settings.email}</p>
              <p>{settings.whatsapp}</p>
              <p>Lun a Vie · 9:00 – 19:00</p>
            </div>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-4 border-t border-bone-100/10 pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-bone-300/50">
            © {new Date().getFullYear()} Publicidad Graphic Solutions · Papelería comercial y marketing digital
          </p>
          <div className="flex flex-wrap gap-5 font-mono text-[10px] uppercase tracking-[0.18em] text-bone-300/50">
            <span>Aviso de privacidad</span>
            <span>Términos</span>
            <span>Entregas</span>
            <Link
              href="/admin"
              className="text-brass-400 transition hover:text-flame-400"
              title="Panel de edición"
            >
              ✎ Panel de edición
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
