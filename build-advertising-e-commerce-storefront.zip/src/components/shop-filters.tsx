"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { SORT_OPTIONS, type SortKey } from "@/lib/sort";

type Facet = { slug: string; name: string; total: number };

const PRICE_PRESETS = [
  { label: "Hasta $1,000", min: undefined, max: 1000 },
  { label: "$1,000 – $5,000", min: 1000, max: 5000 },
  { label: "$5,000 – $15,000", min: 5000, max: 15000 },
  { label: "Más de $15,000", min: 15000, max: undefined },
];

export function SortSelect() {
  const router = useRouter();
  const params = useSearchParams();
  const current = (params.get("orden") as SortKey | null) ?? "destacados";

  return (
    <label className="flex items-center gap-3">
      <span className="hidden font-mono text-[10px] uppercase tracking-[0.18em] text-ink-400 sm:block">
        Ordenar
      </span>
      <select
        value={current}
        onChange={(event) => {
          const next = new URLSearchParams(params.toString());
          next.set("orden", event.target.value);
          router.replace(`/tienda?${next.toString()}`, { scroll: false });
        }}
        className="rounded-sm border border-bone-300 bg-bone-50 px-4 py-2.5 font-mono text-[11px] uppercase tracking-[0.14em] text-ink-800 outline-none transition hover:border-ink-900 focus:border-brass-400"
      >
        {SORT_OPTIONS.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </label>
  );
}

export function ActiveFilterChips({ facets }: { facets: Facet[] }) {
  const router = useRouter();
  const params = useSearchParams();
  if (params.toString().length === 0) return null;

  const chips: { label: string; key: string }[] = [];
  const categoria = params.get("categoria");
  if (categoria) {
    chips.push({ label: facets.find((f) => f.slug === categoria)?.name ?? categoria, key: "categoria" });
  }
  const q = params.get("q");
  if (q) chips.push({ label: `“${q}”`, key: "q" });
  const tags = params.get("tags");
  if (tags) {
    tags
      .split(",")
      .filter(Boolean)
      .forEach((tag) => chips.push({ label: `#${tag}`, key: `tag:${tag}` }));
  }
  const min = params.get("min");
  const max = params.get("max");
  if (min || max) {
    chips.push({
      label: `${min ? `$${min}` : "$0"} – ${max ? `$${max}` : "∞"}`,
      key: "price",
    });
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      {chips.map((chip) => (
        <button
          key={chip.key}
          type="button"
          onClick={() => {
            const next = new URLSearchParams(params.toString());
            if (chip.key.startsWith("tag:")) {
              const remaining = (params.get("tags") ?? "")
                .split(",")
                .filter((tag) => tag && `tag:${tag}` !== chip.key);
              if (remaining.length) next.set("tags", remaining.join(","));
              else next.delete("tags");
            } else if (chip.key === "price") {
              next.delete("min");
              next.delete("max");
            } else {
              next.delete(chip.key);
            }
            router.replace(`/tienda?${next.toString()}`, { scroll: false });
          }}
          className="group inline-flex items-center gap-2 rounded-full border border-bone-300 bg-bone-50 px-3.5 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-700 transition hover:border-ink-900"
        >
          {chip.label}
          <span className="text-ink-400 transition group-hover:text-flame-500">×</span>
        </button>
      ))}
      <button
        type="button"
        onClick={() => router.replace("/tienda", { scroll: false })}
        className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-400 underline decoration-dotted transition hover:text-flame-500"
      >
        Limpiar todo
      </button>
    </div>
  );
}

export function ShopFilters({
  facets,
  tags,
  bounds,
}: {
  facets: Facet[];
  tags: string[];
  bounds: { min: number; max: number };
}) {
  const router = useRouter();
  const params = useSearchParams();
  const [open, setOpen] = useState(false);
  const [term, setTerm] = useState(params.get("q") ?? "");
  const [minValue, setMinValue] = useState(params.get("min") ?? "");
  const [maxValue, setMaxValue] = useState(params.get("max") ?? "");

  const activeCategory = params.get("categoria");
  const activeTags = (params.get("tags") ?? "").split(",").filter(Boolean);

  const push = useCallback(
    (mutate: (next: URLSearchParams) => void) => {
      const next = new URLSearchParams(params.toString());
      mutate(next);
      const query = next.toString();
      router.replace(query ? `/tienda?${query}` : "/tienda", { scroll: false });
    },
    [params, router],
  );

  useEffect(() => {
    setTerm(params.get("q") ?? "");
    setMinValue(params.get("min") ?? "");
    setMaxValue(params.get("max") ?? "");
  }, [params]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      const current = params.get("q") ?? "";
      if (term.trim() === current) return;
      push((next) => {
        if (term.trim()) next.set("q", term.trim());
        else next.delete("q");
      });
    }, 420);
    return () => window.clearTimeout(timer);
  }, [term, params, push]);

  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [open]);

  const body = (
    <div className="space-y-9">
      <div>
        <p className="eyebrow text-ink-400">Buscar</p>
        <div className="mt-3 flex items-center gap-2 border-b border-bone-300 pb-2 focus-within:border-brass-400">
          <svg viewBox="0 0 24 24" className="h-4 w-4 text-ink-400" fill="none" stroke="currentColor" strokeWidth="1.6">
            <circle cx="11" cy="11" r="7" />
            <path d="M20 20l-3.6-3.6" />
          </svg>
          <input
            value={term}
            onChange={(event) => setTerm(event.target.value)}
            placeholder="Tarjetas, exhibidor, UGC…"
            className="w-full bg-transparent text-sm outline-none placeholder:text-ink-400"
          />
        </div>
      </div>

      <div>
        <p className="eyebrow text-ink-400">Colección</p>
        <ul className="mt-3 space-y-1">
          <li>
            <button
              type="button"
              onClick={() => push((next) => next.delete("categoria"))}
              className={`flex w-full items-center justify-between rounded-sm px-3 py-2 text-left text-sm transition ${
                !activeCategory ? "bg-ink-950 text-bone-100" : "text-ink-700 hover:bg-bone-100"
              }`}
            >
              Todo el catálogo
              <span className="font-mono text-[10px] opacity-70">
                {facets.reduce((total, facet) => total + facet.total, 0)}
              </span>
            </button>
          </li>
          {facets.map((facet) => (
            <li key={facet.slug}>
              <button
                type="button"
                onClick={() =>
                  push((next) => {
                    if (activeCategory === facet.slug) next.delete("categoria");
                    else next.set("categoria", facet.slug);
                  })
                }
                className={`flex w-full items-center justify-between gap-2 rounded-sm px-3 py-2 text-left text-sm transition ${
                  activeCategory === facet.slug
                    ? "bg-ink-950 text-bone-100"
                    : "text-ink-700 hover:bg-bone-100"
                }`}
              >
                <span className="truncate">{facet.name}</span>
                <span className="font-mono text-[10px] opacity-70">{facet.total}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <p className="eyebrow text-ink-400">Precio (MXN)</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {PRICE_PRESETS.map((preset) => {
            const active =
              (params.get("min") ?? "") === (preset.min?.toString() ?? "") &&
              (params.get("max") ?? "") === (preset.max?.toString() ?? "");
            return (
              <button
                key={preset.label}
                type="button"
                onClick={() =>
                  push((next) => {
                    if (active) {
                      next.delete("min");
                      next.delete("max");
                    } else {
                      if (preset.min) next.set("min", String(preset.min));
                      else next.delete("min");
                      if (preset.max) next.set("max", String(preset.max));
                      else next.delete("max");
                    }
                  })
                }
                className={`rounded-full border px-3.5 py-1.5 font-mono text-[10px] uppercase tracking-[0.12em] transition ${
                  active
                    ? "border-ink-950 bg-ink-950 text-bone-100"
                    : "border-bone-300 text-ink-600 hover:border-ink-900"
                }`}
              >
                {preset.label}
              </button>
            );
          })}
        </div>
        <div className="mt-4 flex items-center gap-2">
          <input
            type="number"
            inputMode="numeric"
            value={minValue}
            min={bounds.min}
            max={bounds.max}
            onChange={(event) => setMinValue(event.target.value)}
            placeholder={`${bounds.min}`}
            className="w-full rounded-sm border border-bone-300 bg-transparent px-3 py-2 font-mono text-xs outline-none focus:border-brass-400"
            aria-label="Precio mínimo"
          />
          <span className="text-ink-400">—</span>
          <input
            type="number"
            inputMode="numeric"
            value={maxValue}
            min={bounds.min}
            max={bounds.max}
            onChange={(event) => setMaxValue(event.target.value)}
            placeholder={`${bounds.max}`}
            className="w-full rounded-sm border border-bone-300 bg-transparent px-3 py-2 font-mono text-xs outline-none focus:border-brass-400"
            aria-label="Precio máximo"
          />
          <button
            type="button"
            onClick={() =>
              push((next) => {
                if (minValue) next.set("min", minValue);
                else next.delete("min");
                if (maxValue) next.set("max", maxValue);
                else next.delete("max");
              })
            }
            className="shrink-0 rounded-sm bg-ink-950 px-4 py-2 font-mono text-[10px] uppercase tracking-[0.14em] text-bone-100 transition hover:bg-brass-400 hover:text-ink-950"
          >
            Ir
          </button>
        </div>
      </div>

      <div>
        <p className="eyebrow text-ink-400">Etiquetas</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {tags.map((tag) => {
            const active = activeTags.includes(tag);
            return (
              <button
                key={tag}
                type="button"
                onClick={() =>
                  push((next) => {
                    const current = (next.get("tags") ?? "").split(",").filter(Boolean);
                    const updated = active
                      ? current.filter((item) => item !== tag)
                      : [...current, tag];
                    if (updated.length) next.set("tags", updated.join(","));
                    else next.delete("tags");
                  })
                }
                className={`rounded-full border px-3.5 py-1.5 text-xs transition ${
                  active
                    ? "border-brass-400 bg-brass-100 text-brass-600"
                    : "border-bone-300 text-ink-600 hover:border-ink-900"
                }`}
              >
                {tag}
              </button>
            );
          })}
        </div>
      </div>

      <div className="border-t border-bone-200 pt-6">
        <p className="text-xs leading-relaxed text-ink-600">
          ¿No encuentras el formato exacto? Cotizamos medidas especiales, tirajes altos y acabados
          fuera de catálogo.
        </p>
      </div>
    </div>
  );

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex w-full items-center justify-center gap-2 rounded-sm border border-bone-300 px-5 py-3 font-mono text-[11px] uppercase tracking-[0.18em] text-ink-800 transition hover:border-ink-900 lg:hidden"
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M4 6h16M7 12h10M10 18h4" />
        </svg>
        Filtrar catálogo
      </button>

      <aside className="hidden lg:block">
        <div className="sticky top-28 max-h-[calc(100svh-8rem)] overflow-y-auto pr-2">{body}</div>
      </aside>

      <div
        className={`fixed inset-0 z-80 lg:hidden ${open ? "visible" : "invisible"}`}
        aria-hidden={!open}
      >
        <div
          className={`absolute inset-0 bg-ink-950/70 backdrop-blur-sm transition-opacity duration-300 ${
            open ? "opacity-100" : "opacity-0"
          }`}
          onClick={() => setOpen(false)}
        />
        <div
          className={`absolute inset-x-0 bottom-0 max-h-[88svh] overflow-y-auto rounded-t-2xl bg-bone-50 p-6 transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${
            open ? "translate-y-0" : "translate-y-full"
          }`}
        >
          <div className="mb-6 flex items-center justify-between">
            <p className="display-balance text-xl">Filtrar catálogo</p>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="grid h-10 w-10 place-items-center rounded-full border border-bone-300"
              aria-label="Cerrar filtros"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
          </div>
          {body}
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="mt-8 w-full rounded-sm bg-ink-950 px-6 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-bone-100"
          >
            Ver resultados
          </button>
        </div>
      </div>
    </>
  );
}
