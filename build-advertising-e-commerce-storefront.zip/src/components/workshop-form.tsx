"use client";

import { useState } from "react";

type Option = { slug: string; title: string };

export function WorkshopForm({
  options,
  defaultSlug,
}: {
  options: Option[];
  defaultSlug?: string;
}) {
  const [form, setForm] = useState({
    workshopSlug: defaultSlug ?? options[0]?.slug ?? "",
    name: "",
    email: "",
    phone: "",
    business: "",
    seats: 1,
    notes: "",
  });
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [code, setCode] = useState("");

  const update =
    (key: keyof typeof form) =>
    (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm((current) => ({
        ...current,
        [key]: event.target.value,
      }));

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setState("sending");
    setMessage("");
    try {
      const res = await fetch("/api/talleres", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, seats: Number(form.seats) }),
      });
      const data = (await res.json()) as { code?: string; error?: string };
      if (!res.ok || !data.code) {
        setState("error");
        setMessage(data.error ?? "No pudimos completar tu registro.");
        return;
      }
      setCode(data.code);
      setState("done");
    } catch {
      setState("error");
      setMessage("Error de conexión. Intenta de nuevo o escríbenos por WhatsApp.");
    }
  }

  if (state === "done") {
    return (
      <div className="panel-bevel bg-ink-900/90 p-8">
        <p className="eyebrow text-brass-300">Registro recibido</p>
        <h3 className="display-balance neon-text mt-4 text-3xl">¡Tu lugar está apartado!</h3>
        <p className="mt-4 text-sm leading-relaxed text-bone-300/80">
          Folio de registro: <span className="font-mono text-brass-300">{code}</span>. Te escribiremos
          a <span className="text-bone-100">{form.email}</span> con la confirmación de horario,
          forma de pago y materiales. ¿Prefieres WhatsApp? Respondemos al mensaje de confirmación.
        </p>
        <button
          type="button"
          onClick={() => {
            setState("idle");
            setForm((current) => ({ ...current, name: "", email: "", phone: "", notes: "" }));
          }}
          className="mt-6 rounded-sm border border-brass-400/50 px-6 py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-brass-200 transition hover:bg-brass-300 hover:text-ink-950"
        >
          Registrar a otra persona
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="panel-bevel bg-ink-900/90 p-7 sm:p-9">
      <p className="eyebrow text-brass-300">Aparta tu lugar</p>
      <h3 className="display-balance mt-3 text-2xl leading-snug text-bone-50">
        Registro al taller
      </h3>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <Field span>
          <span className="label">Taller</span>
          <select
            value={form.workshopSlug}
            onChange={update("workshopSlug")}
            className="input"
            required
          >
            {options.map((option) => (
              <option key={option.slug} value={option.slug} className="bg-ink-900">
                {option.title}
              </option>
            ))}
          </select>
        </Field>
        <Field>
          <span className="label">Nombre completo *</span>
          <input value={form.name} onChange={update("name")} className="input" required minLength={2} />
        </Field>
        <Field>
          <span className="label">Correo *</span>
          <input
            type="email"
            value={form.email}
            onChange={update("email")}
            className="input"
            required
          />
        </Field>
        <Field>
          <span className="label">Teléfono / WhatsApp *</span>
          <input
            value={form.phone}
            onChange={update("phone")}
            className="input"
            required
            minLength={6}
          />
        </Field>
        <Field>
          <span className="label">Negocio o empresa</span>
          <input value={form.business} onChange={update("business")} className="input" />
        </Field>
        <Field>
          <span className="label">Lugares</span>
          <select value={form.seats} onChange={update("seats")} className="input">
            {[1, 2, 3, 4, 5].map((value) => (
              <option key={value} value={value} className="bg-ink-900">
                {value}
              </option>
            ))}
          </select>
        </Field>
        <Field span>
          <span className="label">¿Qué te gustaría aprender?</span>
          <textarea
            value={form.notes}
            onChange={update("notes")}
            rows={3}
            className="input resize-none"
            placeholder="Cuéntanos de tu emprendimiento y qué necesitas resolver…"
          />
        </Field>
      </div>

      {message ? (
        <p
          className={`mt-4 font-mono text-[11px] uppercase tracking-[0.14em] ${
            state === "error" ? "text-flame-400" : "text-brass-300"
          }`}
        >
          {message}
        </p>
      ) : null}

      <button
        type="submit"
        disabled={state === "sending"}
        className="mt-6 w-full rounded-sm bg-brass-300 px-6 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-ink-950 transition hover:bg-brass-200 hover:shadow-[0_0_34px_-8px_rgba(168,238,31,0.8)] disabled:opacity-60"
      >
        {state === "sending" ? "Enviando…" : "Quiero mi lugar"}
      </button>
      <p className="mt-3 text-center font-mono text-[10px] uppercase tracking-[0.14em] text-bone-300/50">
        Cupo limitado · Confirmación por correo en menos de 24 h
      </p>

      <style>{`
        .label { font-family: var(--font-mono); font-size: 10px; letter-spacing: .16em; text-transform: uppercase; color: rgba(201,206,227,.7); }
        .input { margin-top: .5rem; width: 100%; border-radius: 4px; border: 1px solid rgba(255,255,255,.14);
          background: rgba(4,6,15,.6); padding: .72rem .9rem; font-size: .875rem; color: #f6f7fb; outline: none;
          transition: border-color .25s, box-shadow .25s; }
        .input::placeholder { color: rgba(201,206,227,.35); }
        .input:focus { border-color: #c6ff4d; box-shadow: 0 0 0 3px rgba(198,255,77,.16); }
      `}</style>
    </form>
  );
}

function Field({
  children,
  span = false,
}: {
  children: React.ReactNode;
  span?: boolean;
}) {
  return <label className={span ? "sm:col-span-2 block" : "block"}>{children}</label>;
}
