"use client";

import { useState } from "react";
import { StarRating } from "@/components/ui";
import { formatDate } from "@/lib/format";
import type { Review } from "@/db/schema";

export function ReviewsSection({
  productSlug,
  reviews,
  ratingAvg,
}: {
  productSlug: string;
  reviews: Review[];
  ratingAvg: number;
}) {
  const [items, setItems] = useState(reviews);
  const [formOpen, setFormOpen] = useState(false);
  const [rating, setRating] = useState(5);
  const [author, setAuthor] = useState("");
  const [role, setRole] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "error">("idle");
  const [message, setMessage] = useState("");

  const average =
    items.length > 0 ? items.reduce((total, item) => total + item.rating, 0) / items.length : ratingAvg / 10;
  const distribution = [5, 4, 3, 2, 1].map((star) => ({
    star,
    total: items.filter((item) => item.rating === star).length,
  }));

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setStatus("sending");
    setMessage("");
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productSlug, author, role, rating, title, body }),
      });
      const data = (await res.json()) as { review?: Review; error?: string };
      if (!res.ok || !data.review) {
        setStatus("error");
        setMessage(data.error ?? "No pudimos publicar tu reseña.");
        return;
      }
      setItems((current) => [data.review as Review, ...current]);
      setAuthor("");
      setRole("");
      setTitle("");
      setBody("");
      setRating(5);
      setStatus("idle");
      setFormOpen(false);
      setMessage("¡Gracias! Tu reseña ya está publicada.");
    } catch {
      setStatus("error");
      setMessage("Error de conexión. Intenta de nuevo.");
    }
  }

  return (
    <section id="resenas" className="grid gap-10 lg:grid-cols-[19rem_1fr] lg:gap-16">
      <div className="lg:sticky lg:top-28 lg:self-start">
        <p className="eyebrow text-iris-600">Reseñas verificadas</p>
        <div className="mt-4 flex items-end gap-3">
          <span className="display-balance text-5xl leading-none">{average.toFixed(1)}</span>
          <div className="pb-1">
            <StarRating value={average} size="md" />
            <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-400">
              {items.length} {items.length === 1 ? "reseña" : "reseñas"}
            </p>
          </div>
        </div>

        <ul className="mt-6 space-y-2">
          {distribution.map((row) => {
            const width = items.length ? (row.total / items.length) * 100 : 0;
            return (
              <li key={row.star} className="flex items-center gap-3">
                <span className="w-8 font-mono text-[10px] text-ink-400">{row.star}★</span>
                <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-bone-200">
                  <span
                    className="block h-full rounded-full bg-brass-400 transition-all duration-700"
                    style={{ width: `${width}%` }}
                  />
                </span>
                <span className="w-6 text-right font-mono text-[10px] text-ink-400">{row.total}</span>
              </li>
            );
          })}
        </ul>

        {formOpen ? (
          <form onSubmit={onSubmit} className="mt-8 space-y-4 rounded-sm border border-bone-300 bg-bone-100 p-5">
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-400">
                Tu calificación
              </p>
              <div className="mt-2 flex gap-1.5">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    aria-label={`${star} estrellas`}
                    className={`text-2xl leading-none transition ${
                      star <= rating ? "text-brass-400" : "text-ink-200"
                    }`}
                  >
                    ★
                  </button>
                ))}
              </div>
            </div>
            <div className="grid gap-3">
              <input
                value={author}
                onChange={(event) => setAuthor(event.target.value)}
                placeholder="Tu nombre"
                required
                minLength={2}
                className="rounded-sm border border-bone-300 bg-bone-50 px-3 py-2.5 text-sm outline-none focus:border-brass-400"
              />
              <input
                value={role}
                onChange={(event) => setRole(event.target.value)}
                placeholder="Empresa o cargo (opcional)"
                className="rounded-sm border border-bone-300 bg-bone-50 px-3 py-2.5 text-sm outline-none focus:border-brass-400"
              />
              <input
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                placeholder="Título de tu reseña"
                required
                minLength={3}
                className="rounded-sm border border-bone-300 bg-bone-50 px-3 py-2.5 text-sm outline-none focus:border-brass-400"
              />
              <textarea
                value={body}
                onChange={(event) => setBody(event.target.value)}
                placeholder="Cuéntanos cómo resultó la producción…"
                required
                minLength={10}
                rows={4}
                className="rounded-sm border border-bone-300 bg-bone-50 px-3 py-2.5 text-sm outline-none focus:border-brass-400"
              />
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                disabled={status === "sending"}
                className="flex-1 rounded-sm bg-ink-950 px-4 py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-bone-100 transition hover:bg-brass-400 hover:text-ink-950 disabled:opacity-60"
              >
                {status === "sending" ? "Publicando…" : "Publicar reseña"}
              </button>
              <button
                type="button"
                onClick={() => setFormOpen(false)}
                className="rounded-sm border border-bone-300 px-4 py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-ink-600"
              >
                Cancelar
              </button>
            </div>
          </form>
        ) : (
          <button
            type="button"
            onClick={() => setFormOpen(true)}
            className="mt-8 w-full rounded-sm border border-ink-900 px-6 py-3.5 font-mono text-[10px] uppercase tracking-[0.18em] text-ink-900 transition hover:bg-ink-950 hover:text-bone-100"
          >
            Escribir una reseña
          </button>
        )}
        {message ? (
          <p
            className={`mt-3 font-mono text-[10px] uppercase tracking-[0.14em] ${
              status === "error" ? "text-flame-500" : "text-brass-600"
            }`}
          >
            {message}
          </p>
        ) : null}
      </div>

      <div>
        {items.length === 0 ? (
          <p className="rounded-sm border border-dashed border-bone-300 p-10 text-center text-sm text-ink-600">
            Aún no hay reseñas de este servicio. Sé el primero en contar cómo resultó.
          </p>
        ) : (
          <ul className="divide-y divide-bone-200">
            {items.map((review) => (
              <li key={review.id} className="py-7 first:pt-0">
                <article>
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="grid h-10 w-10 place-items-center rounded-full bg-ink-950 font-mono text-[11px] text-brass-200">
                        {review.author
                          .split(" ")
                          .map((part) => part[0])
                          .slice(0, 2)
                          .join("")
                          .toUpperCase()}
                      </span>
                      <div>
                        <p className="text-sm text-ink-900">{review.author}</p>
                        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-400">
                          {review.role}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <StarRating value={review.rating} />
                      <p className="mt-1 font-mono text-[10px] text-ink-400">
                        {formatDate(review.createdAt)}
                      </p>
                    </div>
                  </div>
                  <h3 className="display-balance mt-4 text-lg leading-snug">{review.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-600">{review.body}</p>
                  {review.verified ? (
                    <p className="mt-4 inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-brass-600">
                      <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M5 13l4 4L19 7" />
                      </svg>
                      Compra verificada
                    </p>
                  ) : null}
                </article>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
