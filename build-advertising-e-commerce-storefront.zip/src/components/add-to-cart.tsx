"use client";

import { useState } from "react";
import { useCart } from "@/components/cart-provider";

export type AddToCartProduct = {
  slug: string;
  name: string;
  image: string;
  unitLabel: string;
  priceCents: number;
  minQty: number;
};

export function QuickAdd({ product }: { product: AddToCartProduct }) {
  const { addItem } = useCart();
  const [added, setAdded] = useState(false);

  return (
    <button
      type="button"
      onClick={() => {
        addItem(product, product.minQty || 1);
        setAdded(true);
        window.setTimeout(() => setAdded(false), 1600);
      }}
      className="flex w-full items-center justify-center gap-2 bg-ink-950 px-4 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-bone-100 transition hover:bg-brass-400 hover:text-ink-950"
    >
      {added ? (
        <>
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M5 13l4 4L19 7" />
          </svg>
          Agregado
        </>
      ) : (
        "Agregar al carrito"
      )}
    </button>
  );
}

export function AddToCartPanel({ product }: { product: AddToCartProduct }) {
  const { addItem } = useCart();
  const [quantity, setQuantity] = useState(product.minQty || 1);

  const decrement = () => setQuantity((value) => Math.max(product.minQty || 1, value - 1));
  const increment = () => setQuantity((value) => Math.min(999, value + 1));

  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-stretch">
      <div className="flex items-center justify-between rounded-sm border border-bone-300 px-2 py-1 sm:w-40">
        <button
          type="button"
          onClick={decrement}
          className="grid h-10 w-10 place-items-center rounded-sm text-lg text-ink-600 transition hover:bg-bone-100 hover:text-ink-950"
          aria-label="Reducir cantidad"
        >
          −
        </button>
        <span className="font-mono text-sm text-ink-900">{quantity}</span>
        <button
          type="button"
          onClick={increment}
          className="grid h-10 w-10 place-items-center rounded-sm text-lg text-ink-600 transition hover:bg-bone-100 hover:text-ink-950"
          aria-label="Aumentar cantidad"
        >
          +
        </button>
      </div>
      <button
        type="button"
        onClick={() => addItem(product, quantity)}
        className="group flex flex-1 items-center justify-center gap-3 rounded-sm bg-ink-950 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-bone-100 transition hover:bg-brass-400 hover:text-ink-950"
      >
        Agregar al carrito
        <svg
          viewBox="0 0 24 24"
          className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
        >
          <path d="M4 7h16l-1.2 13H5.2L4 7zM9 7V5.4A3 3 0 0 1 12 3a3 3 0 0 1 3 2.4V7" />
        </svg>
      </button>
    </div>
  );
}
