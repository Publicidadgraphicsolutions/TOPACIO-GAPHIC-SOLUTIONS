export function GlobeMark({ size = 44, className = "" }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 140 140"
      className={className}
      role="img"
      aria-label="Publicidad Graphic Solutions"
    >
      <defs>
        <linearGradient id="pgs-orbit" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#c6ff4d" />
          <stop offset="38%" stopColor="#3fd8ff" />
          <stop offset="70%" stopColor="#8b5cf6" />
          <stop offset="100%" stopColor="#ff3da5" />
        </linearGradient>
        <linearGradient id="pgs-globe" x1="12%" y1="0%" x2="88%" y2="100%">
          <stop offset="0%" stopColor="#e0b6cf" />
          <stop offset="34%" stopColor="#b678a2" />
          <stop offset="66%" stopColor="#8d5f8f" />
          <stop offset="100%" stopColor="#c9a06f" />
        </linearGradient>
        <linearGradient id="pgs-chrome" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#f4f6ff" />
          <stop offset="45%" stopColor="#9aa1bd" />
          <stop offset="100%" stopColor="#4d5478" />
        </linearGradient>
        <radialGradient id="pgs-shine" cx="32%" cy="26%" r="72%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.75" />
          <stop offset="55%" stopColor="#ffffff" stopOpacity="0.06" />
          <stop offset="100%" stopColor="#000000" stopOpacity="0.35" />
        </radialGradient>
        <filter id="pgs-glow" x="-60%" y="-60%" width="220%" height="220%">
          <feGaussianBlur stdDeviation="3.4" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* orbit ring behind the sphere */}
      <g filter="url(#pgs-glow)" transform="rotate(-19 70 72)">
        <ellipse
          cx="70"
          cy="72"
          rx="61"
          ry="24"
          fill="none"
          stroke="url(#pgs-orbit)"
          strokeWidth="4.4"
          strokeLinecap="round"
        />
        <ellipse
          cx="70"
          cy="72"
          rx="61"
          ry="24"
          fill="none"
          stroke="#ffffff"
          strokeWidth="1"
          strokeOpacity="0.5"
        />
      </g>

      {/* chrome bezel */}
      <circle cx="70" cy="72" r="44" fill="url(#pgs-chrome)" />
      <circle cx="70" cy="72" r="39" fill="#0b0e22" fillOpacity="0.55" />

      {/* sphere */}
      <circle cx="70" cy="72" r="37" fill="url(#pgs-globe)" />

      {/* continents */}
      <path
        d="M46 61c5-4 11-6 16-4 4 1.6 3.4 5.6 7.6 6.4 4.4.9 7.4-2.6 11.6-1.4 3.6 1 4.4 5 2.6 8.2-2 3.6-6.6 4.4-8.4 8-1.7 3.4.6 7.6-2.4 9.8-3.2 2.4-7.6-.4-11.2-2.6-4-2.4-8.6-4.6-10.4-9-1.8-4.4.4-9.6-.6-14-.8-3.6-3-5.4-4.8-8.4z"
        fill="#3f2540"
        fillOpacity="0.62"
      />
      <path
        d="M84 55c4.6 1.2 9.6 2.2 12.6 6 2.6 3.3 2 8.2.4 12.2-1.6 4-4.6 7.6-8.4 9.4-3.4 1.6-7.4.6-10.4-1.8-3.2-2.6-4.4-7-3.6-11.2.8-4.4 3.6-8.2 4.6-12.6.7-3.2 2.2-7 4.8-8.9z"
        fill="#efe0d0"
        fillOpacity="0.6"
      />

      {/* meridians + parallels */}
      <g stroke="#2b1830" strokeOpacity="0.45" fill="none" strokeWidth="1.1">
        <ellipse cx="70" cy="72" rx="13" ry="37" />
        <ellipse cx="70" cy="72" rx="26" ry="37" />
        <path d="M33 72h74" />
        <path d="M37.5 55c9-5.4 19-8 32.5-8s23.5 2.6 32.5 8" />
        <path d="M37.5 89c9 5.4 19 8 32.5 8s23.5-2.6 32.5-8" />
      </g>

      {/* sphere shading + highlight */}
      <circle cx="70" cy="72" r="37" fill="url(#pgs-shine)" style={{ mixBlendMode: "overlay" }} />
      <circle
        cx="70"
        cy="72"
        r="37"
        fill="none"
        stroke="#ffffff"
        strokeOpacity="0.35"
        strokeWidth="1.2"
      />

      {/* orbit segment in front */}
      <g filter="url(#pgs-glow)" transform="rotate(-19 70 72)">
        <path
          d="M11 72a61 24 0 0 0 118 0"
          fill="none"
          stroke="url(#pgs-orbit)"
          strokeWidth="4.6"
          strokeLinecap="round"
        />
      </g>

      {/* satellites */}
      <circle cx="122" cy="44" r="5.4" fill="#ff3da5" />
      <circle cx="120.4" cy="42.4" r="1.7" fill="#ffffff" fillOpacity="0.85" />
      <circle cx="30" cy="103" r="4.6" fill="#3fd8ff" />
      <circle cx="28.7" cy="101.8" r="1.5" fill="#ffffff" fillOpacity="0.85" />
      <circle cx="118" cy="106" r="3.6" fill="#c6ff4d" />
      <circle cx="117.1" cy="105.2" r="1.2" fill="#ffffff" fillOpacity="0.8" />
    </svg>
  );
}

export function Wordmark({ compact = false }: { compact?: boolean }) {
  return (
    <span className="flex flex-col leading-none">
      <span
        className="neon-text block font-display font-black uppercase tracking-tight"
        style={{ fontSize: compact ? "1.02rem" : "1.35rem", letterSpacing: "0.02em" }}
      >
        Graphic
      </span>
      <span
        className="mt-0.5 block font-display italic text-iris-300"
        style={{ fontSize: compact ? "0.78rem" : "0.95rem", letterSpacing: "0.06em" }}
      >
        Solutions
      </span>
    </span>
  );
}

export function BrandLockup({ size = 44, compact = false }: { size?: number; compact?: boolean }) {
  return (
    <span className="flex items-center gap-3">
      <GlobeMark size={size} />
      <Wordmark compact={compact} />
    </span>
  );
}
