"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { useCart } from "@/components/cart-provider";
import { BrandLockup } from "@/components/brand";

type NavCategory = { slug: string; name: string; tagline: string; icon: string };

type SearchHit = {
  slug: string;
  name: string;
  priceCents: number;
  image: string;
  category: string;
};

export function SiteHeader({
  categories,
  settings,
}: {
  categories: NavCategory[];
  settings: Record<string, string>;
}) {
  const { count, openCart, hydrated } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [loadingHits, setLoadingHits] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const pathname = usePathname();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    setSearchOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (searchOpen) {
      const timer = window.setTimeout(() => inputRef.current?.focus(), 120);
      return () => window.clearTimeout(timer);
    }
    return;
  }, [searchOpen]);

  useEffect(() => {
    if (!searchOpen) return;
    const term = query.trim();
    if (term.length < 2) {
      setHits([]);
      return;
    }
    setLoadingHits(true);
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      try {
        const res = await fetch(`/api/products?q=${encodeURIComponent(term)}&limit=6`, {
          signal: controller.signal,
        });
        const data = (await res.json()) as { products: SearchHit[] };
        setHits(data.products ?? []);
      } catch {
        /* aborted */
      } finally {
        setLoadingHits(false);
      }
    }, 260);
    return () => {
      controller.abort();
      window.clearTimeout(timer);
    };
  }, [query, searchOpen]);

  return (
    <>
      <div className="relative overflow-hidden bg-ink-950 py-2.5 text-bone-200">
        <div className="animate-marquee flex w-max gap-10 whitespace-nowrap font-mono text-[10px] uppercase tracking-[0.3em]">
          {[0, 1].map((dup) => (
            <div key={dup} className="flex gap-10">
              {[
                "Papelería comercial",
                "Material P.O.P.",
                "Diseño gráfico",
                "BTL & activaciones",
                "Material audiovisual UGC",
                "Modelaje & talento",
                "Producción en 48 h",
                "Facturación CFDI 4.0",
              ].map((item) => (
                <span key={`${dup}-${item}`} className="flex items-center gap-10">
                  {item}
                  <span className="text-brass-400">✦</span>
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      <header
        className={`sticky top-0 z-60 border-b transition-all duration-500 ${
          scrolled
            ? "border-bone-200 bg-bone-50/90 py-3 backdrop-blur-xl"
            : "border-transparent bg-bone-50 py-5"
        }`}
      >
        <div className="mx-auto flex max-w-[88rem] items-center gap-4 px-5 sm:px-8">
          <Link href="/" className="group flex items-center gap-3">
            <span className="transition-transform duration-500 group-hover:rotate-[8deg]">
              <BrandLockup size={46} compact />
            </span>
            <span className="hidden font-mono text-[9px] uppercase leading-tight tracking-[0.26em] text-ink-400 xl:block">
              {settings.brandName}
            </span>
          </Link>

          <nav className="ml-6 hidden items-center gap-7 lg:flex">
            <Link
              href="/tienda"
              className="group relative text-sm text-ink-700 transition hover:text-ink-950"
            >
              Catálogo
              <span className="absolute -bottom-1 left-0 h-px w-0 bg-brass-400 transition-all duration-300 group-hover:w-full" />
            </Link>
            <Link
              href="/talleres"
              className="group relative text-sm font-medium text-iris-600 transition hover:text-flame-500"
            >
              Talleres
              <span className="absolute -bottom-1 left-0 h-px w-0 bg-gradient-to-r from-brass-400 to-flame-400 transition-all duration-300 group-hover:w-full" />
            </Link>
            <div className="group relative">
              <button
                type="button"
                className="flex items-center gap-1.5 text-sm text-ink-700 transition hover:text-ink-950"
              >
                Servicios
                <svg viewBox="0 0 24 24" className="h-3 w-3 transition-transform group-hover:rotate-180" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M6 9l6 6 6-6" />
                </svg>
              </button>
              <div className="invisible absolute left-1/2 top-full w-[34rem] -translate-x-1/2 translate-y-3 pt-4 opacity-0 transition-all duration-300 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">
                <div className="grid grid-cols-2 gap-1 rounded-sm border border-bone-200 bg-bone-50 p-3 shadow-[0_30px_60px_-30px_rgba(12,12,17,0.4)]">
                  {categories.map((category) => (
                    <Link
                      key={category.slug}
                      href={`/tienda?categoria=${category.slug}`}
                      className="group/item flex gap-3 rounded-sm p-3 transition hover:bg-ink-950 hover:text-bone-100"
                    >
                      <span className="mt-0.5 text-iris-600 group-hover/item:text-brass-300">{category.icon}</span>
                      <span>
                        <span className="block text-sm">{category.name}</span>
                        <span className="mt-0.5 block text-xs text-ink-400 group-hover/item:text-bone-300/70">
                          {category.tagline}
                        </span>
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
            <Link href="/#proceso" className="group relative text-sm text-ink-700 transition hover:text-ink-950">
              Proceso
              <span className="absolute -bottom-1 left-0 h-px w-0 bg-brass-500 transition-all duration-300 group-hover:w-full" />
            </Link>
            <Link href="/#cotizacion" className="group relative text-sm text-ink-700 transition hover:text-ink-950">
              Cotización
              <span className="absolute -bottom-1 left-0 h-px w-0 bg-brass-500 transition-all duration-300 group-hover:w-full" />
            </Link>
          </nav>

          <div className="ml-auto flex items-center gap-2">
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              aria-label="Buscar productos"
              className="grid h-11 w-11 place-items-center rounded-full border border-transparent text-ink-700 transition hover:border-bone-300 hover:text-ink-950"
            >
              <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth="1.6">
                <circle cx="11" cy="11" r="7" />
                <path d="M20 20l-3.6-3.6" />
              </svg>
            </button>
            <Link
              href="/checkout"
              aria-label="Ir al checkout"
              className="hidden h-11 w-11 place-items-center rounded-full border border-transparent text-ink-700 transition hover:border-bone-300 hover:text-ink-950 sm:grid"
            >
              <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M4 7h16l-1.2 13H5.2L4 7zM9 7V5.4A3 3 0 0 1 12 3a3 3 0 0 1 3 2.4V7" />
              </svg>
            </Link>
            <button
              type="button"
              onClick={openCart}
              className="group relative flex items-center gap-2.5 rounded-full bg-ink-950 py-2.5 pl-4 pr-5 text-bone-100 transition hover:bg-ink-800"
            >
              <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M4 7h16l-1.2 13H5.2L4 7zM9 7V5.4A3 3 0 0 1 12 3a3 3 0 0 1 3 2.4V7" />
              </svg>
              <span className="font-mono text-xs">
                {hydrated ? String(count).padStart(2, "0") : "00"}
              </span>
            </button>
            <button
              type="button"
              onClick={() => setMenuOpen(true)}
              aria-label="Abrir menú"
              className="grid h-11 w-11 place-items-center rounded-full border border-bone-300 text-ink-900 lg:hidden"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M4 7h16M4 12h16M4 17h16" />
              </svg>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <div
        className={`fixed inset-0 z-80 bg-ink-950 text-bone-100 transition-all duration-500 lg:hidden ${
          menuOpen ? "visible opacity-100" : "invisible opacity-0"
        }`}
      >
        <div className="flex h-full flex-col p-6">
          <div className="flex items-center justify-between">
            <BrandLockup size={44} compact />
            <button
              type="button"
              onClick={() => setMenuOpen(false)}
              aria-label="Cerrar menú"
              className="grid h-11 w-11 place-items-center rounded-full border border-bone-100/20"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.6">
                <path d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
          </div>
          <nav className="mt-10 flex-1 space-y-1 overflow-y-auto">
            <Link href="/tienda" className="block border-b border-bone-100/10 py-4 text-2xl">
              Todo el catálogo
            </Link>
            <Link
              href="/talleres"
              className="flex items-center justify-between border-b border-bone-100/10 py-4 text-2xl text-brass-300"
            >
              Talleres para emprender
              <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-flame-400">
                Nuevo
              </span>
            </Link>
            {categories.map((category) => (
              <Link
                key={category.slug}
                href={`/tienda?categoria=${category.slug}`}
                className="flex items-center gap-4 border-b border-bone-100/10 py-4"
              >
                <span className="text-brass-300">{category.icon}</span>
                <span className="flex-1">
                  <span className="block text-lg">{category.name}</span>
                  <span className="text-xs text-bone-300/60">{category.tagline}</span>
                </span>
              </Link>
            ))}
          </nav>
          <Link
            href="/checkout"
            className="mt-6 rounded-sm bg-brass-300 px-6 py-4 text-center font-mono text-[11px] uppercase tracking-[0.22em] text-ink-950"
          >
            Finalizar compra
          </Link>
        </div>
      </div>

      {/* Search overlay */}
      <div
        className={`fixed inset-0 z-90 transition-all duration-400 ${
          searchOpen ? "visible opacity-100" : "invisible opacity-0"
        }`}
      >
        <div className="absolute inset-0 bg-ink-950/80 backdrop-blur-md" onClick={() => setSearchOpen(false)} />
        <div
          className={`relative mx-auto mt-[12vh] w-[92%] max-w-3xl rounded-sm border border-bone-200 bg-bone-50 p-6 shadow-2xl transition-all duration-500 ${
            searchOpen ? "translate-y-0" : "-translate-y-6"
          }`}
        >
          <label className="flex items-center gap-3 border-b border-bone-200 pb-4">
            <svg viewBox="0 0 24 24" className="h-5 w-5 text-ink-400" fill="none" stroke="currentColor" strokeWidth="1.6">
              <circle cx="11" cy="11" r="7" />
              <path d="M20 20l-3.6-3.6" />
            </svg>
            <input
              ref={inputRef}
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Buscar tarjetas, exhibidores, UGC, modelaje…"
              className="w-full bg-transparent text-lg outline-none placeholder:text-ink-400"
            />
            <button
              type="button"
              onClick={() => setSearchOpen(false)}
              className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-400 transition hover:text-ink-900"
            >
              Esc
            </button>
          </label>

          <div className="mt-4 max-h-[52vh] overflow-y-auto">
            {query.trim().length < 2 ? (
              <div className="flex flex-wrap gap-2">
                {["tarjetas", "exhibidor", "ugc", "branding", "lona", "modelaje", "packaging"].map((term) => (
                  <button
                    key={term}
                    type="button"
                    onClick={() => setQuery(term)}
                    className="rounded-full border border-bone-300 px-4 py-1.5 text-xs text-ink-600 transition hover:border-ink-900 hover:text-ink-900"
                  >
                    {term}
                  </button>
                ))}
              </div>
            ) : loadingHits && hits.length === 0 ? (
              <p className="py-6 font-mono text-xs uppercase tracking-[0.2em] text-ink-400">Buscando…</p>
            ) : hits.length === 0 ? (
              <p className="py-6 text-sm text-ink-600">
                Sin resultados para “{query}”. Escríbenos y lo cotizamos a medida.
              </p>
            ) : (
              <ul className="divide-y divide-bone-200">
                {hits.map((hit) => (
                  <li key={hit.slug}>
                    <Link
                      href={`/producto/${hit.slug}`}
                      onClick={() => setSearchOpen(false)}
                      className="group flex items-center gap-4 py-3"
                    >
                      <span className="relative h-14 w-12 overflow-hidden rounded-sm bg-bone-200">
                        <Image src={hit.image} alt={hit.name} fill sizes="48px" className="object-cover" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm group-hover:text-brass-600">{hit.name}</span>
                        <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-400">
                          {hit.category}
                        </span>
                      </span>
                      <span className="font-mono text-xs text-ink-700">
                        ${(hit.priceCents / 100).toLocaleString("es-MX")}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
