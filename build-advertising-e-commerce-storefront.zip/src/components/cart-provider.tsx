"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { computeTotals } from "@/lib/format";

export type CartLine = {
  slug: string;
  name: string;
  image: string;
  unitLabel: string;
  priceCents: number;
  minQty: number;
  quantity: number;
};

type CartContextValue = {
  items: CartLine[];
  count: number;
  subtotalCents: number;
  totals: ReturnType<typeof computeTotals>;
  deliveryMethod: "recoger" | "enviar";
  isOpen: boolean;
  hydrated: boolean;
  lastAdded: string | null;
  openCart: () => void;
  closeCart: () => void;
  addItem: (line: Omit<CartLine, "quantity">, quantity?: number) => void;
  setQuantity: (slug: string, quantity: number) => void;
  removeItem: (slug: string) => void;
  clear: () => void;
  setDeliveryMethod: (method: "recoger" | "enviar") => void;
};

const STORAGE_KEY = "pgs-cart-v1";

const CartContext = createContext<CartContextValue | null>(null);

function readStorage(): CartLine[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as CartLine[];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (line) => typeof line?.slug === "string" && typeof line?.priceCents === "number",
    );
  } catch {
    return [];
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartLine[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [lastAdded, setLastAdded] = useState<string | null>(null);
  const [deliveryMethod, setDeliveryMethod] = useState<"recoger" | "enviar">("enviar");

  useEffect(() => {
    setItems(readStorage());
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, [items, hydrated]);

  useEffect(() => {
    if (!isOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [isOpen]);

  useEffect(() => {
    if (!lastAdded) return;
    const timer = window.setTimeout(() => setLastAdded(null), 2600);
    return () => window.clearTimeout(timer);
  }, [lastAdded]);

  const addItem = useCallback((line: Omit<CartLine, "quantity">, quantity = 1) => {
    setItems((current) => {
      const existing = current.find((item) => item.slug === line.slug);
      const step = Math.max(1, quantity);
      if (existing) {
        return current.map((item) =>
          item.slug === line.slug
            ? { ...item, quantity: Math.min(999, item.quantity + step) }
            : item,
        );
      }
      return [...current, { ...line, quantity: Math.max(line.minQty || 1, step) }];
    });
    setLastAdded(line.slug);
    setIsOpen(true);
  }, []);

  const setQuantity = useCallback((slug: string, quantity: number) => {
    setItems((current) =>
      current
        .map((item) =>
          item.slug === slug
            ? { ...item, quantity: Math.max(0, Math.min(999, Math.round(quantity))) }
            : item,
        )
        .filter((item) => item.quantity > 0),
    );
  }, []);

  const removeItem = useCallback((slug: string) => {
    setItems((current) => current.filter((item) => item.slug !== slug));
  }, []);

  const clear = useCallback(() => setItems([]), []);

  const value = useMemo<CartContextValue>(() => {
    const subtotalCents = items.reduce(
      (total, item) => total + item.priceCents * item.quantity,
      0,
    );
    return {
      items,
      count: items.reduce((total, item) => total + item.quantity, 0),
      subtotalCents,
      totals: computeTotals(subtotalCents, deliveryMethod),
      deliveryMethod,
      isOpen,
      hydrated,
      lastAdded,
      openCart: () => setIsOpen(true),
      closeCart: () => setIsOpen(false),
      addItem,
      setQuantity,
      removeItem,
      clear,
      setDeliveryMethod,
    };
  }, [
    items,
    isOpen,
    hydrated,
    lastAdded,
    deliveryMethod,
    addItem,
    setQuantity,
    removeItem,
    clear,
  ]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used inside CartProvider");
  return context;
}
