export type SortKey =
  | "destacados"
  | "precio-asc"
  | "precio-desc"
  | "mejor-calificados"
  | "recientes"
  | "populares";

export const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: "destacados", label: "Destacados" },
  { value: "populares", label: "Más vendidos" },
  { value: "mejor-calificados", label: "Mejor calificados" },
  { value: "precio-asc", label: "Precio: menor a mayor" },
  { value: "precio-desc", label: "Precio: mayor a menor" },
  { value: "recientes", label: "Novedades" },
];
