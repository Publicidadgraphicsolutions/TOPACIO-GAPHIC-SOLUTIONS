import { and, asc, desc, eq, gte, ilike, inArray, lte, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureSeeded } from "@/db/seed";
import type { SortKey } from "@/lib/sort";
import {
  categories,
  orderItems,
  orders,
  products,
  reviews,
  subscribers,
  type Category,
  type Order,
  type OrderItem,
  type Product,
  type Review,
} from "@/db/schema";

export type { SortKey } from "@/lib/sort";

export type ProductFilters = {
  category?: string;
  q?: string;
  tags?: string[];
  minPrice?: number;
  maxPrice?: number;
  sort?: SortKey;
  featuredOnly?: boolean;
  bestsellerOnly?: boolean;
  limit?: number;
};

export async function getCategories(): Promise<Category[]> {
  await ensureSeeded();
  return db.select().from(categories).orderBy(asc(categories.position));
}

export async function getCategoryFacets(): Promise<
  { slug: string; name: string; total: number }[]
> {
  await ensureSeeded();
  const rows = await db
    .select({
      slug: products.categorySlug,
      total: sql<number>`cast(count(*) as int)`,
    })
    .from(products)
    .groupBy(products.categorySlug);

  const cats = await getCategories();
  return cats.map((category) => ({
    slug: category.slug,
    name: category.name,
    total: rows.find((row) => row.slug === category.slug)?.total ?? 0,
  }));
}

export async function getAllTags(): Promise<string[]> {
  await ensureSeeded();
  const rows = await db
    .select({ tag: sql<string>`jsonb_array_elements_text(${products.tags})` })
    .from(products);
  const counts = new Map<string, number>();
  for (const row of rows) {
    counts.set(row.tag, (counts.get(row.tag) ?? 0) + 1);
  }
  return [...counts.entries()]
    .filter(([, total]) => total >= 2)
    .sort((a, b) => b[1] - a[1])
    .map(([tag]) => tag)
    .slice(0, 14);
}

export async function getPriceBounds(): Promise<{ min: number; max: number }> {
  await ensureSeeded();
  const [row] = await db
    .select({
      min: sql<number>`cast(coalesce(min(${products.priceCents}), 0) as int)`,
      max: sql<number>`cast(coalesce(max(${products.priceCents}), 0) as int)`,
    })
    .from(products);
  return {
    min: Math.floor((row?.min ?? 0) / 100),
    max: Math.ceil((row?.max ?? 100000) / 100),
  };
}

function buildProductWhere(filters: ProductFilters) {
  const clauses = [];
  if (filters.category) clauses.push(eq(products.categorySlug, filters.category));
  if (filters.featuredOnly) clauses.push(eq(products.isFeatured, true));
  if (filters.bestsellerOnly) clauses.push(eq(products.isBestseller, true));
  if (typeof filters.minPrice === "number") {
    clauses.push(gte(products.priceCents, Math.round(filters.minPrice * 100)));
  }
  if (typeof filters.maxPrice === "number") {
    clauses.push(lte(products.priceCents, Math.round(filters.maxPrice * 100)));
  }
  if (filters.tags && filters.tags.length > 0) {
    const tagClauses = filters.tags.map(
      (tag) =>
        sql`${products.tags} @> ${JSON.stringify([tag])}::jsonb`,
    );
    const combined = tagClauses.length === 1 ? tagClauses[0] : or(...tagClauses);
    if (combined) clauses.push(combined);
  }
  if (filters.q) {
    const pattern = `%${filters.q}%`;
    const search = or(
      ilike(products.name, pattern),
      ilike(products.shortDescription, pattern),
      ilike(products.description, pattern),
      sql`${products.tags}::text ilike ${pattern}`,
      ilike(products.sku, pattern),
    );
    if (search) clauses.push(search);
  }
  return clauses.length > 0 ? and(...clauses) : undefined;
}

function buildProductOrder(sort: SortKey | undefined) {
  switch (sort) {
    case "precio-asc":
      return [asc(products.priceCents)];
    case "precio-desc":
      return [desc(products.priceCents)];
    case "mejor-calificados":
      return [desc(products.ratingAvg), desc(products.reviewCount)];
    case "recientes":
      return [desc(products.createdAt)];
    case "populares":
      return [desc(products.isBestseller), desc(products.reviewCount)];
    default:
      return [desc(products.isFeatured), desc(products.ratingAvg)];
  }
}

export async function getProducts(filters: ProductFilters = {}): Promise<Product[]> {
  await ensureSeeded();
  const query = db
    .select()
    .from(products)
    .where(buildProductWhere(filters))
    .orderBy(...buildProductOrder(filters.sort));

  if (filters.limit) return query.limit(filters.limit);
  return query;
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  await ensureSeeded();
  const [product] = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  return product ?? null;
}

export async function getProductsBySlugs(slugs: string[]): Promise<Product[]> {
  if (slugs.length === 0) return [];
  await ensureSeeded();
  return db.select().from(products).where(inArray(products.slug, slugs));
}

export async function getRelatedProducts(product: Product, limit = 4): Promise<Product[]> {
  await ensureSeeded();
  const sameCategory = await db
    .select()
    .from(products)
    .where(and(eq(products.categorySlug, product.categorySlug)))
    .orderBy(desc(products.ratingAvg))
    .limit(limit + 1);

  const filtered = sameCategory.filter((item) => item.slug !== product.slug);
  if (filtered.length >= limit) return filtered.slice(0, limit);

  const extras = await db
    .select()
    .from(products)
    .where(eq(products.isFeatured, true))
    .orderBy(desc(products.reviewCount))
    .limit(limit + 2);

  const seen = new Set([product.slug, ...filtered.map((item) => item.slug)]);
  for (const extra of extras) {
    if (filtered.length >= limit) break;
    if (!seen.has(extra.slug)) {
      filtered.push(extra);
      seen.add(extra.slug);
    }
  }
  return filtered.slice(0, limit);
}

export async function getReviewsForProduct(slug: string): Promise<Review[]> {
  await ensureSeeded();
  return db
    .select()
    .from(reviews)
    .where(eq(reviews.productSlug, slug))
    .orderBy(desc(reviews.createdAt));
}

export async function getTopReviews(limit = 6): Promise<Review[]> {
  await ensureSeeded();
  return db
    .select()
    .from(reviews)
    .where(gte(reviews.rating, 5))
    .orderBy(desc(reviews.createdAt))
    .limit(limit);
}

export async function createReview(input: {
  productSlug: string;
  author: string;
  role: string;
  rating: number;
  title: string;
  body: string;
}): Promise<Review> {
  await ensureSeeded();
  const [created] = await db
    .insert(reviews)
    .values({
      productSlug: input.productSlug,
      author: input.author,
      role: input.role || "Cliente verificado",
      rating: Math.min(5, Math.max(1, Math.round(input.rating))),
      title: input.title,
      body: input.body,
      verified: false,
    })
    .returning();

  const [agg] = await db
    .select({
      avg: sql<number>`cast(coalesce(avg(${reviews.rating}), 5) * 10 as int)`,
      total: sql<number>`cast(count(*) as int)`,
    })
    .from(reviews)
    .where(eq(reviews.productSlug, input.productSlug));

  await db
    .update(products)
    .set({
      ratingAvg: agg?.avg ?? 50,
      reviewCount: agg?.total ?? 0,
    })
    .where(eq(products.slug, input.productSlug));

  return created;
}

export type CheckoutItem = { slug: string; quantity: number };

export async function createOrder(input: {
  customerName: string;
  email: string;
  phone: string;
  company?: string;
  taxId?: string;
  deliveryMethod: "recoger" | "enviar";
  addressLine?: string;
  city?: string;
  state?: string;
  postalCode?: string;
  notes?: string;
  paymentMethod: string;
  items: CheckoutItem[];
}): Promise<{ order: Order; items: OrderItem[] }> {
  await ensureSeeded();
  const slugs = input.items.map((item) => item.slug);
  const catalog = await getProductsBySlugs(slugs);
  const bySlug = new Map(catalog.map((product) => [product.slug, product]));

  const lines = input.items
    .map((item) => {
      const product = bySlug.get(item.slug);
      if (!product) return null;
      const quantity = Math.max(product.minQty, Math.min(999, Math.round(item.quantity)));
      return { product, quantity };
    })
    .filter((line): line is { product: Product; quantity: number } => line !== null);

  if (lines.length === 0) {
    throw new Error("EMPTY_CART");
  }

  const subtotalCents = lines.reduce(
    (total, line) => total + line.product.priceCents * line.quantity,
    0,
  );
  const shippingCents =
    input.deliveryMethod === "enviar" ? (subtotalCents >= 1500000 ? 0 : 24900) : 0;
  const taxCents = Math.round((subtotalCents + shippingCents) * 0.16);
  const totalCents = subtotalCents + shippingCents + taxCents;

  const orderNumber = `PGS-${Date.now().toString(36).toUpperCase().slice(-5)}${Math.floor(
    Math.random() * 900 + 100,
  )}`;

  const [order] = await db
    .insert(orders)
    .values({
      orderNumber,
      customerName: input.customerName,
      email: input.email,
      phone: input.phone,
      company: input.company ?? null,
      taxId: input.taxId ?? null,
      deliveryMethod: input.deliveryMethod,
      addressLine: input.addressLine ?? null,
      city: input.city ?? null,
      state: input.state ?? null,
      postalCode: input.postalCode ?? null,
      notes: input.notes ?? null,
      paymentMethod: input.paymentMethod,
      subtotalCents,
      shippingCents,
      taxCents,
      totalCents,
      status: "recibido",
    })
    .returning();

  const items = await db
    .insert(orderItems)
    .values(
      lines.map((line) => ({
        orderNumber,
        productSlug: line.product.slug,
        productName: line.product.name,
        unitPriceCents: line.product.priceCents,
        quantity: line.quantity,
      })),
    )
    .returning();

  return { order, items };
}

export async function getOrderByNumber(
  orderNumber: string,
): Promise<{ order: Order; items: OrderItem[] } | null> {
  const [order] = await db
    .select()
    .from(orders)
    .where(eq(orders.orderNumber, orderNumber))
    .limit(1);
  if (!order) return null;
  const items = await db
    .select()
    .from(orderItems)
    .where(eq(orderItems.orderNumber, orderNumber));
  return { order, items };
}

export async function subscribe(email: string) {
  await ensureSeeded();
  await db.insert(subscribers).values({ email }).onConflictDoNothing();
}

/* ---------------- Settings (editable from /admin) ---------------- */

import { siteSettings, workshops, workshopRegistrations, type Workshop } from "@/db/schema";
import { defaultSettings } from "@/data/workshops";

export async function getSettings(): Promise<Record<string, string>> {
  await ensureSeeded();
  const rows = await db.select().from(siteSettings);
  const merged: Record<string, string> = { ...defaultSettings };
  for (const row of rows) {
    if (typeof row.value === "string") merged[row.key] = row.value;
  }
  return merged;
}

export async function saveSettings(entries: Record<string, string>) {
  await ensureSeeded();
  const values = Object.entries(entries)
    .filter(([key]) => key.trim().length > 0)
    .map(([key, value]) => ({ key, value }));
  if (values.length === 0) return;
  await db.insert(siteSettings).values(values).onConflictDoUpdate({
    target: siteSettings.key,
    set: { value: sql`excluded.value`, updatedAt: new Date() },
  });
}

/* ---------------- Workshops ---------------- */

export async function getWorkshops(): Promise<Workshop[]> {
  await ensureSeeded();
  return db.select().from(workshops).orderBy(asc(workshops.position));
}

export async function getWorkshopBySlug(slug: string): Promise<Workshop | null> {
  await ensureSeeded();
  const [row] = await db.select().from(workshops).where(eq(workshops.slug, slug)).limit(1);
  return row ?? null;
}

export async function createWorkshop(input: Omit<Workshop, "id" | "createdAt">) {
  await ensureSeeded();
  const [row] = await db.insert(workshops).values(input).returning();
  return row;
}

export async function updateWorkshop(id: number, input: Partial<Omit<Workshop, "id" | "createdAt">>) {
  await ensureSeeded();
  const [row] = await db.update(workshops).set(input).where(eq(workshops.id, id)).returning();
  return row ?? null;
}

export async function deleteWorkshop(id: number) {
  await ensureSeeded();
  await db.delete(workshops).where(eq(workshops.id, id));
}

export async function registerWorkshop(input: {
  workshopSlug: string;
  name: string;
  email: string;
  phone: string;
  business?: string;
  seats?: number;
  notes?: string;
}) {
  await ensureSeeded();
  const code = `TLL-${Date.now().toString(36).toUpperCase().slice(-5)}${Math.floor(
    Math.random() * 90 + 10,
  )}`;
  const [row] = await db
    .insert(workshopRegistrations)
    .values({
      code,
      workshopSlug: input.workshopSlug,
      name: input.name,
      email: input.email,
      phone: input.phone,
      business: input.business ?? null,
      seats: Math.max(1, Math.min(20, Math.round(input.seats ?? 1))),
      notes: input.notes ?? null,
    })
    .returning();
  return row;
}

export async function getRegistrations() {
  await ensureSeeded();
  return db
    .select()
    .from(workshopRegistrations)
    .orderBy(desc(workshopRegistrations.createdAt))
    .limit(100);
}
