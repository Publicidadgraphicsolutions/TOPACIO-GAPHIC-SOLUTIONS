const money = new Intl.NumberFormat("es-MX", {
  style: "currency",
  currency: "MXN",
  maximumFractionDigits: 0,
});

export function formatMoney(cents: number) {
  return money.format(Math.round(cents) / 100);
}

export function formatCompactMoney(cents: number) {
  const value = Math.round(cents) / 100;
  if (value >= 1000) {
    return `$${new Intl.NumberFormat("es-MX", { maximumFractionDigits: 0 }).format(value)}`;
  }
  return money.format(value);
}

export function formatDate(value: Date | string) {
  const date = typeof value === "string" ? new Date(value) : value;
  return new Intl.DateTimeFormat("es-MX", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(date);
}

export function ratingLabel(ratingAvg: number) {
  return (ratingAvg / 10).toFixed(1);
}

export const TAX_RATE = 0.16;
export const SHIPPING_FLAT_CENTS = 24900;
export const FREE_SHIPPING_THRESHOLD_CENTS = 1500000;

export function computeTotals(subtotalCents: number, deliveryMethod: "recoger" | "enviar") {
  const shippingCents =
    deliveryMethod === "enviar" && subtotalCents < FREE_SHIPPING_THRESHOLD_CENTS
      ? SHIPPING_FLAT_CENTS
      : 0;
  const taxCents = Math.round((subtotalCents + shippingCents) * TAX_RATE);
  return { subtotalCents, shippingCents, taxCents, totalCents: subtotalCents + shippingCents + taxCents };
}
