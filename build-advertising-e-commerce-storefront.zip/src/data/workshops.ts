export type SeedWorkshop = {
  slug: string;
  title: string;
  level: string;
  modality: string;
  duration: string;
  priceCents: number;
  seats: number;
  summary: string;
  description: string;
  modules: string[];
  outcomes: string[];
  icon: string;
  position: number;
  isCustom: boolean;
};

export const seedWorkshops: SeedWorkshop[] = [
  {
    slug: "publicidad-desde-cero-para-emprender",
    title: "Publicidad desde cero para emprender",
    level: "Inicial",
    modality: "Presencial o en vivo por Zoom",
    duration: "8 horas · 2 sesiones",
    priceCents: 240000,
    seats: 14,
    summary:
      "Entiende qué es la publicidad, cómo funciona y cómo usarla con poco presupuesto para que tu negocio se vea y se venda.",
    description:
      "El taller con el que dejamos de adivinar. Salimos de la intuición y construimos una mini estrategia publicitaria para tu negocio: a quién le hablas, qué le dices, con qué piezas y con cuánto dinero. Todo con ejemplos reales del taller y plantillas listas para usar.",
    modules: [
      "Qué es publicidad y qué es marketing (y por qué se confunden)",
      "Conocer a tu cliente: investigación rápida sin agencias",
      "Mensaje, propuesta de valor y llamado a la acción",
      "Presupuesto realista: cuánto gastar y en qué",
      "Medios: impresos, punto de venta, redes y pauta",
      "Cómo medir sin caer en métricas de vanidad",
    ],
    outcomes: [
      "Tu público definido en una ficha de cliente ideal",
      "Un mensaje publicitario probado con 3 variantes",
      "Un presupuesto mensual armado con prioridades",
      "Calendario de 30 días de piezas a publicar",
    ],
    icon: "◉",
    position: 1,
    isCustom: false,
  },
  {
    slug: "marketing-digital-basico-redes-que-venden",
    title: "Marketing digital básico: redes que venden",
    level: "Inicial",
    modality: "En vivo por Zoom",
    duration: "6 horas · 2 sesiones",
    priceCents: 198000,
    seats: 16,
    summary:
      "Arma el perfil de negocio, el contenido y la medición mínima para vender en Instagram, Facebook y WhatsApp sin gastar en publicidad.",
    description:
      "Dejamos de publicar por publicar. Configuramos tu perfil comercial, definimos la pestaña de servicios, armamos un calendario editorial y aprendemos a leer los números que sí importan: alcance de cuenta, mensajes recibidos y cierres.",
    modules: [
      "Perfil de negocio bien configurado y qué sí sirve",
      "Pestaña de servicios, catálogo y catálogo de WhatsApp",
      "Calendario editorial de 30 días con pilares de contenido",
      "Formatos: post, historia, reel y carrusel para cada etapa",
      "Interpretación de métricas y reporte simple en hoja de cálculo",
      "Errores que matan cuentas pequeñas",
    ],
    outcomes: [
      "Perfil optimizado y catálogo publicado",
      "Calendario editorial con 30 ideas de contenido",
      "Plantilla de reporte mensual en Google Sheets",
      "Guion de mensajes de venta por WhatsApp",
    ],
    icon: "◍",
    position: 2,
    isCustom: false,
  },
  {
    slug: "marca-y-diseno-en-canva",
    title: "Marca y diseño gráfico en Canva",
    level: "Inicial",
    modality: "Presencial en taller o Zoom",
    duration: "6 horas · 2 sesiones",
    priceCents: 178000,
    seats: 12,
    summary:
      "Crea tú mismo tu logotipo, tu paleta, tus tarjetas y tus publicaciones con plantillas coherentes y sin conocimientos previos.",
    description:
      "Un taller práctico donde sales con tu marca lista: logotipo, variantes, paleta, tipografías y aplicaciones de papelería y redes. Enseñamos las reglas de diseño que usamos en agencia para que todo se vea profesional aunque lo hagas tú.",
    modules: [
      "Qué hace que un logo se vea caro o barato",
      "Paleta de color y tipografía sin ser diseñador",
      "Construcción del logotipo y versiones (principal, monocromo, isótipo)",
      "Plantillas, retícula y jerarquía visual",
      "Aplicaciones: tarjeta, membrete, portada y publicación",
      "Cómo exportar correctamente para imprenta y para redes",
    ],
    outcomes: [
      "Logotipo principal, alternativo y monocromo",
      "Paleta de marca con códigos HEX, RGB y CMYK",
      "Kit de plantillas editables en Canva",
      "Tarjeta de presentación lista para imprimir",
    ],
    icon: "✎",
    position: 3,
    isCustom: false,
  },
  {
    slug: "contenido-ugc-video-para-redes",
    title: "Contenido y UGC: video que vende con tu celular",
    level: "Intermedio",
    modality: "Presencial en taller",
    duration: "5 horas · taller práctico",
    priceCents: 220000,
    seats: 10,
    summary:
      "Guion, luz, sonido y edición básica para grabar videos profesionales con el teléfono y crear contenido estilo UGC.",
    description:
      "Grabamos en el taller con lo que ya tienes: celular, una ventana y una lámpara. Aprendemos el hook de los primeros 3 segundos, la estructura de venta en video, iluminación casera, sonido limpio y edición en apps gratuitas.",
    modules: [
      "Estructura hook → problema → solución → llamado a la acción",
      "Grabación con celular: encuadre, luz natural y enfoque",
      "Sonido: el error que arruina el 90% de los videos",
      "Edición en CapCut: cortes, subtítulos y ritmo",
      "Formatos por plataforma: 9:16, 4:5 y 1:1",
      "Cómo armar tu portafolio de creador UGC",
    ],
    outcomes: [
      "3 videos terminados y subidos durante el taller",
      "Guion propio para tu producto o servicio",
      "Checklist de grabación y edición",
      "Orientación para empezar a cobrar como creador UGC",
    ],
    icon: "▶",
    position: 4,
    isCustom: false,
  },
  {
    slug: "cotizar-y-vender-publicidad",
    title: "Cómo cotizar y vender proyectos publicitarios",
    level: "Profesional",
    modality: "En vivo por Zoom",
    duration: "4 horas · sesión intensiva",
    priceCents: 168000,
    seats: 15,
    summary:
      "Para quienes ya trabajan en el giro: cómo armar cotizaciones rentables, presentar propuestas y cerrar clientes.",
    description:
      "El taller del lado opuesto del mostrador. Costo real por pieza, margen, manejo de contraentregas, propuesta presentable y guiones de objeciones. Salimos con una cotización base lista para tu negocio de publicidad.",
    modules: [
      "Costo real: material, tiempo, máquina y mano de obra",
      "Margen, redondeo y precios psicológicos",
      "Estructura de una cotización profesional",
      "Manejo de cambios y contraentregas sin perder dinero",
      "Presentación de propuesta y cierre en 3 objeciones",
      "Anticipo, entregables y letra pequeña útil",
    ],
    outcomes: [
      "Tabla de costos y márgenes para tu catálogo",
      "Plantilla de cotización editable",
      "Propuesta comercial de 1 página",
      "Guion de objeciones más comunes del giro",
    ],
    icon: "▤",
    position: 5,
    isCustom: false,
  },
  {
    slug: "taller-personalizado",
    title: "Taller personalizado para tu equipo o negocio",
    level: "A medida",
    modality: "Presencial, en línea o en tus instalaciones",
    duration: "Lo que necesites · de 2 a 16 horas",
    priceCents: 0,
    seats: 20,
    summary:
      "Diseñamos el temario contigo: públicos, contenido, marca, pauta o punto de venta. Dictado por nosotros, con tus casos y tus productos.",
    description:
      "Si tu equipo necesita algo específico, armamos el taller a la medida: diagnóstico previo, temario aprobado por ti, ejercicios con tus propias piezas y material de apoyo para que quede aplicado. Modalidad presencial en todo México o en línea.",
    modules: [
      "Diagnóstico rápido del conocimiento actual del equipo",
      "Temario y objetivos de aprendizaje aprobados por ti",
      "Material de apoyo y plantillas con tu marca",
      "Ejercicios prácticos con casos reales de tu negocio",
      "Seguimiento de aplicación 15 días después",
    ],
    outcomes: [
      "Temario personalizado y dictado por especialistas",
      "Material de apoyo editable para tu equipo",
      "Certificado de participación por asistente",
      "Reporte de aplicaciones posterior al taller",
    ],
    icon: "✧",
    position: 6,
    isCustom: true,
  },
];

export const defaultSettings: Record<string, string> = {
  brandName: "Publicidad Graphic Solutions",
  heroEyebrow: "Papelería comercial · P.O.P. · Marketing digital",
  heroTitle: "Del archivo al punto de venta, sin tropiezos.",
  heroSubtitle:
    "Somos la agencia que imprime tus tarjetas, fabrica tu exhibidor, diseña tu marca, produce tu contenido UGC y dicta los talleres para que tu negocio aprenda a comunicarse.",
  ctaLabel: "Explorar el catálogo",
  whatsapp: "+52 55 4162 0987",
  email: "hola@publicidadgraphic.mx",
  instagram: "@_graphicsolutions_",
  workshopsIntro:
    "Talleres prácticos para emprender con conocimientos básicos de publicidad y marketing. Saldrás con plantillas, no con apuntes.",
  footerNote:
    "Una sola agencia para llevar tu idea de la pantalla a la realidad. Diseñamos · Producimos · Comunicamos.",
};
