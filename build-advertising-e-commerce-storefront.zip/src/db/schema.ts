import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export type SpecItem = { label: string; value: string };

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  name: varchar("name", { length: 160 }).notNull(),
  tagline: varchar("tagline", { length: 240 }).notNull(),
  description: text("description").notNull(),
  heroImage: text("hero_image").notNull(),
  icon: varchar("icon", { length: 16 }).notNull(),
  position: integer("position").notNull().default(0),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  sku: varchar("sku", { length: 40 }).notNull(),
  name: varchar("name", { length: 200 }).notNull(),
  categorySlug: varchar("category_slug", { length: 120 }).notNull(),
  shortDescription: text("short_description").notNull(),
  description: text("description").notNull(),
  priceCents: integer("price_cents").notNull(),
  compareAtPriceCents: integer("compare_at_price_cents"),
  unitLabel: varchar("unit_label", { length: 120 }).notNull(),
  minQty: integer("min_qty").notNull().default(1),
  leadTime: varchar("lead_time", { length: 120 }).notNull(),
  images: jsonb("images").$type<string[]>().notNull(),
  highlights: jsonb("highlights").$type<string[]>().notNull(),
  specs: jsonb("specs").$type<SpecItem[]>().notNull(),
  tags: jsonb("tags").$type<string[]>().notNull(),
  badge: varchar("badge", { length: 40 }),
  ratingAvg: integer("rating_avg").notNull().default(50),
  reviewCount: integer("review_count").notNull().default(0),
  isFeatured: boolean("is_featured").notNull().default(false),
  isBestseller: boolean("is_bestseller").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productSlug: varchar("product_slug", { length: 160 }).notNull(),
  author: varchar("author", { length: 120 }).notNull(),
  role: varchar("role", { length: 160 }).notNull(),
  rating: integer("rating").notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  body: text("body").notNull(),
  verified: boolean("verified").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: varchar("order_number", { length: 24 }).notNull().unique(),
  customerName: varchar("customer_name", { length: 160 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 60 }).notNull(),
  company: varchar("company", { length: 200 }),
  taxId: varchar("tax_id", { length: 60 }),
  deliveryMethod: varchar("delivery_method", { length: 24 }).notNull(),
  addressLine: varchar("address_line", { length: 240 }),
  city: varchar("city", { length: 120 }),
  state: varchar("state", { length: 120 }),
  postalCode: varchar("postal_code", { length: 24 }),
  notes: text("notes"),
  paymentMethod: varchar("payment_method", { length: 40 }).notNull(),
  subtotalCents: integer("subtotal_cents").notNull(),
  shippingCents: integer("shipping_cents").notNull(),
  taxCents: integer("tax_cents").notNull(),
  totalCents: integer("total_cents").notNull(),
  status: varchar("status", { length: 32 }).notNull().default("recibido"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderNumber: varchar("order_number", { length: 24 }).notNull(),
  productSlug: varchar("product_slug", { length: 160 }).notNull(),
  productName: varchar("product_name", { length: 200 }).notNull(),
  unitPriceCents: integer("unit_price_cents").notNull(),
  quantity: integer("quantity").notNull(),
});

export const subscribers = pgTable("subscribers", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 200 }).notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const workshops = pgTable("workshops", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  title: varchar("title", { length: 220 }).notNull(),
  level: varchar("level", { length: 60 }).notNull(),
  modality: varchar("modality", { length: 60 }).notNull(),
  duration: varchar("duration", { length: 80 }).notNull(),
  priceCents: integer("price_cents").notNull(),
  seats: integer("seats").notNull().default(12),
  summary: text("summary").notNull(),
  description: text("description").notNull(),
  modules: jsonb("modules").$type<string[]>().notNull(),
  outcomes: jsonb("outcomes").$type<string[]>().notNull(),
  icon: varchar("icon", { length: 16 }).notNull(),
  position: integer("position").notNull().default(0),
  isCustom: boolean("is_custom").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const workshopRegistrations = pgTable("workshop_registrations", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 24 }).notNull().unique(),
  workshopSlug: varchar("workshop_slug", { length: 160 }).notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 60 }).notNull(),
  business: varchar("business", { length: 200 }),
  seats: integer("seats").notNull().default(1),
  notes: text("notes"),
  status: varchar("status", { length: 32 }).notNull().default("pendiente"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const siteSettings = pgTable("site_settings", {
  key: varchar("key", { length: 80 }).primaryKey(),
  value: jsonb("value").$type<string>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export type Workshop = typeof workshops.$inferSelect;
export type WorkshopRegistration = typeof workshopRegistrations.$inferSelect;

export type Category = typeof categories.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Review = typeof reviews.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type OrderItem = typeof orderItems.$inferSelect;
