import { sql } from "drizzle-orm";
import { db } from "@/db";
import { categories, products, reviews, siteSettings, workshops } from "@/db/schema";
import { seedCategories, seedProducts, seedReviews } from "@/data/catalog";
import { defaultSettings, seedWorkshops } from "@/data/workshops";

let seedPromise: Promise<void> | null = null;

function daysAgoTimestamp(days: number) {
  return new Date(Date.now() - days * 24 * 60 * 60 * 1000);
}

async function runSeed() {
  // Idempotent: always guarantee settings + workshops exist.
  await db
    .insert(workshops)
    .values(seedWorkshops)
    .onConflictDoNothing();
  await db
    .insert(siteSettings)
    .values(Object.entries(defaultSettings).map(([key, value]) => ({ key, value })))
    .onConflictDoNothing();

  const [{ count }] = await db
    .select({ count: sql<number>`cast(count(*) as int)` })
    .from(products);

  if (count > 0) return;

  await db.insert(categories).values(seedCategories).onConflictDoNothing();

  const ratingTotals = new Map<
    string,
    { sum: number; count: number }
  >();
  for (const review of seedReviews) {
    const current = ratingTotals.get(review.productSlug) ?? { sum: 0, count: 0 };
    ratingTotals.set(review.productSlug, {
      sum: current.sum + review.rating,
      count: current.count + 1,
    });
  }

  await db
    .insert(products)
    .values(
      seedProducts.map((product, index) => {
        const rating = ratingTotals.get(product.slug);
        const reviewCount = rating?.count ?? 0;
        const ratingAvg = rating ? Math.round((rating.sum / rating.count) * 10) : 50;
        return {
          ...product,
          compareAtPriceCents: product.compareAtPriceCents ?? null,
          badge: product.badge ?? null,
          isFeatured: product.isFeatured ?? false,
          isBestseller: product.isBestseller ?? false,
          ratingAvg: reviewCount > 0 ? ratingAvg : 50,
          reviewCount,
          createdAt: daysAgoTimestamp(seedProducts.length - index),
        };
      }),
    )
    .onConflictDoNothing();

  await db
    .insert(reviews)
    .values(
      seedReviews.map((review) => ({
        productSlug: review.productSlug,
        author: review.author,
        role: review.role,
        rating: review.rating,
        title: review.title,
        body: review.body,
        verified: true,
        createdAt: daysAgoTimestamp(review.daysAgo),
      })),
    )
    .onConflictDoNothing();

  await db.insert(workshops).values(seedWorkshops).onConflictDoNothing();

  await db
    .insert(siteSettings)
    .values(
      Object.entries(defaultSettings).map(([key, value]) => ({ key, value })),
    )
    .onConflictDoNothing();
}

/** Idempotent seeding so a fresh database always has a stocked storefront. */
export function ensureSeeded() {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}
