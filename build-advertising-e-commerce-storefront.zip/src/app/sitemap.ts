import type { MetadataRoute } from "next";
import { getCategories, getProducts } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = "https://publicidadgraphic.mx";
  const [categories, products] = await Promise.all([getCategories(), getProducts()]);

  return [
    { url: base, changeFrequency: "weekly", priority: 1 },
    { url: `${base}/tienda`, changeFrequency: "daily", priority: 0.9 },
    ...categories.map((category) => ({
      url: `${base}/tienda?categoria=${category.slug}`,
      changeFrequency: "weekly" as const,
      priority: 0.7,
    })),
    ...products.map((product) => ({
      url: `${base}/producto/${product.slug}`,
      lastModified: product.createdAt,
      changeFrequency: "weekly" as const,
      priority: 0.6,
    })),
  ];
}
