import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Manrope, Playfair_Display, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { CartProvider } from "@/components/cart-provider";
import { CartDrawer } from "@/components/cart-drawer";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { seedCategories } from "@/data/catalog";
import { getSettings } from "@/lib/queries";

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
});

const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope",
  display: "swap",
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Publicidad Graphic Solutions · Papelería comercial y marketing digital",
    template: "%s · Publicidad Graphic Solutions",
  },
  description:
    "Taller integral de papelería comercial, material P.O.P., diseño gráfico, BTL, producción audiovisual UGC y modelaje. Cotiza, produce y recibe en un solo lugar.",
  keywords: [
    "papelería comercial",
    "material P.O.P.",
    "diseño gráfico",
    "BTL",
    "UGC",
    "modelaje",
    "imprenta",
    "marketing digital",
  ],
  openGraph: {
    title: "Publicidad Graphic Solutions",
    description:
      "Papelería comercial, P.O.P., diseño gráfico, BTL y material audiovisual UGC listo para producir.",
    type: "website",
    locale: "es_MX",
  },
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const navCategories = seedCategories.map((category) => ({
    slug: category.slug,
    name: category.name,
    tagline: category.tagline,
    icon: category.icon,
  }));

  const settings = await getSettings();

  return (
    <html lang="es-MX" className={`${playfair.variable} ${manrope.variable} ${mono.variable}`}>
      <body className="min-h-screen bg-bone-50 text-ink-900 antialiased">
        <CartProvider>
          <SiteHeader categories={navCategories} settings={settings} />
          <main>{children}</main>
          <SiteFooter categories={navCategories} settings={settings} />
          <CartDrawer />
        </CartProvider>
      </body>
    </html>
  );
}
