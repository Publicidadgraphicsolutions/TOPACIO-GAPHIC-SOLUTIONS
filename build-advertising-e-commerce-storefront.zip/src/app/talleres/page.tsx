import type { Metadata } from "next";
import Link from "next/link";
import { BrandLockup } from "@/components/brand";
import { Reveal } from "@/components/ui";
import { WorkshopForm } from "@/components/workshop-form";
import { getSettings, getWorkshops } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Talleres para emprender",
  description:
    "Talleres personalizados de publicidad y marketing para emprender: fundamentos, redes, diseño, contenido UGC y cómo cotizar proyectos. Presencial o en línea.",
};

export default async function TalleresPage() {
  const [workshops, settings] = await Promise.all([getWorkshops(), getSettings()]);

  return (
    <>
      <section className="cyber-grid relative overflow-hidden border-b border-iris-500/25 bg-ink-950 text-bone-100">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(70%_60%_at_78%_18%,rgba(224,26,128,0.18),transparent_65%)]" />
        <div className="relative mx-auto max-w-[88rem] px-5 py-16 sm:px-8 lg:py-24">
          <nav className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-bone-300/60">
            <Link href="/" className="transition hover:text-brass-300">
              Inicio
            </Link>
            <span>/</span>
            <span className="text-brass-300">Talleres</span>
          </nav>

          <div className="mt-8 grid items-end gap-10 lg:grid-cols-[1.35fr_0.65fr]">
            <div>
              <p className="eyebrow text-brass-300">
                Educación · Publicidad y marketing para emprender
              </p>
              <h1 className="display-balance neon-text glow-neon mt-5 text-[clamp(2.3rem,6vw,4.5rem)] font-black leading-[1]">
                Aprende a publicitar tu negocio, no solo a publicar
              </h1>
              <p className="mt-6 max-w-2xl text-base leading-relaxed text-bone-300/85">
                {settings.workshopsIntro}
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <a
                  href="#registro"
                  className="group inline-flex items-center gap-3 rounded-sm bg-brass-300 px-7 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-ink-950 transition hover:bg-brass-200 hover:shadow-[0_0_34px_-6px_rgba(168,238,31,0.7)]"
                >
                  Apartar mi lugar
                </a>
                <a
                  href="#programa"
                  className="inline-flex items-center gap-3 rounded-sm border border-iris-400/60 px-7 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-iris-200 transition hover:border-flame-400 hover:text-flame-400"
                >
                  Ver el programa
                </a>
              </div>
            </div>

            <div className="panel-bevel bg-ink-900/70 p-7">
              <BrandLockup size={58} />
              <ul className="mt-6 space-y-3 border-t border-bone-100/10 pt-5 text-sm text-bone-300/80">
                {[
                  "Grupos de 10 a 16 personas",
                  "Presencial en todo México o en vivo por Zoom",
                  "Plantillas y material editable incluidos",
                  "Seguimiento 15 días después del taller",
                ].map((item) => (
                  <li key={item} className="flex gap-3">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brass-400" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section id="programa" className="cyber-grid bg-ink-950 py-16 text-bone-100 lg:py-24">
        <div className="mx-auto max-w-[88rem] px-5 sm:px-8">
          <div className="max-w-2xl">
            <p className="eyebrow text-brass-300">Programa</p>
            <h2 className="display-balance neon-text mt-4 text-3xl leading-tight sm:text-4xl">
              {workshops.length} talleres listos para dictar
            </h2>
          </div>

          <div className="mt-12 space-y-6">
            {workshops.map((workshop, index) => (
              <Reveal key={workshop.slug} delay={Math.min(index, 5) * 60}>
                <article
                  id={workshop.slug}
                  className="panel-bevel scroll-mt-28 bg-ink-900/75 p-6 sm:p-8"
                >
                  <div className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr]">
                    <div>
                      <div className="flex flex-wrap items-center gap-3">
                        <span className="grid h-12 w-12 place-items-center rounded-full border border-iris-400/50 text-xl text-iris-300">
                          {workshop.icon}
                        </span>
                        <span className="rounded-full border border-brass-400/40 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-brass-300">
                          {workshop.level}
                        </span>
                        <span className="rounded-full border border-bone-100/15 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-bone-300/70">
                          {workshop.modality}
                        </span>
                        {workshop.isCustom ? (
                          <span className="rounded-full border border-flame-400/50 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-flame-400">
                            A la medida
                          </span>
                        ) : null}
                      </div>

                      <h3 className="display-balance mt-5 text-2xl leading-snug sm:text-3xl">
                        {workshop.title}
                      </h3>
                      <p className="mt-4 text-sm leading-relaxed text-bone-300/80">
                        {workshop.description}
                      </p>

                      <div className="mt-6 flex flex-wrap gap-x-8 gap-y-3 border-t border-bone-100/10 pt-5">
                        <div>
                          <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-bone-300/50">
                            Duración
                          </p>
                          <p className="mt-1 font-mono text-xs text-bone-100">{workshop.duration}</p>
                        </div>
                        <div>
                          <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-bone-300/50">
                            Cupo
                          </p>
                          <p className="mt-1 font-mono text-xs text-bone-100">
                            {workshop.seats} lugares
                          </p>
                        </div>
                        <div>
                          <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-bone-300/50">
                            Inversión
                          </p>
                          <p className="mt-1 font-mono text-xs text-brass-300">
                            {workshop.priceCents > 0
                              ? `$${(workshop.priceCents / 100).toLocaleString("es-MX")} MXN por persona`
                              : "Cotizado a la medida"}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-1">
                      <div className="rounded-sm border border-bone-100/12 bg-ink-950/60 p-5">
                        <p className="eyebrow text-brass-300">Temario</p>
                        <ul className="mt-3 space-y-2 text-[13px] leading-relaxed text-bone-300/80">
                          {workshop.modules.map((module) => (
                            <li key={module} className="flex gap-2.5">
                              <span className="mt-2 h-1 w-3 shrink-0 bg-brass-400/70" />
                              {module}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="rounded-sm border border-iris-400/25 bg-iris-600/10 p-5">
                        <p className="eyebrow text-iris-300">Al terminar tendrás</p>
                        <ul className="mt-3 space-y-2 text-[13px] leading-relaxed text-bone-200">
                          {workshop.outcomes.map((outcome) => (
                            <li key={outcome} className="flex gap-2.5">
                              <span className="text-brass-300">✓</span>
                              {outcome}
                            </li>
                          ))}
                        </ul>
                        <a
                          href={`#registro`}
                          onClick={undefined}
                          className="mt-5 flex items-center justify-center gap-2 rounded-sm bg-brass-300 px-4 py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-ink-950 transition hover:bg-brass-200"
                          data-workshop={workshop.slug}
                        >
                          Inscribirme a este taller
                        </a>
                      </div>
                    </div>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section id="registro" className="relative border-t border-iris-500/25 bg-ink-900 py-16 text-bone-100 lg:py-24">
        <div className="mx-auto grid max-w-[88rem] items-start gap-12 px-5 sm:px-8 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <p className="eyebrow text-brass-300">Registro</p>
            <h2 className="display-balance neon-text mt-4 text-3xl leading-tight sm:text-4xl">
              Aparta tu lugar en el próximo grupo
            </h2>
            <p className="mt-5 text-sm leading-relaxed text-bone-300/80">
              Después de registrarte te confirmamos fecha, horario y forma de pago. Si prefieres
              agendar el taller para todo tu equipo, marca “Taller personalizado” y armamos el
              temario contigo.
            </p>
            <div className="mt-8 space-y-4 border-t border-bone-100/10 pt-6">
              {[
                { label: "WhatsApp", value: settings.whatsapp },
                { label: "Correo", value: settings.email },
                { label: "Instagram", value: settings.instagram },
              ].map((item) => (
                <div key={item.label} className="flex items-baseline justify-between gap-4">
                  <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-bone-300/50">
                    {item.label}
                  </span>
                  <span className="text-sm text-bone-100">{item.value}</span>
                </div>
              ))}
            </div>
          </div>

          <WorkshopForm
            options={workshops.map((workshop) => ({ slug: workshop.slug, title: workshop.title }))}
          />
        </div>
      </section>
    </>
  );
}
