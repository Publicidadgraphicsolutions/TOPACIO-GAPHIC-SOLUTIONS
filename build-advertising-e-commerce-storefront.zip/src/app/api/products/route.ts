import { NextResponse, type NextRequest } from "next/server";
import { getCategories, getProducts, type SortKey } from "@/lib/queries";

export const dynamic = "force-dynamic";

const SORTS: SortKey[] = [
  "destacados",
  "precio-asc",
  "precio-desc",
  "mejor-calificados",
  "recientes",
  "populares",
];

export async function GET(request: NextRequest) {
  const params = request.nextUrl.searchParams;
  const sortParam = params.get("sort") as SortKey | null;
  const limitParam = Number(params.get("limit"));

  try {
    const [categories, products] = await Promise.all([
      getCategories(),
      getProducts({
        q: params.get("q") ?? undefined,
        category: params.get("categoria") ?? undefined,
        tags: params.get("tags")?.split(",").filter(Boolean),
        minPrice: params.get("min") ? Number(params.get("min")) : undefined,
        maxPrice: params.get("max") ? Number(params.get("max")) : undefined,
        sort: sortParam && SORTS.includes(sortParam) ? sortParam : "destacados",
        limit: Number.isFinite(limitParam) && limitParam > 0 ? Math.min(24, limitParam) : undefined,
      }),
    ]);

    const categoryMap = new Map(categories.map((category) => [category.slug, category.name]));

    return NextResponse.json({
      total: products.length,
      products: products.map((product) => ({
        slug: product.slug,
        name: product.name,
        sku: product.sku,
        category: categoryMap.get(product.categorySlug) ?? product.categorySlug,
        categorySlug: product.categorySlug,
        priceCents: product.priceCents,
        compareAtPriceCents: product.compareAtPriceCents,
        unitLabel: product.unitLabel,
        leadTime: product.leadTime,
        image: product.images[0],
        images: product.images,
        ratingAvg: product.ratingAvg,
        reviewCount: product.reviewCount,
        badge: product.badge,
      })),
    });
  } catch {
    return NextResponse.json({ error: "No pudimos cargar el catálogo." }, { status: 500 });
  }
}
