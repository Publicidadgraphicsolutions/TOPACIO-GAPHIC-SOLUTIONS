import { NextResponse } from "next/server";
import { createReview } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let payload: Record<string, unknown>;
  try {
    payload = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Cuerpo inválido." }, { status: 400 });
  }

  const productSlug = String(payload.productSlug ?? "").trim();
  const author = String(payload.author ?? "").trim();
  const title = String(payload.title ?? "").trim();
  const body = String(payload.body ?? "").trim();
  const role = String(payload.role ?? "").trim();
  const rating = Number(payload.rating);

  if (!productSlug || author.length < 2 || title.length < 3 || body.length < 10) {
    return NextResponse.json(
      { error: "Completa tu nombre, un título y una reseña de al menos 10 caracteres." },
      { status: 400 },
    );
  }
  if (!Number.isFinite(rating) || rating < 1 || rating > 5) {
    return NextResponse.json({ error: "La calificación debe ir entre 1 y 5." }, { status: 400 });
  }

  try {
    const review = await createReview({
      productSlug,
      author,
      role: role || "Cliente",
      rating,
      title,
      body,
    });
    return NextResponse.json({ review }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "No pudimos guardar tu reseña." }, { status: 500 });
  }
}
