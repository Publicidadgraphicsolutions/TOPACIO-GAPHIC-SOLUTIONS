import { NextResponse } from "next/server";
import { subscribe } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as { email?: string };
    const email = String(payload.email ?? "").trim().toLowerCase();
    if (!email.includes("@") || email.length < 5) {
      return NextResponse.json({ error: "Correo inválido." }, { status: 400 });
    }
    await subscribe(email);
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "No pudimos suscribirte." }, { status: 500 });
  }
}
