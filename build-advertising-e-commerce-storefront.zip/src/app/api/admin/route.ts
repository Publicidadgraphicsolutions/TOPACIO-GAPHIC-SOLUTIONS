import { NextResponse, type NextRequest } from "next/server";
import {
  createWorkshop,
  deleteWorkshop,
  getRegistrations,
  getSettings,
  getWorkshops,
  saveSettings,
  updateWorkshop,
} from "@/lib/queries";

export const dynamic = "force-dynamic";

const ADMIN_TOKEN = process.env.ADMIN_TOKEN ?? "graphic-solutions-2026";

function authorize(request: NextRequest) {
  const header = request.headers.get("x-admin-token") ?? "";
  const url = request.nextUrl.searchParams.get("token") ?? "";
  return header === ADMIN_TOKEN || url === ADMIN_TOKEN;
}

const WORKSHOP_FIELDS = [
  "slug",
  "title",
  "level",
  "modality",
  "duration",
  "summary",
  "description",
  "icon",
] as const;

export async function GET(request: NextRequest) {
  if (!authorize(request)) {
    return NextResponse.json({ error: "Token inválido." }, { status: 401 });
  }
  try {
    const [settings, list, registrations] = await Promise.all([
      getSettings(),
      getWorkshops(),
      getRegistrations(),
    ]);
    return NextResponse.json({ settings, workshops: list, registrations });
  } catch {
    return NextResponse.json({ error: "No pudimos cargar la configuración." }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  if (!authorize(request)) {
    return NextResponse.json({ error: "Token inválido." }, { status: 401 });
  }

  let payload: Record<string, unknown>;
  try {
    payload = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Cuerpo inválido." }, { status: 400 });
  }

  const section = String(payload.section ?? "");

  try {
    if (section === "settings") {
      const entries = (payload.settings ?? {}) as Record<string, string>;
      const clean: Record<string, string> = {};
      for (const [key, value] of Object.entries(entries)) {
        if (typeof value === "string") clean[key] = value.slice(0, 600);
      }
      await saveSettings(clean);
      return NextResponse.json({ settings: await getSettings() });
    }

    if (section === "workshop") {
      const raw = (payload.workshop ?? {}) as Record<string, unknown>;
      const id = Number(raw.id ?? 0);
      const base: Record<string, unknown> = {};
      for (const field of WORKSHOP_FIELDS) {
        if (typeof raw[field] === "string") base[field] = String(raw[field]);
      }
      base.modules = Array.isArray(raw.modules)
        ? (raw.modules as unknown[]).map(String).filter(Boolean)
        : [];
      base.outcomes = Array.isArray(raw.outcomes)
        ? (raw.outcomes as unknown[]).map(String).filter(Boolean)
        : [];
      base.priceCents = Math.max(0, Math.round(Number(raw.priceCents ?? 0) || 0));
      base.seats = Math.max(1, Math.round(Number(raw.seats ?? 10) || 10));
      base.position = Math.round(Number(raw.position ?? 1) || 1);
      base.isCustom = Boolean(raw.isCustom);

      if (id > 0) {
        await updateWorkshop(id, base);
      } else {
        await createWorkshop(
          base as Parameters<typeof createWorkshop>[0],
        );
      }
      return NextResponse.json({ workshops: await getWorkshops() });
    }

    if (section === "workshop-delete") {
      const id = Number((payload.id ?? 0));
      if (id > 0) await deleteWorkshop(id);
      return NextResponse.json({ workshops: await getWorkshops() });
    }

    return NextResponse.json({ error: "Sección desconocida." }, { status: 400 });
  } catch {
    return NextResponse.json({ error: "No pudimos guardar los cambios." }, { status: 500 });
  }
}
