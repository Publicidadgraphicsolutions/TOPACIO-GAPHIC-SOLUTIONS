import { NextResponse, type NextRequest } from "next/server";
import { getWorkshops, registerWorkshop } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const list = await getWorkshops();
    return NextResponse.json({
      workshops: list.map((workshop) => ({
        slug: workshop.slug,
        title: workshop.title,
        level: workshop.level,
        modality: workshop.modality,
        duration: workshop.duration,
        priceCents: workshop.priceCents,
        seats: workshop.seats,
        summary: workshop.summary,
        icon: workshop.icon,
        isCustom: workshop.isCustom,
      })),
    });
  } catch {
    return NextResponse.json({ error: "No pudimos cargar los talleres." }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  let payload: Record<string, unknown>;
  try {
    payload = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Cuerpo inválido." }, { status: 400 });
  }

  const workshopSlug = String(payload.workshopSlug ?? "").trim();
  const name = String(payload.name ?? "").trim();
  const email = String(payload.email ?? "").trim();
  const phone = String(payload.phone ?? "").trim();

  if (!workshopSlug || name.length < 2 || !email.includes("@") || phone.length < 6) {
    return NextResponse.json(
      { error: "Completa taller, nombre, correo y teléfono válidos." },
      { status: 400 },
    );
  }

  try {
    const registration = await registerWorkshop({
      workshopSlug,
      name,
      email,
      phone,
      business: String(payload.business ?? "").trim() || undefined,
      seats: Number(payload.seats ?? 1) || 1,
      notes: String(payload.notes ?? "").trim() || undefined,
    });
    return NextResponse.json(
      { code: registration.code, status: registration.status },
      { status: 201 },
    );
  } catch {
    return NextResponse.json(
      { error: "No pudimos registrar tu lugar. Intenta de nuevo." },
      { status: 500 },
    );
  }
}
