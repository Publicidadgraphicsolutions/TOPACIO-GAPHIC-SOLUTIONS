import { NextResponse } from "next/server";
import { createOrder, type CheckoutItem } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let payload: Record<string, unknown>;
  try {
    payload = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Cuerpo inválido." }, { status: 400 });
  }

  const required = ["customerName", "email", "phone"] as const;
  for (const field of required) {
    if (!String(payload[field] ?? "").trim()) {
      return NextResponse.json({ error: `El campo ${field} es obligatorio.` }, { status: 400 });
    }
  }
  const email = String(payload.email).trim();
  if (!email.includes("@")) {
    return NextResponse.json({ error: "Correo inválido." }, { status: 400 });
  }

  const rawItems = Array.isArray(payload.items) ? payload.items : [];
  const items: CheckoutItem[] = rawItems
    .map((item) => {
      const line = item as Record<string, unknown>;
      return {
        slug: String(line.slug ?? ""),
        quantity: Number(line.quantity ?? 0),
      };
    })
    .filter((item) => item.slug && Number.isFinite(item.quantity) && item.quantity > 0);

  if (items.length === 0) {
    return NextResponse.json({ error: "Tu carrito está vacío." }, { status: 400 });
  }

  const deliveryMethod = payload.deliveryMethod === "recoger" ? "recoger" : "enviar";
  const paymentMethod = String(payload.paymentMethod ?? "transferencia");

  try {
    const { order, items: orderItems } = await createOrder({
      customerName: String(payload.customerName).trim(),
      email,
      phone: String(payload.phone).trim(),
      company: String(payload.company ?? "").trim() || undefined,
      taxId: String(payload.taxId ?? "").trim() || undefined,
      deliveryMethod,
      addressLine: String(payload.addressLine ?? "").trim() || undefined,
      city: String(payload.city ?? "").trim() || undefined,
      state: String(payload.state ?? "").trim() || undefined,
      postalCode: String(payload.postalCode ?? "").trim() || undefined,
      notes: String(payload.notes ?? "").trim() || undefined,
      paymentMethod,
      items,
    });

    return NextResponse.json(
      {
        orderNumber: order.orderNumber,
        totalCents: order.totalCents,
        itemCount: orderItems.reduce((total, item) => total + item.quantity, 0),
      },
      { status: 201 },
    );
  } catch {
    return NextResponse.json(
      { error: "No pudimos registrar tu pedido. Intenta de nuevo." },
      { status: 500 },
    );
  }
}
