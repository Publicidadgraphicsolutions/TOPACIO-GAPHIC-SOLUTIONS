"use client";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <section className="mx-auto flex min-h-[70svh] max-w-2xl flex-col items-center justify-center gap-6 px-5 text-center">
      <p className="eyebrow text-iris-600">Algo salió mal</p>
      <h1 className="display-balance text-[clamp(2rem,5vw,3.25rem)] leading-tight">
        La prensa se detuvo un segundo
      </h1>
      <p className="max-w-md text-sm leading-relaxed text-ink-600">
        No pudimos cargar esta sección del taller. Puedes intentar de nuevo o escribirnos a
        hola@publicidadgraphic.mx con el código{" "}
        <span className="font-mono text-ink-900">{error.digest ?? "PGS-ERR"}</span>.
      </p>
      <div className="flex flex-wrap justify-center gap-3">
        <button
          type="button"
          onClick={reset}
          className="rounded-sm bg-ink-950 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-bone-100 transition hover:bg-brass-400 hover:text-ink-950"
        >
          Intentar de nuevo
        </button>
        <a
          href="/tienda"
          className="rounded-sm border border-bone-300 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-ink-800 transition hover:border-ink-900"
        >
          Ir al catálogo
        </a>
      </div>
    </section>
  );
}
