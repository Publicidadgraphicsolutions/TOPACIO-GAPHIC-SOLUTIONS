import Link from "next/link";

export default function NotFound() {
  return (
    <section className="mx-auto flex min-h-[70svh] max-w-3xl flex-col items-center justify-center gap-6 px-5 text-center">
      <p className="eyebrow text-iris-600">Error 404</p>
      <h1 className="display-balance text-[clamp(2.2rem,5vw,3.5rem)] leading-tight">
        Esta pieza ya no está en el catálogo
      </h1>
      <p className="max-w-md text-sm leading-relaxed text-ink-600">
        Puede que la hayamos actualizado o que el enlace esté incompleto. Explora el catálogo
        completo o pide una cotización a medida.
      </p>
      <div className="flex flex-wrap justify-center gap-3">
        <Link
          href="/tienda"
          className="rounded-sm bg-ink-950 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-bone-100 transition hover:bg-brass-400 hover:text-ink-950"
        >
          Ver catálogo
        </Link>
        <Link
          href="/#cotizacion"
          className="rounded-sm border border-bone-300 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-ink-800 transition hover:border-ink-900"
        >
          Cotizar a medida
        </Link>
      </div>
    </section>
  );
}
