"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { useCart } from "@/components/cart-provider";
import { computeTotals, formatMoney } from "@/lib/format";

const STEPS = ["Contacto", "Entrega", "Pago"] as const;

const PAYMENT_METHODS = [
  {
    id: "transferencia",
    label: "Transferencia SPEI",
    detail: "Enviamos datos bancarios por correo. Liberamos producción al confirmar el depósito.",
  },
  {
    id: "tarjeta",
    label: "Tarjeta de crédito / débito",
    detail: "Enlace de pago seguro 3-D Secure. Hasta 12 meses sin intereses en pedidos mayores.",
  },
  {
    id: "credito",
    label: "Crédito a 30 días",
    detail: "Para empresas con cuenta abierta. Requiere alta previa de crédito.",
  },
] as const;

export default function CheckoutPage() {
  const { items, count, subtotalCents, clear, hydrated } = useCart();
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    customerName: "",
    email: "",
    phone: "",
    company: "",
    taxId: "",
    addressLine: "",
    city: "",
    state: "",
    postalCode: "",
    notes: "",
  });
  const [deliveryMethod, setDeliveryMethod] = useState<"recoger" | "enviar">("enviar");
  const [paymentMethod, setPaymentMethod] = useState<string>("transferencia");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const totals = useMemo(
    () => computeTotals(subtotalCents, deliveryMethod),
    [subtotalCents, deliveryMethod],
  );

  const update = (key: keyof typeof form) => (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((current) => ({ ...current, [key]: event.target.value }));

  const stepValid = () => {
    if (step === 0) {
      return form.customerName.trim().length > 1 && form.email.includes("@") && form.phone.trim().length > 5;
    }
    if (step === 1) {
      if (deliveryMethod === "recoger") return true;
      return form.addressLine.trim().length > 3 && form.city.trim().length > 1 && form.postalCode.trim().length > 4;
    }
    return true;
  };

  async function submitOrder() {
    setSubmitting(true);
    setError("");
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          deliveryMethod,
          paymentMethod,
          items: items.map((item) => ({ slug: item.slug, quantity: item.quantity })),
        }),
      });
      const data = (await res.json()) as { orderNumber?: string; error?: string };
      if (!res.ok || !data.orderNumber) {
        setError(data.error ?? "No pudimos registrar tu pedido.");
        setSubmitting(false);
        return;
      }
      clear();
      router.push(`/pedido/${data.orderNumber}`);
    } catch {
      setError("Error de conexión. Intenta de nuevo.");
      setSubmitting(false);
    }
  }

  if (hydrated && items.length === 0) {
    return (
      <section className="mx-auto flex min-h-[60svh] max-w-3xl flex-col items-center justify-center gap-6 px-5 py-24 text-center">
        <span className="grid h-20 w-20 place-items-center rounded-full border border-brass-400/40 text-brass-400">
          <svg viewBox="0 0 24 24" className="h-8 w-8" fill="none" stroke="currentColor" strokeWidth="1.2">
            <path d="M4 7h16l-1.2 13H5.2L4 7zM9 7V5.4A3 3 0 0 1 12 3a3 3 0 0 1 3 2.4V7" />
          </svg>
        </span>
        <div>
          <h1 className="display-balance text-3xl">Tu carrito está vacío</h1>
          <p className="mt-3 text-sm text-ink-600">
            Elige los servicios que necesitas producir y vuelve aquí para cerrar el pedido.
          </p>
        </div>
        <Link
          href="/tienda"
          className="rounded-sm bg-ink-950 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-bone-100 transition hover:bg-brass-400 hover:text-ink-950"
        >
          Ir al catálogo
        </Link>
      </section>
    );
  }

  return (
    <section className="mx-auto max-w-[88rem] px-5 py-12 sm:px-8 lg:py-16">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow text-iris-600">Checkout seguro</p>
          <h1 className="display-balance mt-3 text-[clamp(2rem,4vw,3rem)] leading-tight">
            Cierra tu orden de producción
          </h1>
        </div>
        <p className="max-w-sm text-sm leading-relaxed text-ink-600">
          Un asesor revisa tu pedido, confirma prueba de color y te envía la orden firmada antes de
          producir.
        </p>
      </div>

      <div className="mt-10 grid gap-10 lg:grid-cols-[1.35fr_0.85fr] lg:gap-16">
        <div>
          <ol className="flex flex-wrap items-center gap-3 border-b border-bone-200 pb-6">
            {STEPS.map((label, index) => (
              <li key={label} className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => index < step && setStep(index)}
                  className={`flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.16em] transition ${
                    index === step
                      ? "text-ink-950"
                      : index < step
                        ? "text-brass-600"
                        : "text-ink-400"
                  }`}
                >
                  <span
                    className={`grid h-8 w-8 place-items-center rounded-full border text-[11px] ${
                      index === step
                        ? "border-ink-950 bg-ink-950 text-bone-100"
                        : index < step
                          ? "border-brass-400 bg-brass-100 text-brass-600"
                          : "border-bone-300"
                    }`}
                  >
                    {index < step ? "✓" : index + 1}
                  </span>
                  {label}
                </button>
                {index < STEPS.length - 1 ? (
                  <span className="hidden h-px w-8 bg-bone-300 sm:block" />
                ) : null}
              </li>
            ))}
          </ol>

          <div className="mt-8 space-y-8">
            {step === 0 ? (
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Nombre y apellido" value={form.customerName} onChange={update("customerName")} required />
                <Field label="Correo electrónico" type="email" value={form.email} onChange={update("email")} required />
                <Field label="Teléfono / WhatsApp" value={form.phone} onChange={update("phone")} required />
                <Field label="Empresa (opcional)" value={form.company} onChange={update("company")} />
                <Field label="RFC para facturar (opcional)" value={form.taxId} onChange={update("taxId")} />
                <div className="sm:col-span-2">
                  <label className="block">
                    <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-400">
                      Notas del proyecto (opcional)
                    </span>
                    <textarea
                      value={form.notes}
                      onChange={update("notes")}
                      rows={3}
                      placeholder="Fechas límite, número de versión del archivo, entregas parciales…"
                      className="mt-2 w-full rounded-sm border border-bone-300 bg-bone-50 px-4 py-3 text-sm outline-none transition focus:border-brass-400"
                    />
                  </label>
                </div>
              </div>
            ) : null}

            {step === 1 ? (
              <div className="space-y-6">
                <div className="grid gap-3 sm:grid-cols-2">
                  {(["enviar", "recoger"] as const).map((method) => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setDeliveryMethod(method)}
                      className={`rounded-sm border p-5 text-left transition ${
                        deliveryMethod === method
                          ? "border-brass-400 bg-brass-100/40"
                          : "border-bone-300 hover:border-ink-900/40"
                      }`}
                    >
                      <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-400">
                        {method === "enviar" ? "Envío nacional" : "Recoger en taller"}
                      </p>
                      <p className="display-balance mt-2 text-lg">
                        {method === "enviar" ? "Llevamos tu pedido" : "Pasa por tu pedido"}
                      </p>
                      <p className="mt-2 text-sm leading-relaxed text-ink-600">
                        {method === "enviar"
                          ? "Paquetería asegurada a todo México. Gratis en pedidos mayores a $15,000 MXN."
                          : "Nuestro taller en CDMX, de lunes a viernes de 9:00 a 19:00. Sin costo."}
                      </p>
                      <p className="mt-3 font-mono text-xs text-brass-600">
                        {method === "enviar"
                          ? totals.shippingCents === 0
                            ? "Envío incluido"
                            : formatMoney(totals.shippingCents)
                          : "Sin costo"}
                      </p>
                    </button>
                  ))}
                </div>

                {deliveryMethod === "enviar" ? (
                  <div className="grid gap-5 sm:grid-cols-2">
                    <div className="sm:col-span-2">
                      <Field
                        label="Calle y número"
                        value={form.addressLine}
                        onChange={update("addressLine")}
                        required
                      />
                    </div>
                    <Field label="Ciudad / Alcaldía" value={form.city} onChange={update("city")} required />
                    <Field label="Estado" value={form.state} onChange={update("state")} />
                    <Field label="Código postal" value={form.postalCode} onChange={update("postalCode")} required />
                  </div>
                ) : (
                  <div className="rounded-sm border border-bone-300 bg-bone-100 p-6">
                    <p className="eyebrow text-iris-600">Taller Publicidad Graphic Solutions</p>
                    <p className="mt-3 text-sm leading-relaxed text-ink-700">
                      Calle Impresores 128, Col. Industrial Vallejo, CDMX · Lunes a viernes de 9:00 a
                      19:00. Te avisamos por WhatsApp cuando el pedido esté listo.
                    </p>
                  </div>
                )}
              </div>
            ) : null}

            {step === 2 ? (
              <div className="space-y-4">
                {PAYMENT_METHODS.map((method) => (
                  <button
                    key={method.id}
                    type="button"
                    onClick={() => setPaymentMethod(method.id)}
                    className={`flex w-full items-start gap-4 rounded-sm border p-5 text-left transition ${
                      paymentMethod === method.id
                        ? "border-brass-400 bg-brass-100/40"
                        : "border-bone-300 hover:border-ink-900/40"
                    }`}
                  >
                    <span
                      className={`mt-1 grid h-4 w-4 shrink-0 place-items-center rounded-full border ${
                        paymentMethod === method.id ? "border-brass-500" : "border-ink-400"
                      }`}
                    >
                      {paymentMethod === method.id ? (
                        <span className="h-2 w-2 rounded-full bg-brass-500" />
                      ) : null}
                    </span>
                    <span>
                      <span className="display-balance block text-lg">{method.label}</span>
                      <span className="mt-1 block text-sm leading-relaxed text-ink-600">
                        {method.detail}
                      </span>
                    </span>
                  </button>
                ))}
              </div>
            ) : null}
          </div>

          {error ? (
            <p className="mt-6 rounded-sm border border-flame-500/30 bg-flame-400/10 px-4 py-3 font-mono text-[11px] uppercase tracking-[0.14em] text-flame-500">
              {error}
            </p>
          ) : null}

          <div className="mt-10 flex flex-wrap items-center gap-3">
            {step > 0 ? (
              <button
                type="button"
                onClick={() => setStep((value) => value - 1)}
                className="rounded-sm border border-bone-300 px-7 py-3.5 font-mono text-[11px] uppercase tracking-[0.18em] text-ink-700 transition hover:border-ink-900"
              >
                Atrás
              </button>
            ) : null}
            {step < STEPS.length - 1 ? (
              <button
                type="button"
                disabled={!stepValid()}
                onClick={() => setStep((value) => value + 1)}
                className="group flex items-center gap-3 rounded-sm bg-ink-950 px-8 py-3.5 font-mono text-[11px] uppercase tracking-[0.18em] text-bone-100 transition hover:bg-brass-400 hover:text-ink-950 disabled:cursor-not-allowed disabled:opacity-40"
              >
                Continuar
                <svg viewBox="0 0 24 24" className="h-4 w-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <path d="M4 12h15M13 6l6 6-6 6" />
                </svg>
              </button>
            ) : (
              <button
                type="button"
                disabled={submitting}
                onClick={submitOrder}
                className="group flex items-center gap-3 rounded-sm bg-brass-400 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.18em] text-ink-950 transition hover:bg-brass-300 disabled:opacity-60"
              >
                {submitting ? "Procesando…" : `Confirmar pedido · ${formatMoney(totals.totalCents)}`}
              </button>
            )}
          </div>
        </div>

        <aside className="lg:sticky lg:top-28 lg:self-start">
          <div className="overflow-hidden rounded-sm border border-bone-300 bg-bone-50">
            <div className="border-b border-bone-200 bg-ink-950 px-6 py-5 text-bone-100">
              <p className="eyebrow text-brass-300">Resumen del pedido</p>
              <p className="mt-1.5 font-mono text-xs text-bone-300/70">
                {count} {count === 1 ? "pieza" : "piezas"} · {items.length} servicios
              </p>
            </div>
            <ul className="divide-y divide-bone-200">
              {items.map((item) => (
                <li key={item.slug} className="flex gap-4 p-5">
                  <span className="relative h-16 w-14 shrink-0 overflow-hidden rounded-sm bg-bone-100">
                    <Image src={item.image} alt={item.name} fill sizes="56px" className="object-cover" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <Link
                      href={`/producto/${item.slug}`}
                      className="line-clamp-2 text-sm leading-snug transition hover:text-brass-600"
                    >
                      {item.name}
                    </Link>
                    <span className="mt-1 block font-mono text-[10px] uppercase tracking-[0.14em] text-ink-400">
                      {item.quantity} × {formatMoney(item.priceCents)}
                    </span>
                  </span>
                  <span className="font-mono text-xs text-ink-800">
                    {formatMoney(item.priceCents * item.quantity)}
                  </span>
                </li>
              ))}
            </ul>
            <dl className="space-y-2 border-t border-bone-200 px-6 py-5 font-mono text-xs text-ink-600">
              <div className="flex justify-between">
                <dt>Subtotal</dt>
                <dd>{formatMoney(totals.subtotalCents)}</dd>
              </div>
              <div className="flex justify-between">
                <dt>Envío</dt>
                <dd>{totals.shippingCents === 0 ? "Incluido" : formatMoney(totals.shippingCents)}</dd>
              </div>
              <div className="flex justify-between">
                <dt>IVA 16%</dt>
                <dd>{formatMoney(totals.taxCents)}</dd>
              </div>
              <div className="flex justify-between border-t border-bone-200 pt-3 text-base text-ink-950">
                <dt>Total</dt>
                <dd className="text-brass-600">{formatMoney(totals.totalCents)}</dd>
              </div>
            </dl>
          </div>
          <div className="mt-5 space-y-3 rounded-sm border border-bone-300 bg-bone-100 p-6 text-sm leading-relaxed text-ink-600">
            <p className="eyebrow text-iris-600">Incluido en tu orden</p>
            <p>· Revisión de archivo y prueba de color digital sin costo.</p>
            <p>· Asesor de producción asignado con WhatsApp directo.</p>
            <p>· Garantía de reimpresión si algo no cumple lo aprobado.</p>
          </div>
        </aside>
      </div>
    </section>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required = false,
}: {
  label: string;
  value: string;
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-400">
        {label} {required ? <span className="text-flame-500">*</span> : null}
      </span>
      <input
        type={type}
        value={value}
        onChange={onChange}
        required={required}
        className="mt-2 w-full rounded-sm border border-bone-300 bg-bone-50 px-4 py-3 text-sm outline-none transition focus:border-brass-400"
      />
    </label>
  );
}
