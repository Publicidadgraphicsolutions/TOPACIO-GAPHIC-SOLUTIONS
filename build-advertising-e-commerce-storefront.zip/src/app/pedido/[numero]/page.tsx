import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { formatDate, formatMoney } from "@/lib/format";
import { getOrderByNumber } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Pedido confirmado",
  robots: { index: false },
};

const TIMELINE = [
  { label: "Orden recibida", detail: "Un asesor revisa tu solicitud" },
  { label: "Prueba de color", detail: "Aprobación digital antes de producir" },
  { label: "En producción", detail: "Taller asignado y fecha comprometida" },
  { label: "Listo / En ruta", detail: "Te avisamos por WhatsApp" },
];

export default async function OrderPage({
  params,
}: {
  params: Promise<{ numero: string }>;
}) {
  const { numero } = await params;
  const result = await getOrderByNumber(numero);
  if (!result) notFound();

  const { order, items } = result;
  const paymentLabel =
    order.paymentMethod === "tarjeta"
      ? "Tarjeta de crédito / débito"
      : order.paymentMethod === "credito"
        ? "Crédito a 30 días"
        : "Transferencia SPEI";

  return (
    <section className="mx-auto max-w-[76rem] px-5 py-14 sm:px-8 lg:py-20">
      <div className="overflow-hidden rounded-sm border border-bone-300">
        <div className="relative overflow-hidden bg-ink-950 px-6 py-12 text-bone-100 sm:px-12">
          <div className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-brass-400/20 blur-3xl" />
          <div className="relative">
            <p className="eyebrow text-brass-300">Pedido {order.orderNumber}</p>
            <h1 className="display-balance mt-4 text-[clamp(2rem,4.5vw,3.25rem)] leading-[1.05]">
              ¡Gracias, {order.customerName.split(" ")[0]}! Tu orden quedó registrada.
            </h1>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-bone-300/80">
              Recibirás la confirmación en <span className="text-brass-200">{order.email}</span> y un
              asesor de producción te contactará en menos de 4 horas hábiles con la prueba de color y
              la fecha comprometida.
            </p>
            <div className="mt-8 flex flex-wrap gap-x-10 gap-y-4 border-t border-bone-100/15 pt-6">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-bone-300/60">Fecha</p>
                <p className="mt-1 font-mono text-sm text-bone-100">{formatDate(order.createdAt)}</p>
              </div>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-bone-300/60">Total</p>
                <p className="mt-1 font-mono text-sm text-brass-200">{formatMoney(order.totalCents)}</p>
              </div>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-bone-300/60">Pago</p>
                <p className="mt-1 font-mono text-sm text-bone-100">{paymentLabel}</p>
              </div>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-bone-300/60">Entrega</p>
                <p className="mt-1 font-mono text-sm text-bone-100">
                  {order.deliveryMethod === "enviar"
                    ? `${order.city ?? ""} ${order.postalCode ?? ""}`.trim() || "Envío a domicilio"
                    : "Recoger en taller"}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid gap-10 p-6 sm:p-12 lg:grid-cols-[1.3fr_0.7fr]">
          <div>
            <p className="eyebrow text-iris-600">Detalle de producción</p>
            <ul className="mt-5 divide-y divide-bone-200">
              {items.map((item) => (
                <li key={item.id} className="flex flex-wrap items-center justify-between gap-3 py-4">
                  <div className="min-w-0">
                    <Link
                      href={`/producto/${item.productSlug}`}
                      className="text-sm leading-snug transition hover:text-brass-600"
                    >
                      {item.productName}
                    </Link>
                    <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-400">
                      {item.quantity} × {formatMoney(item.unitPriceCents)}
                    </p>
                  </div>
                  <p className="font-mono text-sm text-ink-900">
                    {formatMoney(item.unitPriceCents * item.quantity)}
                  </p>
                </li>
              ))}
            </ul>

            <dl className="mt-6 space-y-2 border-t border-bone-200 pt-5 font-mono text-xs text-ink-600">
              <div className="flex justify-between">
                <dt>Subtotal</dt>
                <dd>{formatMoney(order.subtotalCents)}</dd>
              </div>
              <div className="flex justify-between">
                <dt>Envío</dt>
                <dd>
                  {order.shippingCents === 0 ? "Incluido" : formatMoney(order.shippingCents)}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt>IVA 16%</dt>
                <dd>{formatMoney(order.taxCents)}</dd>
              </div>
              <div className="flex justify-between border-t border-bone-200 pt-3 text-base text-ink-950">
                <dt>Total</dt>
                <dd className="text-brass-600">{formatMoney(order.totalCents)}</dd>
              </div>
            </dl>

            {order.notes ? (
              <div className="mt-6 rounded-sm border border-bone-300 bg-bone-100 p-5">
                <p className="eyebrow text-iris-600">Notas del proyecto</p>
                <p className="mt-2 text-sm leading-relaxed text-ink-700">{order.notes}</p>
              </div>
            ) : null}
          </div>

          <div>
            <p className="eyebrow text-iris-600">Seguimiento</p>
            <ol className="mt-5 space-y-5">
              {TIMELINE.map((stage, index) => (
                <li key={stage.label} className="flex gap-4">
                  <span className="relative flex flex-col items-center">
                    <span
                      className={`grid h-7 w-7 place-items-center rounded-full border font-mono text-[10px] ${
                        index === 0
                          ? "border-brass-500 bg-brass-300 text-ink-950"
                          : "border-bone-300 text-ink-400"
                      }`}
                    >
                      {index + 1}
                    </span>
                    {index < TIMELINE.length - 1 ? (
                      <span className="mt-1 h-10 w-px bg-bone-300" />
                    ) : null}
                  </span>
                  <span className="pb-2">
                    <span className="block text-sm text-ink-900">{stage.label}</span>
                    <span className="mt-0.5 block text-xs leading-relaxed text-ink-600">
                      {stage.detail}
                    </span>
                  </span>
                </li>
              ))}
            </ol>

            {order.company ? (
              <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-400">
                Empresa · {order.company}
              </p>
            ) : null}

            <div className="mt-8 rounded-sm bg-ink-950 p-6 text-bone-100">
              <p className="eyebrow text-brass-300">Siguiente paso</p>
              <p className="mt-3 text-sm leading-relaxed text-bone-300/80">
                ¿Necesitas ajustar el tiraje o la fecha? Responde el correo de confirmación o
                escríbenos por WhatsApp al +52 55 4162 0987 con tu número de orden.
              </p>
              <Link
                href="/tienda"
                className="mt-6 flex items-center justify-center rounded-sm border border-brass-400/50 px-6 py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-brass-200 transition hover:bg-brass-300 hover:text-ink-950"
              >
                Seguir produciendo
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
