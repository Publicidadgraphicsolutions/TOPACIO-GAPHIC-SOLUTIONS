"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { BrandLockup } from "@/components/brand";

type WorkshopRow = {
  id: number;
  slug: string;
  title: string;
  level: string;
  modality: string;
  duration: string;
  priceCents: number;
  seats: number;
  summary: string;
  description: string;
  modules: string[];
  outcomes: string[];
  icon: string;
  position: number;
  isCustom: boolean;
};

type Registration = {
  id: number;
  code: string;
  workshopSlug: string;
  name: string;
  email: string;
  phone: string;
  business: string | null;
  seats: number;
  status: string;
  createdAt: string;
};

const SETTING_FIELDS: { key: string; label: string; multiline?: boolean }[] = [
  { key: "brandName", label: "Nombre de la marca" },
  { key: "heroEyebrow", label: "Hero · línea superior" },
  { key: "heroTitle", label: "Hero · titular" },
  { key: "heroSubtitle", label: "Hero · descripción", multiline: true },
  { key: "ctaLabel", label: "Hero · botón principal" },
  { key: "workshopsIntro", label: "Talleres · introducción", multiline: true },
  { key: "footerNote", label: "Pie de página · frase", multiline: true },
  { key: "whatsapp", label: "WhatsApp" },
  { key: "email", label: "Correo" },
  { key: "instagram", label: "Instagram" },
];

const EMPTY_WORKSHOP: WorkshopRow = {
  id: 0,
  slug: "",
  title: "",
  level: "Inicial",
  modality: "En vivo por Zoom",
  duration: "4 horas",
  priceCents: 180000,
  seats: 12,
  summary: "",
  description: "",
  modules: [],
  outcomes: [],
  icon: "◉",
  position: 1,
  isCustom: false,
};

export default function AdminPage() {
  const [token, setToken] = useState("");
  const [inputToken, setInputToken] = useState("");
  const [authed, setAuthed] = useState(false);
  const [tab, setTab] = useState<"settings" | "workshops" | "registrations">("settings");
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [workshops, setWorkshops] = useState<WorkshopRow[]>([]);
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [editing, setEditing] = useState<WorkshopRow | null>(null);
  const [modulesText, setModulesText] = useState("");
  const [outcomesText, setOutcomesText] = useState("");
  const [status, setStatus] = useState<{ kind: "idle" | "saving" | "ok" | "error"; msg: string }>({
    kind: "idle",
    msg: "",
  });

  const load = useCallback(async (value: string) => {
    const res = await fetch("/api/admin", { headers: { "x-admin-token": value } });
    if (!res.ok) return false;
    const data = (await res.json()) as {
      settings: Record<string, string>;
      workshops: WorkshopRow[];
      registrations: Registration[];
    };
    setSettings(data.settings);
    setWorkshops(data.workshops);
    setRegistrations(data.registrations);
    return true;
  }, []);

  useEffect(() => {
    const saved = window.localStorage.getItem("pgs-admin-token") ?? "";
    if (!saved) return;
    setToken(saved);
    load(saved).then((ok) => setAuthed(ok));
  }, [load]);

  async function signIn(event: React.FormEvent) {
    event.preventDefault();
    setStatus({ kind: "saving", msg: "Validando…" });
    const ok = await load(inputToken);
    if (ok) {
      setToken(inputToken);
      window.localStorage.setItem("pgs-admin-token", inputToken);
      setAuthed(true);
      setStatus({ kind: "idle", msg: "" });
    } else {
      setStatus({ kind: "error", msg: "Token inválido." });
    }
  }

  async function saveSettings(event: React.FormEvent) {
    event.preventDefault();
    setStatus({ kind: "saving", msg: "Guardando…" });
    const res = await fetch("/api/admin", {
      method: "PUT",
      headers: { "Content-Type": "application/json", "x-admin-token": token },
      body: JSON.stringify({ section: "settings", settings }),
    });
    if (res.ok) {
      const data = (await res.json()) as { settings: Record<string, string> };
      setSettings(data.settings);
      setStatus({ kind: "ok", msg: "Cambios publicados. El sitio ya los muestra." });
    } else {
      setStatus({ kind: "error", msg: "No se pudo guardar." });
    }
  }

  function openWorkshop(workshop?: WorkshopRow) {
    const row = workshop ?? { ...EMPTY_WORKSHOP, position: workshops.length + 1 };
    setEditing(row);
    setModulesText(row.modules.join("\n"));
    setOutcomesText(row.outcomes.join("\n"));
    setStatus({ kind: "idle", msg: "" });
  }

  async function saveWorkshop(event: React.FormEvent) {
    event.preventDefault();
    if (!editing) return;
    setStatus({ kind: "saving", msg: "Guardando taller…" });
    const res = await fetch("/api/admin", {
      method: "PUT",
      headers: { "Content-Type": "application/json", "x-admin-token": token },
      body: JSON.stringify({
        section: "workshop",
        workshop: {
          ...editing,
          modules: modulesText.split("\n").map((line) => line.trim()).filter(Boolean),
          outcomes: outcomesText.split("\n").map((line) => line.trim()).filter(Boolean),
        },
      }),
    });
    if (res.ok) {
      const data = (await res.json()) as { workshops: WorkshopRow[] };
      setWorkshops(data.workshops);
      setEditing(null);
      setStatus({ kind: "ok", msg: "Taller publicado." });
    } else {
      setStatus({ kind: "error", msg: "No se pudo guardar el taller." });
    }
  }

  async function removeWorkshop(id: number) {
    if (!window.confirm("¿Eliminar este taller?")) return;
    const res = await fetch("/api/admin", {
      method: "PUT",
      headers: { "Content-Type": "application/json", "x-admin-token": token },
      body: JSON.stringify({ section: "workshop-delete", id }),
    });
    if (res.ok) {
      const data = (await res.json()) as { workshops: WorkshopRow[] };
      setWorkshops(data.workshops);
      setStatus({ kind: "ok", msg: "Taller eliminado." });
    }
  }

  if (!authed) {
    return (
      <section className="cyber-grid flex min-h-[78svh] items-center justify-center bg-ink-950 px-5 py-20">
        <form
          onSubmit={signIn}
          className="panel-bevel w-full max-w-md bg-ink-900/90 p-8 text-bone-100"
        >
          <BrandLockup size={56} />
          <h1 className="display-balance mt-6 text-2xl">Panel de edición</h1>
          <p className="mt-2 text-sm leading-relaxed text-bone-300/70">
            Escribe el token de administración para editar textos, datos de contacto y talleres.
          </p>
          <label className="mt-6 block">
            <span className="eyebrow text-bone-300/60">Token</span>
            <input
              type="password"
              value={inputToken}
              onChange={(event) => setInputToken(event.target.value)}
              className="mt-2 w-full rounded-sm border border-white/15 bg-ink-950/70 px-4 py-3 text-sm text-bone-50 outline-none focus:border-brass-400"
              placeholder="••••••••"
              autoFocus
            />
          </label>
          {status.kind === "error" ? (
            <p className="mt-3 font-mono text-[11px] text-flame-400">{status.msg}</p>
          ) : null}
          <button
            type="submit"
            className="mt-6 w-full rounded-sm bg-brass-300 px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-ink-950 transition hover:bg-brass-200"
          >
            Entrar
          </button>
          <div className="mt-5 flex items-center justify-between border-t border-white/10 pt-4 font-mono text-[10px] uppercase tracking-[0.16em] text-bone-300/50">
            <Link href="/" className="transition hover:text-brass-300">
              ← Volver al sitio
            </Link>
            <span>Token por defecto: graphic-solutions-2026</span>
          </div>
        </form>
      </section>
    );
  }

  return (
    <section className="cyber-grid min-h-[80svh] bg-ink-950 px-5 py-12 text-bone-100 sm:px-8">
      <div className="mx-auto max-w-[80rem]">
        <div className="flex flex-wrap items-center justify-between gap-5 border-b border-white/10 pb-6">
          <BrandLockup size={52} compact />
          <div className="flex flex-wrap gap-2">
            {(
              [
                ["settings", "Textos del sitio"],
                ["workshops", "Talleres"],
                ["registrations", "Registros"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setTab(id)}
                className={`rounded-full px-4 py-2 font-mono text-[10px] uppercase tracking-[0.16em] transition ${
                  tab === id
                    ? "bg-brass-300 text-ink-950"
                    : "border border-white/15 text-bone-300/70 hover:border-brass-400/60"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
          <p className="font-mono text-[11px] uppercase tracking-[0.16em]">
            {status.kind === "saving" ? (
              <span className="text-brass-300">{status.msg}</span>
            ) : status.kind === "ok" ? (
              <span className="text-brass-300">✓ {status.msg}</span>
            ) : status.kind === "error" ? (
              <span className="text-flame-400">{status.msg}</span>
            ) : (
              <span className="text-bone-300/50">Edición en vivo · los cambios son inmediatos</span>
            )}
          </p>
          <div className="flex gap-3">
            <Link
              href="/"
              className="font-mono text-[10px] uppercase tracking-[0.16em] text-bone-300/60 transition hover:text-brass-300"
            >
              Ver sitio
            </Link>
            <button
              type="button"
              onClick={() => {
                window.localStorage.removeItem("pgs-admin-token");
                setAuthed(false);
                setToken("");
              }}
              className="font-mono text-[10px] uppercase tracking-[0.16em] text-flame-400 transition hover:text-flame-400/70"
            >
              Cerrar sesión
            </button>
          </div>
        </div>

        {tab === "settings" ? (
          <form onSubmit={saveSettings} className="panel-bevel mt-6 bg-ink-900/80 p-6 sm:p-8">
            <p className="eyebrow text-brass-300">Textos del sitio</p>
            <p className="mt-2 text-sm text-bone-300/70">
              Estos textos aparecen en el encabezado, el hero, los talleres y el pie de página.
            </p>
            <div className="mt-6 grid gap-5 sm:grid-cols-2">
              {SETTING_FIELDS.map((field) => (
                <label
                  key={field.key}
                  className={field.multiline ? "block sm:col-span-2" : "block"}
                >
                  <span className="eyebrow text-bone-300/60">{field.label}</span>
                  {field.multiline ? (
                    <textarea
                      rows={3}
                      value={settings[field.key] ?? ""}
                      onChange={(event) =>
                        setSettings((current) => ({ ...current, [field.key]: event.target.value }))
                      }
                      className="mt-2 w-full rounded-sm border border-white/15 bg-ink-950/70 px-4 py-3 text-sm text-bone-50 outline-none focus:border-brass-400"
                    />
                  ) : (
                    <input
                      value={settings[field.key] ?? ""}
                      onChange={(event) =>
                        setSettings((current) => ({ ...current, [field.key]: event.target.value }))
                      }
                      className="mt-2 w-full rounded-sm border border-white/15 bg-ink-950/70 px-4 py-3 text-sm text-bone-50 outline-none focus:border-brass-400"
                    />
                  )}
                </label>
              ))}
            </div>
            <button
              type="submit"
              className="mt-7 rounded-sm bg-brass-300 px-8 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-ink-950 transition hover:bg-brass-200"
            >
              Publicar cambios
            </button>
          </form>
        ) : null}

        {tab === "workshops" ? (
          <div className="mt-6 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="eyebrow text-brass-300">Talleres publicados</p>
              <button
                type="button"
                onClick={() => openWorkshop()}
                className="rounded-sm bg-brass-300 px-5 py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-ink-950 transition hover:bg-brass-200"
              >
                + Nuevo taller
              </button>
            </div>

            {editing ? (
              <form onSubmit={saveWorkshop} className="panel-bevel bg-ink-900/90 p-6 sm:p-8">
                <div className="flex items-center justify-between">
                  <p className="eyebrow text-brass-300">
                    {editing.id ? "Editar taller" : "Nuevo taller"}
                  </p>
                  <button
                    type="button"
                    onClick={() => setEditing(null)}
                    className="font-mono text-[10px] uppercase tracking-[0.16em] text-bone-300/60 hover:text-flame-400"
                  >
                    Cancelar
                  </button>
                </div>

                <div className="mt-5 grid gap-4 sm:grid-cols-2">
                  {(
                    [
                      ["title", "Título"],
                      ["slug", "Slug (URL)"],
                      ["level", "Nivel"],
                      ["modality", "Modalidad"],
                      ["duration", "Duración"],
                      ["icon", "Ícono (emoji)"],
                    ] as const
                  ).map(([key, label]) => (
                    <label key={key} className="block">
                      <span className="eyebrow text-bone-300/60">{label}</span>
                      <input
                        value={String(editing[key] ?? "")}
                        onChange={(event) =>
                          setEditing((current) =>
                            current
                              ? { ...current, [key]: event.target.value, slug: slugify(current, key, event.target.value) }
                              : current,
                          )
                        }
                        className="mt-2 w-full rounded-sm border border-white/15 bg-ink-950/70 px-4 py-3 text-sm text-bone-50 outline-none focus:border-brass-400"
                      />
                    </label>
                  ))}
                  <label className="block">
                    <span className="eyebrow text-bone-300/60">Precio (pesos MXN)</span>
                    <input
                      type="number"
                      min={0}
                      value={Math.round(editing.priceCents / 100)}
                      onChange={(event) =>
                        setEditing((current) =>
                          current
                            ? { ...current, priceCents: Math.round(Number(event.target.value) * 100) }
                            : current,
                        )
                      }
                      className="mt-2 w-full rounded-sm border border-white/15 bg-ink-950/70 px-4 py-3 text-sm text-bone-50 outline-none focus:border-brass-400"
                    />
                  </label>
                  <label className="block">
                    <span className="eyebrow text-bone-300/60">Cupo</span>
                    <input
                      type="number"
                      min={1}
                      value={editing.seats}
                      onChange={(event) =>
                        setEditing((current) =>
                          current
                            ? { ...current, seats: Math.max(1, Number(event.target.value)) }
                            : current,
                        )
                      }
                      className="mt-2 w-full rounded-sm border border-white/15 bg-ink-950/70 px-4 py-3 text-sm text-bone-50 outline-none focus:border-brass-400"
                    />
                  </label>
                  <label className="block">
                    <span className="eyebrow text-bone-300/60">Posición</span>
                    <input
                      type="number"
                      min={1}
                      value={editing.position}
                      onChange={(event) =>
                        setEditing((current) =>
                          current
                            ? { ...current, position: Math.max(1, Number(event.target.value)) }
                            : current,
                        )
                      }
                      className="mt-2 w-full rounded-sm border border-white/15 bg-ink-950/70 px-4 py-3 text-sm text-bone-50 outline-none focus:border-brass-400"
                    />
                  </label>
                  <label className="flex items-center gap-3 sm:col-span-2">
                    <input
                      type="checkbox"
                      checked={editing.isCustom}
                      onChange={(event) =>
                        setEditing((current) =>
                          current ? { ...current, isCustom: event.target.checked } : current,
                        )
                      }
                      className="h-4 w-4 accent-[#c6ff4d]"
                    />
                    <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-bone-300/70">
                      Marcar como taller a la medida
                    </span>
                  </label>
                  <label className="block sm:col-span-2">
                    <span className="eyebrow text-bone-300/60">Resumen (tarjeta)</span>
                    <textarea
                      rows={2}
                      value={editing.summary}
                      onChange={(event) =>
                        setEditing((current) =>
                          current ? { ...current, summary: event.target.value } : current,
                        )
                      }
                      className="mt-2 w-full rounded-sm border border-white/15 bg-ink-950/70 px-4 py-3 text-sm text-bone-50 outline-none focus:border-brass-400"
                    />
                  </label>
                  <label className="block sm:col-span-2">
                    <span className="eyebrow text-bone-300/60">Descripción larga</span>
                    <textarea
                      rows={4}
                      value={editing.description}
                      onChange={(event) =>
                        setEditing((current) =>
                          current ? { ...current, description: event.target.value } : current,
                        )
                      }
                      className="mt-2 w-full rounded-sm border border-white/15 bg-ink-950/70 px-4 py-3 text-sm text-bone-50 outline-none focus:border-brass-400"
                    />
                  </label>
                  <label className="block">
                    <span className="eyebrow text-bone-300/60">Temario · una línea por tema</span>
                    <textarea
                      rows={7}
                      value={modulesText}
                      onChange={(event) => setModulesText(event.target.value)}
                      className="mt-2 w-full rounded-sm border border-white/15 bg-ink-950/70 px-4 py-3 text-sm text-bone-50 outline-none focus:border-brass-400"
                    />
                  </label>
                  <label className="block">
                    <span className="eyebrow text-bone-300/60">Resultados · una línea por logro</span>
                    <textarea
                      rows={7}
                      value={outcomesText}
                      onChange={(event) => setOutcomesText(event.target.value)}
                      className="mt-2 w-full rounded-sm border border-white/15 bg-ink-950/70 px-4 py-3 text-sm text-bone-50 outline-none focus:border-brass-400"
                    />
                  </label>
                </div>

                <button
                  type="submit"
                  className="mt-6 rounded-sm bg-brass-300 px-8 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-ink-950 transition hover:bg-brass-200"
                >
                  Guardar taller
                </button>
              </form>
            ) : null}

            <ul className="grid gap-4 sm:grid-cols-2">
              {workshops.map((workshop) => (
                <li key={workshop.id} className="panel-bevel bg-ink-900/75 p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-brass-300">
                        {workshop.icon} {workshop.level}
                      </p>
                      <p className="display-balance mt-2 text-lg leading-snug">{workshop.title}</p>
                      <p className="mt-2 font-mono text-[10px] text-bone-300/50">
                        {workshop.duration} · {workshop.seats} lugares ·{" "}
                        {workshop.priceCents > 0
                          ? `$${(workshop.priceCents / 100).toLocaleString("es-MX")}`
                          : "A medida"}
                      </p>
                    </div>
                    <div className="flex shrink-0 gap-2">
                      <button
                        type="button"
                        onClick={() => openWorkshop(workshop)}
                        className="rounded-sm border border-white/15 px-3 py-2 font-mono text-[10px] uppercase tracking-[0.14em] text-bone-200 transition hover:border-brass-400 hover:text-brass-300"
                      >
                        Editar
                      </button>
                      <button
                        type="button"
                        onClick={() => removeWorkshop(workshop.id)}
                        className="rounded-sm border border-flame-400/40 px-3 py-2 font-mono text-[10px] uppercase tracking-[0.14em] text-flame-400 transition hover:bg-flame-500/15"
                      >
                        Borrar
                      </button>
                    </div>
                  </div>
                  <p className="mt-3 line-clamp-2 text-[13px] leading-relaxed text-bone-300/70">
                    {workshop.summary}
                  </p>
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        {tab === "registrations" ? (
          <div className="mt-6">
            <p className="eyebrow text-brass-300">Registros a talleres</p>
            {registrations.length === 0 ? (
              <p className="mt-6 rounded-sm border border-dashed border-white/15 p-10 text-center text-sm text-bone-300/60">
                Aún no hay registros. Cuando alguien complete el formulario aparecerá aquí.
              </p>
            ) : (
              <div className="mt-5 overflow-x-auto rounded-sm border border-white/10">
                <table className="w-full min-w-[46rem] text-left text-sm">
                  <thead className="bg-ink-900 font-mono text-[10px] uppercase tracking-[0.16em] text-bone-300/60">
                    <tr>
                      <th className="px-4 py-3">Folio</th>
                      <th className="px-4 py-3">Nombre</th>
                      <th className="px-4 py-3">Taller</th>
                      <th className="px-4 py-3">Contacto</th>
                      <th className="px-4 py-3">Lugares</th>
                      <th className="px-4 py-3">Estado</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/8">
                    {registrations.map((row) => (
                      <tr key={row.id} className="bg-ink-950/50">
                        <td className="px-4 py-3 font-mono text-[11px] text-brass-300">{row.code}</td>
                        <td className="px-4 py-3">
                          {row.name}
                          {row.business ? (
                            <span className="block text-[11px] text-bone-300/50">{row.business}</span>
                          ) : null}
                        </td>
                        <td className="px-4 py-3 text-bone-300/80">
                          {workshops.find((workshop) => workshop.slug === row.workshopSlug)?.title ??
                            row.workshopSlug}
                        </td>
                        <td className="px-4 py-3 text-bone-300/70">
                          <span className="block">{row.email}</span>
                          <span className="block text-[11px] text-bone-300/50">{row.phone}</span>
                        </td>
                        <td className="px-4 py-3">{row.seats}</td>
                        <td className="px-4 py-3">
                          <span className="rounded-full border border-brass-400/40 px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-brass-300">
                            {row.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        ) : null}
      </div>
    </section>
  );
}

function slugify(current: WorkshopRow, key: string, value: string) {
  if (key !== "title" || current.id > 0) return current.slug === undefined ? "" : current.slug;
  if (current.slug && current.id === 0) {
    // keep manual slug once user edited it; only auto-generate while untouched from empty
    if (current.slug.length > 0) return current.slug;
  }
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}
