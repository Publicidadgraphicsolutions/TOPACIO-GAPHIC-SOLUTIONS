export default function TiendaLoading() {
  return (
    <div className="mx-auto max-w-[88rem] px-5 py-14 sm:px-8">
      <div className="h-8 w-48 animate-pulse rounded-sm bg-bone-200" />
      <div className="mt-6 h-14 w-2/3 animate-pulse rounded-sm bg-bone-200" />
      <div className="mt-10 grid gap-10 lg:grid-cols-[17rem_1fr] lg:gap-14">
        <div className="hidden space-y-4 lg:block">
          {Array.from({ length: 6 }).map((_, index) => (
            <div key={index} className="h-9 animate-pulse rounded-sm bg-bone-200" />
          ))}
        </div>
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 9 }).map((_, index) => (
            <div key={index} className="overflow-hidden rounded-sm border border-bone-200">
              <div className="aspect-4/5 animate-pulse bg-bone-200" />
              <div className="space-y-3 p-5">
                <div className="h-3 w-20 animate-pulse rounded-sm bg-bone-200" />
                <div className="h-4 w-4/5 animate-pulse rounded-sm bg-bone-200" />
                <div className="h-3 w-2/3 animate-pulse rounded-sm bg-bone-200" />
                <div className="h-6 w-28 animate-pulse rounded-sm bg-bone-200" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
