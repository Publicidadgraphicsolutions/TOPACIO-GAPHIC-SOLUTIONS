import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ProductCard } from "@/components/product-card";
import {
  ActiveFilterChips,
  ShopFilters,
  SortSelect,
} from "@/components/shop-filters";
import { Reveal } from "@/components/ui";
import {
  getAllTags,
  getCategories,
  getCategoryFacets,
  getPriceBounds,
  getProducts,
  type SortKey,
} from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Catálogo",
  description:
    "Papelería comercial, material P.O.P., gran formato, diseño gráfico, BTL, audiovisual UGC y modelaje. Filtra por colección, precio y etiqueta.",
};

type SearchParams = Record<string, string | string[] | undefined>;

function first(value: string | string[] | undefined) {
  if (Array.isArray(value)) return value[0];
  return value;
}

export default async function ShopPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const params = await searchParams;
  const categoria = first(params.categoria);
  const q = first(params.q);
  const tagsParam = first(params.tags);
  const min = first(params.min);
  const max = first(params.max);
  const orden = (first(params.orden) as SortKey | undefined) ?? "destacados";

  const [categories, facets, tagList, bounds, products] = await Promise.all([
    getCategories(),
    getCategoryFacets(),
    getAllTags(),
    getPriceBounds(),
    getProducts({
      category: categoria,
      q,
      tags: tagsParam?.split(",").filter(Boolean),
      minPrice: min ? Number(min) : undefined,
      maxPrice: max ? Number(max) : undefined,
      sort: orden,
    }),
  ]);

  const activeCategory = categories.find((category) => category.slug === categoria);
  const categoryNames = new Map(categories.map((category) => [category.slug, category.name]));

  return (
    <>
      <section className="relative overflow-hidden bg-ink-950 text-bone-100">
        {activeCategory ? (
          <div className="absolute inset-0">
            <Image
              src={activeCategory.heroImage}
              alt=""
              aria-hidden
              fill
              priority
              sizes="100vw"
              className="object-cover opacity-35"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/85 to-ink-950/40" />
          </div>
        ) : null}
        <div className="relative mx-auto max-w-[88rem] px-5 py-14 sm:px-8 lg:py-20">
          <nav className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-bone-300/60">
            <Link href="/" className="transition hover:text-brass-200">
              Inicio
            </Link>
            <span>/</span>
            <span className="text-brass-300">{activeCategory ? activeCategory.name : "Catálogo"}</span>
          </nav>
          <div className="mt-6 max-w-3xl">
            <p className="eyebrow text-brass-300">
              {activeCategory ? activeCategory.tagline : "7 colecciones · 1 taller"}
            </p>
            <h1 className="display-balance mt-4 text-[clamp(2.2rem,5vw,3.75rem)] leading-[1.02]">
              {activeCategory ? activeCategory.name : "Catálogo de producción"}
            </h1>
            <p className="mt-5 text-sm leading-relaxed text-bone-300/80 sm:text-base">
              {activeCategory
                ? activeCategory.description
                : "Todo lo que producimos, con precio abierto y fecha de entrega real. Filtra por colección, presupuesto o etiqueta y arma tu pedido en minutos."}
            </p>
          </div>
          <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-4 border-t border-bone-100/12 pt-6">
            <div>
              <p className="display-balance text-2xl text-brass-200">{products.length}</p>
              <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-bone-300/60">
                Productos en vista
              </p>
            </div>
            <div className="hidden h-10 w-px bg-bone-100/15 sm:block" />
            <div className="flex flex-wrap gap-2">
              {categories.slice(0, 4).map((category) => (
                <Link
                  key={category.slug}
                  href={`/tienda?categoria=${category.slug}`}
                  className={`rounded-full border px-3.5 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] transition ${
                    categoria === category.slug
                      ? "border-brass-300 bg-brass-300/15 text-brass-200"
                      : "border-bone-100/20 text-bone-300/70 hover:border-brass-300 hover:text-brass-200"
                  }`}
                >
                  {category.name}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[88rem] px-5 py-12 sm:px-8 lg:py-16">
        <div className="grid gap-10 lg:grid-cols-[17rem_1fr] lg:gap-14">
          <ShopFilters facets={facets} tags={tagList} bounds={bounds} />

          <div>
            <div className="flex flex-col gap-4 border-b border-bone-200 pb-5 sm:flex-row sm:items-center sm:justify-between">
              <ActiveFilterChips facets={facets} />
              <div className="flex items-center gap-3 sm:ml-auto">
                <SortSelect />
              </div>
            </div>

            {products.length === 0 ? (
              <div className="flex flex-col items-center justify-center gap-5 rounded-sm border border-dashed border-bone-300 bg-bone-100 px-6 py-24 text-center">
                <span className="grid h-16 w-16 place-items-center rounded-full border border-brass-400/40 text-brass-400">
                  <svg viewBox="0 0 24 24" className="h-7 w-7" fill="none" stroke="currentColor" strokeWidth="1.2">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M20 20l-3.6-3.6M8.5 11h5" />
                  </svg>
                </span>
                <div>
                  <p className="display-balance text-2xl">Sin resultados con esos filtros</p>
                  <p className="mt-2 text-sm text-ink-600">
                    Prueba ampliar el rango de precio o quitar etiquetas. También podemos cotizarlo
                    a medida.
                  </p>
                </div>
                <Link
                  href="/tienda"
                  className="rounded-sm bg-ink-950 px-6 py-3 font-mono text-[11px] uppercase tracking-[0.2em] text-bone-100 transition hover:bg-brass-400 hover:text-ink-950"
                >
                  Ver todo el catálogo
                </Link>
              </div>
            ) : (
              <div className="mt-8 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {products.map((product, index) => (
                  <Reveal key={product.slug} delay={Math.min(index, 8) * 60}>
                    <ProductCard
                      product={product}
                      categoryName={categoryNames.get(product.categorySlug)}
                      priority={index < 3}
                    />
                  </Reveal>
                ))}
              </div>
            )}

            <div className="mt-14 rounded-sm border border-ink-900/10 bg-ink-950 p-8 text-bone-100 sm:p-10">
              <div className="flex flex-wrap items-end justify-between gap-6">
                <div className="max-w-xl">
                  <p className="eyebrow text-brass-300">Producción a medida</p>
                  <h2 className="display-balance mt-3 text-2xl leading-snug sm:text-3xl">
                    ¿Necesitas otra medida, otro tiraje o otro acabado?
                  </h2>
                  <p className="mt-3 text-sm leading-relaxed text-bone-300/75">
                    Cotizamos formatos especiales, tirajes de 100 a 500,000 piezas y acabados fuera
                    de catálogo. Envíanos tu archivo y te respondemos en menos de 4 horas hábiles.
                  </p>
                </div>
                <Link
                  href="/#cotizacion"
                  className="inline-flex items-center gap-3 rounded-sm bg-brass-300 px-7 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-ink-950 transition hover:bg-brass-200"
                >
                  Pedir cotización
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
