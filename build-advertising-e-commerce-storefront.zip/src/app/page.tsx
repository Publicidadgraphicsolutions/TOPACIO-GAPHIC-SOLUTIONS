import Image from "next/image";
import Link from "next/link";
import { ProductCard } from "@/components/product-card";
import { NewsletterForm } from "@/components/site-footer";
import { Reveal, SectionHeading, StarRating } from "@/components/ui";
import { formatMoney } from "@/lib/format";
import {
  getCategories,
  getProducts,
  getSettings,
  getTopReviews,
  getWorkshops,
} from "@/lib/queries";

export const dynamic = "force-dynamic";

const CLIENTS = [
  "Café Tonalli",
  "Kanik Software",
  "Ledesma Skincare",
  "Grupo Tepeyac",
  "Bebidas Cielo Rojo",
  "Elizalde Beauty",
  "Ontiveros Constructora",
  "Snacks Yolki",
  "Rentería Tech",
  "Boutique Nadia",
];

const PROCESS = [
  {
    step: "01",
    title: "Brief y diagnóstico",
    copy: "Escuchamos el objetivo comercial, revisamos lo que ya existe y definimos qué se necesita producir: formato, tiraje, sustrato y fecha límite.",
  },
  {
    step: "02",
    title: "Diseño y prototipo",
    copy: "Dirección de arte, pruebas de color y —cuando aplica— prototipo físico o render antes de autorizar producción.",
  },
  {
    step: "03",
    title: "Producción en taller",
    copy: "Impresión offset, digital, gran formato, corte láser y armado. Control de calidad por pieza, no por lote.",
  },
  {
    step: "04",
    title: "Entrega y reporte",
    copy: "Logística a punto de venta u oficina, guía de instalación y reporte fotográfico del material colocado.",
  },
];

const CAPABILITIES = [
  { icon: "✳", label: "Papelería comercial", detail: "Offset, digital, foil, letterpress" },
  { icon: "◈", label: "Material P.O.P.", detail: "Corrugado, acrílico, metal" },
  { icon: "✎", label: "Diseño gráfico", detail: "Branding, packaging, editorial" },
  { icon: "◉", label: "BTL & activaciones", detail: "Stands, sampling, staff" },
  { icon: "▶", label: "Audiovisual & UGC", detail: "UGC, spots, foto producto" },
  { icon: "✧", label: "Modelaje & talento", detail: "Editorial, e-commerce, voz" },
];

export default async function HomePage() {
  const [categories, featured, bestsellers, newest, reviews, settings, talleres] =
    await Promise.all([
      getCategories(),
      getProducts({ featuredOnly: true, limit: 8 }),
      getProducts({ bestsellerOnly: true, sort: "populares", limit: 4 }),
      getProducts({ sort: "recientes", limit: 3 }),
      getTopReviews(3),
      getSettings(),
      getWorkshops(),
    ]);

  const categoryCounts = await Promise.all(
    categories.map(async (category) => {
      const items = await getProducts({ category: category.slug });
      return { ...category, count: items.length };
    }),
  );

  return (
    <>
      {/* HERO */}
      <section className="relative isolate flex min-h-[92svh] items-end overflow-hidden bg-ink-950 text-bone-100">
        <div className="absolute inset-0">
          <Image
            src="/images/hero-atelier.jpg"
            alt="Atelier de impresión comercial de Publicidad Graphic Solutions"
            fill
            priority
            sizes="100vw"
            className="animate-kenburns object-cover opacity-70"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/70 to-ink-950/30" />
          <div className="absolute inset-0 bg-[radial-gradient(120%_80%_at_80%_10%,rgba(201,164,92,0.22),transparent_60%)]" />
        </div>

        <div className="relative mx-auto w-full max-w-[88rem] px-5 pb-16 pt-32 sm:px-8 lg:pb-24">
          <div className="animate-fade-up max-w-4xl">
            <p className="eyebrow text-brass-300">{settings.heroEyebrow}</p>
            <h1 className="display-balance neon-text glow-neon mt-6 text-[clamp(2.6rem,7vw,5.4rem)] font-black leading-[0.98]">
              {settings.heroTitle}
            </h1>
            <p className="mt-7 max-w-xl text-base leading-relaxed text-bone-300/85 sm:text-lg">
              {settings.heroSubtitle}
            </p>
            <div className="mt-10 flex flex-wrap items-center gap-3">
              <Link
                href="/tienda"
                className="group inline-flex items-center gap-3 rounded-sm bg-brass-300 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-ink-950 transition hover:bg-brass-200 hover:shadow-[0_0_34px_-6px_rgba(168,238,31,0.7)]"
              >
                {settings.ctaLabel}
                <svg
                  viewBox="0 0 24 24"
                  className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                >
                  <path d="M4 12h15M13 6l6 6-6 6" />
                </svg>
              </Link>
              <Link
                href="/talleres"
                className="inline-flex items-center gap-3 rounded-sm border border-iris-400/60 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-iris-200 transition hover:border-flame-400 hover:text-flame-400"
              >
                Talleres para emprender
              </Link>
              <Link
                href="#cotizacion"
                className="inline-flex items-center gap-3 rounded-sm border border-bone-100/25 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-bone-100 transition hover:border-brass-300 hover:text-brass-200"
              >
                Cotizar un proyecto
              </Link>
            </div>
          </div>

          <div className="mt-16 grid gap-6 border-t border-bone-100/15 pt-8 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { value: "12 años", label: "Produciendo marcas en México" },
              { value: "3,400+", label: "Proyectos entregados" },
              { value: "48 h", label: "Gran formato en entrega exprés" },
              { value: "96%", label: "Clientes que repiten tiraje" },
            ].map((stat, index) => (
              <div
                key={stat.label}
                className="animate-fade-up"
                style={{ animationDelay: `${180 + index * 110}ms` }}
              >
                <p className="display-balance text-3xl text-brass-200">{stat.value}</p>
                <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.18em] text-bone-300/60">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CLIENT MARQUEE */}
      <section className="border-y border-bone-200 bg-bone-100 py-6">
        <div className="mx-auto flex max-w-[88rem] items-center gap-8 overflow-hidden px-5 sm:px-8">
          <span className="hidden shrink-0 font-mono text-[10px] uppercase tracking-[0.22em] text-ink-400 sm:block">
            Confían en nosotros
          </span>
          <div className="relative flex-1 overflow-hidden">
            <div className="animate-marquee flex w-max items-center gap-12">
              {[0, 1].map((dup) => (
                <div key={dup} className="flex items-center gap-12">
                  {CLIENTS.map((client) => (
                    <span
                      key={`${dup}-${client}`}
                      className="display-balance whitespace-nowrap text-lg text-ink-600"
                    >
                      {client}
                    </span>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* COLLECTIONS */}
      <section id="colecciones" className="mx-auto max-w-[88rem] px-5 py-20 sm:px-8 lg:py-28">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <Reveal>
            <SectionHeading
              eyebrow="Colecciones destacadas"
              title="Todo lo que tu marca necesita producir"
              description="Siete líneas de servicio que se combinan entre sí: diseña, imprime, exhibe y comunica con el mismo equipo."
            />
          </Reveal>
          <Reveal delay={120}>
            <Link
              href="/tienda"
              className="group inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.2em] text-ink-700 transition hover:text-brass-600"
            >
              Ver las 7 colecciones
              <svg viewBox="0 0 24 24" className="h-4 w-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M4 12h15M13 6l6 6-6 6" />
              </svg>
            </Link>
          </Reveal>
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:grid-rows-2">
          {categoryCounts.map((category, index) => {
            const featuredLayout =
              index === 0
                ? "sm:col-span-2 lg:row-span-2 min-h-[26rem] lg:min-h-[34rem]"
                : index === 3
                  ? "lg:col-span-2 min-h-[16rem]"
                  : "min-h-[16rem]";
            return (
              <Reveal key={category.slug} delay={index * 70} className={featuredLayout}>
                <Link
                  href={`/tienda?categoria=${category.slug}`}
                  className="group relative flex h-full flex-col justify-end overflow-hidden rounded-sm bg-ink-950 p-6 text-bone-100"
                >
                  <Image
                    src={category.heroImage}
                    alt={category.name}
                    fill
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                    className="object-cover opacity-60 transition-all duration-[1200ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-110 group-hover:opacity-75"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/50 to-transparent" />
                  <div className="relative">
                    <span className="text-2xl text-brass-300">{category.icon}</span>
                    <h3 className="display-balance mt-3 text-2xl leading-tight">{category.name}</h3>
                    <p className="mt-2 max-w-sm text-sm text-bone-300/80">{category.tagline}</p>
                    <div className="mt-5 flex items-center justify-between">
                      <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-brass-200">
                        {category.count} productos
                      </span>
                      <span className="grid h-9 w-9 place-items-center rounded-full border border-bone-100/30 text-bone-100 transition-all duration-500 group-hover:translate-x-1 group-hover:border-brass-300 group-hover:bg-brass-300 group-hover:text-ink-950">
                        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
                          <path d="M4 12h15M13 6l6 6-6 6" />
                        </svg>
                      </span>
                    </div>
                  </div>
                </Link>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* BESTSELLERS */}
      <section className="bg-ink-950 py-20 text-bone-100 lg:py-28">
        <div className="mx-auto max-w-[88rem] px-5 sm:px-8">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <Reveal>
              <SectionHeading
                invert
                eyebrow="Los favoritos del taller"
                title="Lo que los clientes piden otra vez"
                description="Piezas con precio abierto, tiraje claro y fecha de entrega real. Agrégalas al carrito y recibe cotización formal en menos de 4 horas."
              />
            </Reveal>
            <Reveal delay={120}>
              <Link
                href="/tienda?orden=populares"
                className="group inline-flex items-center gap-2 rounded-sm border border-bone-100/25 px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] transition hover:border-brass-300 hover:text-brass-200"
              >
                Ver más vendidos
              </Link>
            </Reveal>
          </div>

          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {bestsellers.map((product, index) => (
              <Reveal key={product.slug} delay={index * 80}>
                <ProductCard
                  product={product}
                  categoryName={
                    categories.find((category) => category.slug === product.categorySlug)?.name
                  }
                />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESS */}
      <section id="proceso" className="mx-auto max-w-[88rem] px-5 py-20 sm:px-8 lg:py-28">
        <div className="grid gap-14 lg:grid-cols-[0.95fr_1.05fr]">
          <Reveal>
            <SectionHeading
              eyebrow="Cómo trabajamos"
              title="Un proceso corto, con nombre y apellido"
              description="No hay intermediarios ni call center. Hablas con quien diseña, con quien imprime y con quien entrega."
            />
            <div className="mt-10 overflow-hidden rounded-sm">
              <div className="relative aspect-4/3">
                <Image
                  src="/images/collection-stationery.jpg"
                  alt="Papelería premium producida en taller"
                  fill
                  sizes="(max-width: 1024px) 100vw, 45vw"
                  className="object-cover"
                />
              </div>
            </div>
            <dl className="mt-8 grid grid-cols-2 gap-5 border-t border-bone-200 pt-8">
              {CAPABILITIES.map((capability) => (
                <div key={capability.label} className="flex gap-3">
                  <span className="text-iris-600">{capability.icon}</span>
                  <div>
                    <dt className="text-sm text-ink-900">{capability.label}</dt>
                    <dd className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-400">
                      {capability.detail}
                    </dd>
                  </div>
                </div>
              ))}
            </dl>
          </Reveal>

          <div className="space-y-3">
            {PROCESS.map((item, index) => (
              <Reveal key={item.step} delay={index * 90}>
                <div className="group relative overflow-hidden rounded-sm border border-bone-200 bg-bone-50 p-7 transition-all duration-500 hover:-translate-y-0.5 hover:border-brass-400/50 hover:bg-bone-100">
                  <div className="flex items-start gap-6">
                    <span className="display-balance text-4xl text-brass-400/70 transition-colors group-hover:text-iris-600">
                      {item.step}
                    </span>
                    <div>
                      <h3 className="display-balance text-xl">{item.title}</h3>
                      <p className="mt-2.5 text-sm leading-relaxed text-ink-600">{item.copy}</p>
                    </div>
                  </div>
                  <span className="absolute inset-x-0 bottom-0 h-px w-0 bg-gradient-to-r from-brass-400 to-transparent transition-all duration-700 group-hover:w-full" />
                </div>
              </Reveal>
            ))}
            <Reveal delay={380}>
              <div className="rounded-sm bg-ink-950 p-7 text-bone-100">
                <p className="eyebrow text-brass-300">Garantía de taller</p>
                <p className="mt-3 text-sm leading-relaxed text-bone-300/85">
                  Si el color, el corte o el armado no cumplen lo aprobado, lo reimpresionamos sin
                  costo. Así de simple: firmamos cada orden con responsable de producción.
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* TALLERES */}
      <section id="talleres" className="cyber-grid border-y border-iris-500/25 bg-ink-950 py-20 text-bone-100 lg:py-28">
        <div className="mx-auto max-w-[88rem] px-5 sm:px-8">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <Reveal>
              <div className="max-w-2xl">
                <p className="eyebrow text-brass-300">Talleres para emprender</p>
                <h2 className="display-balance neon-text mt-4 text-3xl leading-[1.08] sm:text-4xl lg:text-[2.75rem]">
                  Publicidad y marketing, explicados para quien está empezando
                </h2>
                <p className="mt-4 text-sm leading-relaxed text-bone-300/80 sm:text-base">
                  {settings.workshopsIntro}
                </p>
              </div>
            </Reveal>
            <Reveal delay={120}>
              <Link
                href="/talleres"
                className="group inline-flex items-center gap-2 rounded-sm border border-brass-400/50 px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-brass-200 transition hover:bg-brass-300 hover:text-ink-950"
              >
                Ver todos los talleres
                <svg viewBox="0 0 24 24" className="h-4 w-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <path d="M4 12h15M13 6l6 6-6 6" />
                </svg>
              </Link>
            </Reveal>
          </div>

          <div className="mt-12 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {talleres.slice(0, 3).map((taller, index) => (
              <Reveal key={taller.slug} delay={index * 80}>
                <Link
                  href={`/talleres#${taller.slug}`}
                  className="group panel-bevel flex h-full flex-col bg-ink-900/80 p-7 transition-transform duration-500 hover:-translate-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="grid h-12 w-12 place-items-center rounded-full border border-iris-400/50 text-xl text-iris-300 transition group-hover:border-brass-400 group-hover:text-brass-300">
                      {taller.icon}
                    </span>
                    <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-bone-300/60">
                      {taller.level}
                    </span>
                  </div>
                  <h3 className="display-balance mt-5 text-xl leading-snug transition group-hover:text-brass-200">
                    {taller.title}
                  </h3>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-bone-300/75">
                    {taller.summary}
                  </p>
                  <div className="mt-6 flex items-center justify-between border-t border-bone-100/10 pt-4">
                    <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-bone-300/60">
                      {taller.duration}
                    </span>
                    <span className="font-mono text-sm text-brass-300">
                      {taller.priceCents > 0
                        ? `$${(taller.priceCents / 100).toLocaleString("es-MX")}`
                        : "A medida"}
                    </span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED PRODUCTS */}
      <section className="border-y border-bone-200 bg-bone-100 py-20 lg:py-28">
        <div className="mx-auto max-w-[88rem] px-5 sm:px-8">
          <Reveal>
            <SectionHeading
              align="center"
              eyebrow="Selección del mes"
              title="Piezas listas para producir hoy"
              description="Servicios con precio público, especificación abierta y entregable claro. Elige, agrega al carrito y nosotros nos encargamos del resto."
            />
          </Reveal>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {featured.slice(0, 8).map((product, index) => (
              <Reveal key={product.slug} delay={index * 70}>
                <ProductCard
                  product={product}
                  categoryName={
                    categories.find((category) => category.slug === product.categorySlug)?.name
                  }
                />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* AUDIOVISUAL SPOTLIGHT */}
      <section className="mx-auto max-w-[88rem] px-5 py-20 sm:px-8 lg:py-28">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <Reveal>
            <div className="relative aspect-4/5 overflow-hidden rounded-sm">
              <Image
                src="/images/collection-audiovisual.jpg"
                alt="Estudio de producción de contenido UGC"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950/80 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 flex flex-wrap items-center gap-3">
                <span className="rounded-full bg-bone-50/95 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-900">
                  Rodaje UGC
                </span>
                <span className="rounded-full bg-bone-50/95 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-900">
                  4K · 9:16
                </span>
                <span className="rounded-full bg-brass-300 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-950">
                  Casting incluido
                </span>
              </div>
            </div>
          </Reveal>
          <Reveal delay={120}>
            <SectionHeading
              eyebrow="Marketing digital"
              title="Contenido UGC que se siente nativo, no publicitario"
              description="Creamos el video, la foto y la voz que tu marca necesita para vender en TikTok, Reels y marketplace. Guion con hook probado, creadores reales y entrega con variantes para pauta."
            />
            <ul className="mt-8 space-y-4">
              {[
                "Paquetes de 10 videos verticales con variantes de 15, 30 y 60 segundos",
                "Fotografía de producto en estudio con dirección de arte y retoque",
                "Modelaje editorial y talento e-commerce con liberación de derechos",
                "Cobertura de evento con resumen viral en 48 horas",
              ].map((item) => (
                <li key={item} className="flex gap-4 border-b border-bone-200 pb-4">
                  <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-brass-400" />
                  <span className="text-sm leading-relaxed text-ink-700">{item}</span>
                </li>
              ))}
            </ul>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/tienda?categoria=material-audiovisual"
                className="group inline-flex items-center gap-3 rounded-sm bg-ink-950 px-7 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-bone-100 transition hover:bg-brass-400 hover:text-ink-950"
              >
                Ver audiovisual
                <svg viewBox="0 0 24 24" className="h-4 w-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <path d="M4 12h15M13 6l6 6-6 6" />
                </svg>
              </Link>
              <Link
                href="/tienda?categoria=modelaje-talento"
                className="inline-flex items-center gap-3 rounded-sm border border-bone-300 px-7 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-ink-800 transition hover:border-ink-900"
              >
                Casting de modelaje
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* NEW ARRIVALS + REVIEWS */}
      <section className="bg-ink-950 py-20 text-bone-100 lg:py-28">
        <div className="mx-auto grid max-w-[88rem] gap-14 px-5 sm:px-8 lg:grid-cols-[1fr_1.1fr]">
          <div>
            <Reveal>
              <SectionHeading
                invert
                eyebrow="Recién llegados al catálogo"
                title="Novedades de temporada"
              />
            </Reveal>
            <div className="mt-10 space-y-4">
              {newest.map((product, index) => (
                <Reveal key={product.slug} delay={index * 90}>
                  <Link
                    href={`/producto/${product.slug}`}
                    className="group flex items-center gap-5 border-b border-bone-100/10 pb-4"
                  >
                    <span className="relative h-20 w-16 shrink-0 overflow-hidden rounded-sm bg-ink-800">
                      <Image
                        src={product.images[0]}
                        alt={product.name}
                        fill
                        sizes="64px"
                        className="object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="eyebrow block text-brass-300/80">
                        {
                          categories.find((category) => category.slug === product.categorySlug)
                            ?.name
                        }
                      </span>
                      <span className="display-balance mt-1.5 block text-lg leading-snug transition group-hover:text-brass-200">
                        {product.name}
                      </span>
                    </span>
                    <span className="shrink-0 font-mono text-sm text-bone-200">
                      {formatMoney(product.priceCents)}
                    </span>
                  </Link>
                </Reveal>
              ))}
            </div>
          </div>

          <div>
            <Reveal>
              <SectionHeading
                invert
                eyebrow="Reseñas verificadas"
                title="Lo que dicen quienes ya produjeron con nosotros"
              />
            </Reveal>
            <div className="mt-10 grid gap-4">
              {reviews.map((review, index) => (
                <Reveal key={review.id} delay={index * 100}>
                  <figure className="rounded-sm border border-bone-100/12 bg-ink-900/60 p-6 transition duration-500 hover:border-brass-400/40">
                    <StarRating value={review.rating} size="md" />
                    <figcaption className="display-balance mt-4 text-lg leading-snug">
                      “{review.title}”
                    </figcaption>
                    <blockquote className="mt-3 text-sm leading-relaxed text-bone-300/75">
                      {review.body}
                    </blockquote>
                    <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.16em] text-brass-300/80">
                      {review.author} · {review.role}
                    </p>
                  </figure>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section id="cotizacion" className="relative overflow-hidden bg-bone-100 py-20 lg:py-28">
        <div className="pointer-events-none absolute -right-20 top-0 h-80 w-80 rounded-full bg-brass-300/20 blur-3xl" />
        <div className="relative mx-auto grid max-w-[88rem] items-center gap-12 px-5 sm:px-8 lg:grid-cols-[1.15fr_0.85fr]">
          <Reveal>
            <SectionHeading
              eyebrow="Cotización"
              title="Cuéntanos qué necesitas producir"
              description="Responde tres datos y un asesor de producción te contacta con precio, tiraje sugerido y fecha de entrega. Sin compromiso y sin llamadas en frío."
            />
            <div className="mt-8 grid gap-4 sm:grid-cols-3">
              {[
                { label: "WhatsApp", value: settings.whatsapp },
                { label: "Correo", value: settings.email },
                { label: "Instagram", value: settings.instagram },
              ].map((item) => (
                <div key={item.label} className="border-l border-brass-400 pl-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-400">
                    {item.label}
                  </p>
                  <p className="mt-1.5 text-sm text-ink-900">{item.value}</p>
                </div>
              ))}
            </div>
          </Reveal>
          <Reveal delay={140}>
            <div className="rounded-sm border border-ink-900/10 bg-ink-950 p-8 text-bone-100">
              <p className="eyebrow text-brass-300">Brief mensual</p>
              <h3 className="display-balance mt-3 text-2xl leading-snug">
                Ideas de campaña y precios de temporada
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-bone-300/75">
                Un correo al mes con lo que está funcionando en punto de venta, formatos nuevos y
                promociones de tiraje.
              </p>
              <div className="mt-6">
                <NewsletterForm />
              </div>
              <Link
                href="/tienda"
                className="mt-8 flex items-center justify-center gap-3 rounded-sm border border-brass-400/50 px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-brass-200 transition hover:bg-brass-300 hover:text-ink-950"
              >
                O mira el catálogo completo
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
