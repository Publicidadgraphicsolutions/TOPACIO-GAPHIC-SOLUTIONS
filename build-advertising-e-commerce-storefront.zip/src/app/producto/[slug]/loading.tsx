export default function ProductoLoading() {
  return (
    <div className="mx-auto max-w-[88rem] px-5 py-12 sm:px-8 lg:py-16">
      <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
        <div className="space-y-4">
          <div className="aspect-4/5 animate-pulse rounded-sm bg-bone-200" />
          <div className="grid grid-cols-4 gap-3">
            {Array.from({ length: 4 }).map((_, index) => (
              <div key={index} className="aspect-square animate-pulse rounded-sm bg-bone-200" />
            ))}
          </div>
        </div>
        <div className="space-y-5">
          <div className="h-3 w-32 animate-pulse rounded-sm bg-bone-200" />
          <div className="h-12 w-4/5 animate-pulse rounded-sm bg-bone-200" />
          <div className="h-4 w-1/2 animate-pulse rounded-sm bg-bone-200" />
          <div className="h-20 w-full animate-pulse rounded-sm bg-bone-200" />
          <div className="h-14 w-full animate-pulse rounded-sm bg-bone-200" />
          <div className="h-24 w-full animate-pulse rounded-sm bg-bone-200" />
        </div>
      </div>
    </div>
  );
}
