import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { AddToCartPanel } from "@/components/add-to-cart";
import { ProductCard } from "@/components/product-card";
import { ProductGallery } from "@/components/product-gallery";
import { ReviewsSection } from "@/components/reviews-section";
import { Reveal, StarRating } from "@/components/ui";
import { formatMoney, ratingLabel } from "@/lib/format";
import {
  getCategories,
  getProductBySlug,
  getProducts,
  getRelatedProducts,
  getReviewsForProduct,
} from "@/lib/queries";

export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "Producto no encontrado" };
  return {
    title: product.name,
    description: product.shortDescription,
    openGraph: { images: [product.images[0]] },
  };
}

export default async function ProductPage({ params }: PageProps) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const [categories, reviews, related] = await Promise.all([
    getCategories(),
    getReviewsForProduct(slug),
    getRelatedProducts(product),
  ]);

  const category = categories.find((item) => item.slug === product.categorySlug);
  const categoryNames = new Map(categories.map((item) => [item.slug, item.name]));
  const hasDiscount =
    typeof product.compareAtPriceCents === "number" &&
    product.compareAtPriceCents > product.priceCents;

  return (
    <>
      <div className="border-b border-bone-200 bg-bone-100">
        <nav className="mx-auto flex max-w-[88rem] flex-wrap items-center gap-2 px-5 py-4 font-mono text-[10px] uppercase tracking-[0.18em] text-ink-400 sm:px-8">
          <Link href="/" className="transition hover:text-ink-900">
            Inicio
          </Link>
          <span>/</span>
          <Link href="/tienda" className="transition hover:text-ink-900">
            Catálogo
          </Link>
          <span>/</span>
          <Link
            href={`/tienda?categoria=${product.categorySlug}`}
            className="transition hover:text-ink-900"
          >
            {category?.name ?? product.categorySlug}
          </Link>
          <span>/</span>
          <span className="truncate text-ink-800">{product.name}</span>
        </nav>
      </div>

      <section className="mx-auto max-w-[88rem] px-5 py-10 sm:px-8 lg:py-16">
        <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
          <div className="lg:sticky lg:top-28 lg:self-start">
            <ProductGallery images={product.images} name={product.name} />
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-3">
              <span className="eyebrow text-iris-600">
                {category?.icon} {category?.name}
              </span>
              {product.badge ? (
                <span className="rounded-full border border-brass-400/40 bg-brass-100/70 px-3 py-1 font-mono text-[9px] uppercase tracking-[0.18em] text-brass-600">
                  {product.badge}
                </span>
              ) : null}
            </div>

            <h1 className="display-balance mt-4 text-[clamp(1.9rem,4vw,3rem)] leading-[1.05]">
              {product.name}
            </h1>

            <div className="mt-4 flex flex-wrap items-center gap-4">
              {product.reviewCount > 0 ? (
                <a href="#resenas" className="flex items-center gap-2">
                  <StarRating value={product.ratingAvg / 10} size="md" />
                  <span className="font-mono text-xs text-ink-600">
                    {ratingLabel(product.ratingAvg)} · {product.reviewCount} reseñas
                  </span>
                </a>
              ) : (
                <span className="font-mono text-xs uppercase tracking-[0.14em] text-ink-400">
                  Nuevo en catálogo
                </span>
              )}
              <span className="h-4 w-px bg-bone-300" />
              <span className="font-mono text-xs uppercase tracking-[0.14em] text-ink-400">
                SKU {product.sku}
              </span>
            </div>

            <p className="mt-6 text-[15px] leading-relaxed text-ink-700">
              {product.shortDescription}
            </p>

            <div className="mt-8 flex flex-wrap items-end gap-4 border-y border-bone-200 py-6">
              <div>
                <p className="display-balance text-4xl leading-none">
                  {formatMoney(product.priceCents)}
                </p>
                <p className="mt-2 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-400">
                  {product.unitLabel} · + IVA
                </p>
              </div>
              {hasDiscount ? (
                <p className="pb-1 font-mono text-sm text-flame-500">
                  <span className="line-through opacity-70">
                    {formatMoney(product.compareAtPriceCents as number)}
                  </span>{" "}
                  ahorra {formatMoney((product.compareAtPriceCents as number) - product.priceCents)}
                </p>
              ) : null}
              <div className="ml-auto flex flex-col items-end gap-1 pb-1 text-right">
                <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-400">
                  Entrega
                </span>
                <span className="font-mono text-xs text-ink-800">{product.leadTime}</span>
              </div>
            </div>

            <div className="mt-7">
              <AddToCartPanel
                product={{
                  slug: product.slug,
                  name: product.name,
                  image: product.images[0],
                  unitLabel: product.unitLabel,
                  priceCents: product.priceCents,
                  minQty: product.minQty,
                }}
              />
              <p className="mt-3 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-400">
                Cantidad mínima {product.minQty} · Confirmamos prueba de color antes de producir
              </p>
            </div>

            <ul className="mt-8 grid gap-3 sm:grid-cols-2">
              {product.highlights.map((highlight) => (
                <li key={highlight} className="flex gap-3">
                  <span className="mt-1 text-iris-600">
                    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
                      <path d="M5 13l4 4L19 7" />
                    </svg>
                  </span>
                  <span className="text-sm leading-relaxed text-ink-700">{highlight}</span>
                </li>
              ))}
            </ul>

            <div className="mt-8 grid gap-3 rounded-sm bg-ink-950 p-6 text-bone-100 sm:grid-cols-3">
              {[
                { label: "Asesor asignado", value: "Producción dedicada" },
                { label: "Garantía", value: "Reimpresión sin costo" },
                { label: "Facturación", value: "CFDI 4.0" },
              ].map((item) => (
                <div key={item.label}>
                  <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-brass-300">
                    {item.label}
                  </p>
                  <p className="mt-1.5 text-sm text-bone-200">{item.value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="border-y border-bone-200 bg-bone-100 py-14 lg:py-20">
        <div className="mx-auto grid max-w-[88rem] gap-12 px-5 sm:px-8 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
          <Reveal>
            <p className="eyebrow text-iris-600">Ficha del servicio</p>
            <h2 className="display-balance mt-3 text-3xl leading-tight">Así se produce</h2>
            <p className="mt-5 text-[15px] leading-relaxed text-ink-700">{product.description}</p>
            <div className="mt-8 flex flex-wrap gap-2">
              {product.tags.map((tag) => (
                <Link
                  key={tag}
                  href={`/tienda?tags=${encodeURIComponent(tag)}`}
                  className="rounded-full border border-bone-300 bg-bone-50 px-3.5 py-1.5 text-xs text-ink-600 transition hover:border-ink-900 hover:text-ink-900"
                >
                  #{tag}
                </Link>
              ))}
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="overflow-hidden rounded-sm border border-bone-300 bg-bone-50">
              <div className="border-b border-bone-200 bg-ink-950 px-6 py-4">
                <p className="eyebrow text-brass-300">Especificación técnica</p>
              </div>
              <dl className="divide-y divide-bone-200">
                {product.specs.map((spec) => (
                  <div key={spec.label} className="flex items-start justify-between gap-6 px-6 py-4">
                    <dt className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-400">
                      {spec.label}
                    </dt>
                    <dd className="max-w-[60%] text-right text-sm text-ink-800">{spec.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <div className="mt-5 rounded-sm border border-brass-400/40 bg-brass-100/40 p-6">
              <p className="eyebrow text-brass-600">Archivo de impresión</p>
              <p className="mt-2 text-sm leading-relaxed text-ink-700">
                Aceptamos PDF x-1a, AI, PSD y PNG a 300 dpi con 3 mm de sangrado. Si no tienes el
                archivo, nuestro equipo de diseño lo prepara sin costo adicional en pedidos desde
                $10,000 MXN.
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-[88rem] px-5 py-14 sm:px-8 lg:py-20">
        <ReviewsSection
          productSlug={product.slug}
          reviews={reviews}
          ratingAvg={product.ratingAvg}
        />
      </section>

      {related.length > 0 ? (
        <section className="border-t border-bone-200 bg-bone-100 py-14 lg:py-20">
          <div className="mx-auto max-w-[88rem] px-5 sm:px-8">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="eyebrow text-iris-600">Combina tu pedido</p>
                <h2 className="display-balance mt-3 text-3xl leading-tight">
                  También lo pidieron con esto
                </h2>
              </div>
              <Link
                href={`/tienda?categoria=${product.categorySlug}`}
                className="group inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.18em] text-ink-700 transition hover:text-brass-600"
              >
                Ver {category?.name ?? "colección"}
                <svg viewBox="0 0 24 24" className="h-4 w-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <path d="M4 12h15M13 6l6 6-6 6" />
                </svg>
              </Link>
            </div>
            <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((item, index) => (
                <Reveal key={item.slug} delay={index * 70}>
                  <ProductCard
                    product={item}
                    categoryName={categoryNames.get(item.categorySlug)}
                    compact
                  />
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      ) : null}
    </>
  );
}


