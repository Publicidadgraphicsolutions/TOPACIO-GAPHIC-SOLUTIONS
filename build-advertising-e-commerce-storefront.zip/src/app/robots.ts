import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/pedido/", "/api/"] }],
    sitemap: "https://publicidadgraphic.mx/sitemap.xml",
  };
}
